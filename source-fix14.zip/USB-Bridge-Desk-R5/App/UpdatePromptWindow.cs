// SPDX-License-Identifier: GPL-3.0-only
using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Controls;
using System.Runtime.InteropServices;
using System.Windows.Automation;

namespace Desk;

internal sealed class UpdatePromptWindow : Window
{
    [StructLayout(LayoutKind.Sequential)]
    private struct WindowRect
    {
        internal int Left;
        internal int Top;
        internal int Right;
        internal int Bottom;
    }

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(nint hwnd);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(nint hwnd, out WindowRect rect);

    [DllImport("user32.dll")]
    private static extern nint GetForegroundWindow();

    private readonly TaskCompletionSource<bool> result = new(
        TaskCreationOptions.RunContinuationsAsynchronously
    );
    private readonly DispatcherQueueTimer heartbeat;
    private int ticks;
    private bool opened;

    internal UpdatePromptWindow(object content)
    {
        Title = "USB Bridge Desk 更新";
        var layout = new StackPanel
        {
            Spacing = 20,
            Margin = new Thickness(24),
            VerticalAlignment = VerticalAlignment.Center,
        };
        layout.Children.Add((UIElement)content);
        var actions = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Spacing = 8,
        };
        var later = new Button { Content = "稍后", MinWidth = 96 };
        var install = new AutomationTraceButton { Content = "下载并安装", MinWidth = 120 };
        later.Click += (_, _) => Finish(false);
        install.Click += (_, _) => Finish(true);
        actions.Children.Add(later);
        actions.Children.Add(install);
        layout.Children.Add(actions);
        Content = layout;

        AppWindow.Resize(new(520, 250));
        var area = DisplayArea.GetFromWindowId(AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        AppWindow.MoveAndResize(new(
            area.X + (area.Width - 520) / 2,
            area.Y + (area.Height - 250) / 2,
            520,
            250
        ));

        heartbeat = DispatcherQueue.GetForCurrentThread().CreateTimer();
        heartbeat.Interval = TimeSpan.FromSeconds(5);
        heartbeat.Tick += (_, _) =>
        {
            ticks++;
            Program.Trace($"Update prompt dispatcher heartbeat tick={ticks} elapsed_seconds={ticks * 5}");
            TraceAccessibilityState($"heartbeat-{ticks}");
            if (ticks >= 14) heartbeat.Stop();
        };
        Activated += (_, _) =>
        {
            if (opened) return;
            opened = true;
            Program.Trace("Update dialog Opened (top-level Window)");
            TraceAccessibilityState("opened");
            heartbeat.Start();
        };
        Closed += (_, _) =>
        {
            heartbeat.Stop();
            result.TrySetResult(false);
        };
    }

    internal Task<bool> ShowAsync()
    {
        Activate();
        return result.Task;
    }

    private void Finish(bool install)
    {
        result.TrySetResult(install);
        Close();
    }

    private void TraceAccessibilityState(string reason)
    {
        try
        {
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
            var hasRect = GetWindowRect(hwnd, out var rect);
            var foreground = GetForegroundWindow();
            var rootPeer = Content is FrameworkElement root
                ? FrameworkElementAutomationPeer.CreatePeerForElement(root)
                : null;
            AutomationElement? windowElement = null;
            AutomationElement? buttonElement = null;
            var fromHandleError = "none";
            var windowPattern = false;
            try
            {
                windowElement = AutomationElement.FromHandle(hwnd);
                if (windowElement is not null)
                {
                    windowPattern = windowElement.TryGetCurrentPattern(
                        WindowPattern.Pattern,
                        out _
                    );
                    var buttonCondition = new AndCondition(
                        new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                        new PropertyCondition(AutomationElement.NameProperty, "下载并安装")
                    );
                    buttonElement = windowElement.FindFirst(TreeScope.Descendants, buttonCondition);
                }
            }
            catch (Exception e)
            {
                fromHandleError = $"0x{e.HResult:X8}:{e.GetType().Name}";
            }

            var windowName = "unavailable";
            var windowType = "unavailable";
            if (windowElement is not null)
            {
                try
                {
                    windowName = windowElement.Current.Name;
                    windowType = windowElement.Current.ControlType.ProgrammaticName;
                }
                catch (Exception e)
                {
                    windowName = $"error:{e.GetType().Name}";
                }
            }
            Program.Trace(
                $"Update prompt UIA probe reason={reason} hwnd=0x{hwnd.ToInt64():X} " +
                $"visible={IsWindowVisible(hwnd)} rectAvailable={hasRect} " +
                $"rect={rect.Left},{rect.Top},{rect.Right},{rect.Bottom} " +
                $"foreground=0x{foreground.ToInt64():X} foregroundIsWindow={foreground == hwnd} " +
                $"fromHandle={(windowElement is null ? "null" : "element")} fromHandleError={fromHandleError} " +
                $"windowName='{windowName}' windowType={windowType} " +
                $"buttonFound={buttonElement is not null} rootPeer={(rootPeer is null ? "null" : rootPeer.GetType().Name)} " +
                $"windowPattern={windowPattern}"
            );
        }
        catch (Exception e)
        {
            Program.Trace($"Update prompt UIA probe failed reason={reason} error=0x{e.HResult:X8}:{e}");
        }
    }
}

internal sealed class AutomationTraceButton : Button
{
    protected override AutomationPeer OnCreateAutomationPeer()
    {
        var peer = base.OnCreateAutomationPeer();
        Program.Trace("Update prompt download button AutomationPeer created");
        return peer;
    }
}
