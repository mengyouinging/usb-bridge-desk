# R4 使用的组件

| 项目 | 版本与用途 | 许可或分发条款 |
|---|---|---|
| USB Bridge Desk | R4 / 1.2.0。设备流程、安装和驱动配置来自附件 1.0.1。 | GPL-3.0-only，见 LICENSE。 |
| Windows App SDK / WinUI 3 | Windows App SDK 1.8.260921001 对应 WinUI、Foundation、InteractiveExperiences 投影。窗口、控件、弹窗、云母和亚克力。 | 开源仓库的相关代码使用 MIT。实际随包 Microsoft 二进制按 Windows App SDK 软件许可条款，见 WindowsAppSDK-license.txt 和 WinUI-NOTICE.txt。 |
| Microsoft WebView2 SDK 类型投影 | 1.0.3179.45。WinUI 程序集元数据引用的托管投影 DLL，保留类型解析兼容性。程序仅创建 WinUI 原生控件，安装器未包含浏览器内核。 | Microsoft WebView2 SDK 许可，见 WebView2-SDK-license.txt。 |
| .NET / Windows Forms / C#/WinRT | .NET 10 桌面共享运行时供主程序、通知区图标、PNG 和系统对话框使用。WinRT.Runtime.dll 与 Windows SDK 投影由 .NET SDK 引入。 | .NET、Windows Forms 和 C#/WinRT 源码为 MIT。Microsoft 运行时与投影使用各自发布条款。 |
| usbipd-win | v5.3.0。自源码构建服务端和 CLI，上游原始 MSI 配置系统服务及驱动。 | GPL-3.0-only，含 usbipd-win-5.3.0-source.zip 与 COPYING。 |
| VirtualBox USB / USBMon | 7.2.2。上游 USB 共享端驱动。 | GPL-3.0，见 VirtualBox-Drivers.md。 |
| usbip-win2 / wusbip | v.0.9.8.1。USB/IP 导入、UDE 虚拟控制器。wusbip 的映射呈现作为基线参考。 | BSD-2-Clause，见对应源码和许可证。客户端安装程序还包含 Microsoft VC++ Redistributable。 |
| RemoteUSB | 基线的状态解析、CLI 适配和提权行为来源。 | MIT，见 RemoteUSB-MIT.txt。 |
| NSIS | 3.11，安装器与卸载器。 | zlib/libpng 及组件各自条款，见 NSIS-licenses.txt。 |

UU 远程和 EasyTier 由用户按所选传输方式准备。两者通过目标端点接入。

Desk UI Sans 是 Noto Sans SC 的可变字重子集，涵盖随包中文界面文案。字体文件随应用加载。上游为 Google Fonts 的 ofl/notosanssc 版本，许可和版权声明见 NotoSansSC-OFL.txt。
