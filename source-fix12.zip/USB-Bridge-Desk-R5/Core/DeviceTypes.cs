// SPDX-License-Identifier: GPL-3.0-only
using System.Text.RegularExpressions;

namespace UsbBridge;

public sealed record DeviceType(string Title, string Glyph, bool Inferred = false)
{
    public string Label => Title + (Inferred ? "（推测）" : "");
}

public sealed record UsbEvidence(
    string ClassGuid,
    string[] CompatibleIds,
    byte? DeviceClass = null,
    byte? DeviceSubClass = null,
    byte? DeviceProtocol = null,
    byte? InterfaceClass = null,
    byte? InterfaceSubClass = null,
    byte? InterfaceProtocol = null,
    ushort? HidUsagePage = null,
    ushort? HidUsage = null,
    string ProductName = ""
);

public static class DeviceTypes
{
    private static readonly DeviceType Mouse = new("鼠标", "\uE962"),
        Keyboard = new("键盘", "\uE765"),
        Disk = new("U盘/移动硬盘", "\uEDA2"),
        Printer = new("打印机", "\uE749"),
        Camera = new("摄像头", "\uE722"),
        Imaging = new("影像设备", "\uE722"),
        Audio = new("音频设备", "\uE767"),
        Serial = new("串口设备", "\uE968"),
        Key = new("加密狗", "\uE8D7"),
        Hub = new("集线器", "\uE968"),
        Network = new("网卡", "\uE774"),
        SmartCard = new("智能卡读卡器", "\uE8D7"),
        Biometric = new("指纹/生物识别", "\uE928"),
        Unknown = new("USB 设备", "\uE88E");

    private static readonly Dictionary<(string Vid, string Pid), string> Products = LoadProducts();

    public static string DatabaseVersion => "2026.06.26";

    private static Dictionary<(string, string), string> LoadProducts()
    {
        var result = new Dictionary<(string, string), string>();
        var file = Path.Combine(AppContext.BaseDirectory, "usb.ids");
        if (!File.Exists(file))
            file = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../usb.ids"));
        if (!File.Exists(file))
            return result;
        string vid = "";
        foreach (var line in File.ReadLines(file))
        {
            if (line.Length == 0 || line[0] == '#') continue;
            if (line[0] != '\t' && line.Length >= 4 && ushort.TryParse(line.AsSpan(0, 4), System.Globalization.NumberStyles.HexNumber, null, out _))
                vid = line[..4].ToLowerInvariant();
            else if (line.StartsWith("\t\t", StringComparison.Ordinal)) continue;
            else if (line.Length > 6 && line[0] == '\t' && ushort.TryParse(line.AsSpan(1, 4), System.Globalization.NumberStyles.HexNumber, null, out _))
                result[(vid, line.Substring(1, 4).ToLowerInvariant())] = line[6..].Trim();
        }
        return result;
    }

    public static string ProductName(string vid, string pid) => Products.GetValueOrDefault((vid.ToLowerInvariant(), pid.ToLowerInvariant()), "");

    public static DeviceType Infer(string name, string vid, string pid)
    {
        var rules = new (string Pattern, DeviceType Kind)[]
        {
            (@"\b(mouse|trackball)\b|鼠标", Mouse), (@"\bkeyboard\b|键盘", Keyboard),
            (@"flash drive|mass storage|thumb drive|portable ssd|移动硬盘|存储|优盘|U盘", Disk),
            (@"printer|打印机", Printer), (@"camera|webcam|摄像头", Camera),
            (@"audio|microphone|headset|音频|麦克风", Audio), (@"serial|uart|串口", Serial),
            (@"sentinel (hasp|hl)|\bhasp\b|security key|加密狗", Key), (@"\bhub\b|集线器", Hub),
        };
        foreach (var (pattern, type) in rules)
            if (Regex.IsMatch(name, pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
                return type with { Inferred = true };
        return Unknown;
    }

    public static DeviceType Classify(string name, string vid, string pid, IEnumerable<(string ClassGuid, string[] CompatibleIds)> nodes) =>
        Classify(name, vid, pid, nodes.Select(n => new UsbEvidence(n.ClassGuid, n.CompatibleIds)));

    public static DeviceType Classify(string name, string vid, string pid, IEnumerable<UsbEvidence> evidence)
    {
        var nodes = evidence.ToArray();
        // Compatible IDs are interface-level on composite devices and take precedence.
        foreach (var node in nodes)
            foreach (var id in node.CompatibleIds)
                if (CompatibleType(id) is { } type)
                    return type;
        foreach (var node in nodes)
        {
            var type = InterfaceType(node.InterfaceClass, node.InterfaceSubClass, node.InterfaceProtocol);
            if (type != null) return type;
        }
        foreach (var node in nodes)
        {
            var type = node.DeviceClass is null or 0x00 or 0xef or 0xff
                ? null : InterfaceType(node.DeviceClass, node.DeviceSubClass, node.DeviceProtocol);
            if (type != null) return type;
        }
        foreach (var node in nodes)
            if (ClassGuidType(node.ClassGuid) is { } type)
                return type;
        foreach (var node in nodes)
        {
            if (node.HidUsagePage != 0x01) continue;
            if (node.HidUsage == 0x06) return Keyboard;
            if (node.HidUsage == 0x02) return Mouse;
        }
        foreach (var node in nodes)
            if (node.ClassGuid.Trim('{', '}').Equals("745a17a0-74d3-11d0-b6fe-00a0c90f57da", StringComparison.OrdinalIgnoreCase))
                return new("HID 设备", "\uE765");
        var product = nodes.Select(n => n.ProductName).FirstOrDefault(n => !string.IsNullOrEmpty(n)) ?? "";
        return Infer(name.Length == 0 ? (product.Length == 0 ? ProductName(vid, pid) : product) : name, "", "");
    }

    private static DeviceType? CompatibleType(string id)
    {
        var match = Regex.Match(id, @"^USB\\Class_([0-9a-f]{2})(?:&SubClass_([0-9a-f]{2}))?(?:&Prot_([0-9a-f]{2}))?$", RegexOptions.IgnoreCase);
        if (match.Success)
        {
            byte cls = Convert.ToByte(match.Groups[1].Value, 16);
            byte? sub = match.Groups[2].Success ? Convert.ToByte(match.Groups[2].Value, 16) : null;
            byte? proto = match.Groups[3].Success ? Convert.ToByte(match.Groups[3].Value, 16) : null;
            return InterfaceType(cls, sub, proto);
        }
        if (id.Equals("PNP0501", StringComparison.OrdinalIgnoreCase) || id.Equals("GUID_DEVINTERFACE_COMPORT", StringComparison.OrdinalIgnoreCase)) return Serial;
        return null;
    }


    private static DeviceType? InterfaceType(byte? cls, byte? sub, byte? protocol) => (cls, sub, protocol) switch
    {
        (0x03, 0x01, 0x01) => Keyboard,
        (0x03, 0x01, 0x02) => Mouse,
        (0x01, _, _) or (0x10, _, _) => Audio,
        (0x02, 0x02, _) => new("通信设备/串口设备", "\uE968"),
        (0x02, 0x0d, _) or (0xef, 0x04, 0x01) or (0xe0, 0x03, _) => Network,
        (0x02, 0x0e, _) => new("移动宽带", "\uE774"),
        (0x03, _, _) => null,
        (0x05, _, _) => new("力反馈设备", "\uE962"),
        (0x06, 0x01, 0x01) => Imaging,
        (0x07, _, _) => Printer,
        (0x08, 0x06, 0x50 or 0x62 or null) => Disk,
        (0x08, _, _) => new("存储设备", "\uEDA2"),
        (0x09, _, _) => Hub,
        (0x0b, _, _) => SmartCard,
        (0x0d, _, _) => Biometric,
        (0x0e, _, _) => Camera,
        (0x0f, _, _) => new("健康设备", "\uE95E"),
        (0x11, _, _) => new("USB-C Billboard", "\uE8A5"),
        (0x12, _, _) => new("USB-C 桥接设备", "\uE8A5"),
        (0xfe, _, _) => new("专用 USB 设备", "\uE88E"),
        (0xe0, 0x01, _) => new("蓝牙设备", "\uE702"),
        _ => null,
    };

    private static DeviceType? ClassGuidType(string guid) => guid.Trim('{', '}').ToLowerInvariant() switch
    {
        "4d36e96f-e325-11ce-bfc1-08002be10318" => Mouse,
        "4d36e96b-e325-11ce-bfc1-08002be10318" => Keyboard,
        "4d36e967-e325-11ce-bfc1-08002be10318" or "4d36e965-e325-11ce-bfc1-08002be10318" => Disk,
        "4d36e97b-e325-11ce-bfc1-08002be10318" => new("SCSI 存储适配器", "\uEDA2"),
        "4d36e979-e325-11ce-bfc1-08002be10318" => Printer,
        "6bdd1fc6-810f-11d0-bec7-08002be2092f" => Imaging,
        "ca3e7ab9-b4c3-4ae6-8251-579ef933890f" => Camera,
        "4d36e96c-e325-11ce-bfc1-08002be10318" => Audio,
        "4d36e978-e325-11ce-bfc1-08002be10318" => Serial,
        "4d36e972-e325-11ce-bfc1-08002be10318" => Network,
        "e0cbf06c-cd8b-4647-bb8a-263b43f0f974" => new("蓝牙设备", "\uE702"),
        "50dd5230-ba8a-11d1-bf5d-0000f805f530" => SmartCard,
        "53d29ef7-377c-4d14-864b-eb3a85769359" => Biometric,
        _ => null,
    };
}
