// SPDX-License-Identifier: GPL-3.0-only
using Microsoft.UI.Composition;
using Microsoft.UI.Composition.SystemBackdrops;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Controls;
using Windows.UI;

namespace Desk;

// Each instance belongs to one Shell. XAML tracks activation and accessibility
// through its default backdrop configuration.
internal sealed partial class WindowAcrylic(bool dark, Panel panel) : SystemBackdrop
{
    private DesktopAcrylicController? controller;

    private SolidColorBrush? solid;

    internal void SetTheme(bool isDark)
    {
        dark = isDark;
        var tint = dark ? Color.FromArgb(255, 28, 36, 40) : Color.FromArgb(255, 239, 246, 245);
        if (solid is not null)
            solid.Color = tint;
        if (controller is null)
            return;
        controller.TintColor = tint;
        controller.FallbackColor = tint;
        controller.TintOpacity = dark ? 0.48f : 0.62f;
        controller.LuminosityOpacity = dark ? 0.42f : 0.62f;
    }

    protected override void OnTargetConnected(ICompositionSupportsSystemBackdrop target, XamlRoot root)
    {
        base.OnTargetConnected(target, root);
        try
        {
            controller = new DesktopAcrylicController();
            controller.SetSystemBackdropConfiguration(GetDefaultSystemBackdropConfiguration(target, root));
            SetTheme(dark);
            if (controller.AddSystemBackdropTarget(target))
            {
                Program.Trace("DesktopAcrylicController attached=True");
                return;
            }
        }
        catch (Exception e)
        {
            Program.Trace($"Desktop acrylic: {e.Message}");
        }
        controller?.Dispose();
        controller = null;
        solid = new SolidColorBrush();
        SetTheme(dark);
        panel.Background = solid;
        Program.Trace("DesktopAcrylicController attached=False; using solid fallback");
    }

    protected override void OnTargetDisconnected(ICompositionSupportsSystemBackdrop target)
    {
        controller?.RemoveSystemBackdropTarget(target);
        controller?.Dispose();
        controller = null;
        if (solid is not null)
        {
            if (panel.Background == solid)
                panel.Background = null;
            solid = null;
        }
        base.OnTargetDisconnected(target);
    }
}
