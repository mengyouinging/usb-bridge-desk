// SPDX-License-Identifier: GPL-3.0-only
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

namespace Desk;

internal static class TrayArtwork
{
    public static readonly IReadOnlyDictionary<string, Color> Palette = new Dictionary<
        string,
        Color
    >
    {
        ["idle"] = Color.SlateGray,
        ["active"] = Color.FromArgb(28, 183, 105),
        ["warning"] = Color.FromArgb(244, 171, 31),
        ["fault"] = Color.FromArgb(225, 78, 83),
    };

    [DllImport("user32.dll")]
    private static extern bool DestroyIcon(nint handle);

    public static Icon Create(Icon original, Color color)
    {
        using var image = original.ToBitmap();
        using (var g = Graphics.FromImage(image))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using var dot = new SolidBrush(color);
            float scale = image.Width / 32f;
            g.ScaleTransform(scale, scale);
            // Keep both polar connectors clear on the hinted small frame.
            float left = image.Width == 16 ? 0 : 21;
            g.FillEllipse(Brushes.WhiteSmoke, left, 21, 11, 11);
            g.FillEllipse(dot, left + 1.5f, 22.5f, 8, 8);
        }
        var handle = image.GetHicon();
        try
        {
            using var wrapped = Icon.FromHandle(handle);
            return (Icon)wrapped.Clone();
        }
        finally
        {
            DestroyIcon(handle);
        }
    }
}
