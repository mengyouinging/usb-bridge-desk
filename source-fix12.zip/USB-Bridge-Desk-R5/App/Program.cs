// SPDX-License-Identifier: GPL-3.0-only
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using WinRT;

namespace Desk;

internal static class Program
{
    internal static readonly string Folder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "USB Bridge Desk"
    );
    internal static readonly string LogPath = Path.Combine(Folder, "startup.log");

    [DllImport("Microsoft.ui.xaml.dll", ExactSpelling = true)]
    private static extern void XamlCheckProcessRequirements();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    internal static extern int MessageBox(nint hwnd, string message, string title, uint type);

    internal static void Trace(string message)
    {
        try
        {
            Directory.CreateDirectory(Folder);
            File.AppendAllText(LogPath, $"{DateTimeOffset.Now:O} {message}\n");
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    internal static void Fatal(Exception e)
    {
        Environment.ExitCode = 1;
        Trace($"HRESULT 0x{e.HResult:X8} {e}");
        if (Environment.GetEnvironmentVariable("USB_BRIDGE_CAPTURE") == "1")
            return;
        MessageBox(
            0,
            $"USB Bridge Desk 启动或运行遇到问题。\n{e.Message}\n\n请运行安装包修复运行时或查看日志：\n{LogPath}",
            "USB Bridge Desk",
            0x10
        );
    }

    internal static EventWaitHandle? Wake;

    [STAThread]
    private static int Main()
    {
        Trace($"Main pid={Environment.ProcessId} base={AppContext.BaseDirectory}");
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Trace($"Unhandled: {e.ExceptionObject}");
        using var single = new Mutex(true, @"Local\UsbBridgeDesk-R3", out bool first);
        if (!first)
        {
            for (int i = 0; i < 20; i++)
            {
                if (EventWaitHandle.TryOpenExisting(@"Local\UsbBridgeDesk-Show", out var existing))
                {
                    using (existing)
                        existing.Set();
                    break;
                }
                Thread.Sleep(100);
            }
            return 0;
        }
        try
        {
            Wake = new(false, EventResetMode.AutoReset, @"Local\UsbBridgeDesk-Show");
            Trace("Checking WinUI process requirements");
            XamlCheckProcessRequirements();
            StartUI();
            return Environment.ExitCode;
        }
        catch (Exception e)
        {
            Fatal(e);
            return 1;
        }
        finally
        {
            Wake?.Dispose();
        }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void StartUI()
    {
        ComWrappersSupport.InitializeComWrappers();
        Trace("Entering Application.Start");
        Application.Start(_ =>
        {
            SynchronizationContext.SetSynchronizationContext(
                new DispatcherQueueSynchronizationContext(DispatcherQueue.GetForCurrentThread())
            );
            Trace("UI dispatcher ready, creating application");
            try
            {
                _app = new DeskApp();
            }
            catch (Exception e)
            {
                Trace($"Creating application: HRESULT 0x{e.HResult:X8} {e}");
                throw;
            }
        });
    }

    private static DeskApp? _app;
}

public sealed partial class DeskApp : Application
{
    private Shell? window;

    public DeskApp()
    {
        UnhandledException += (_, e) => Program.Fatal(e.Exception);
        Program.Trace("Loading compiled App.xaml");
        InitializeComponent();
        Program.Trace("Application resources loaded");
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        try
        {
            Program.Trace("Constructing main window");
            window = new Shell();
            Program.Trace("Activating main window");
            window.Activate();
        }
        catch (Exception e)
        {
            Program.Fatal(e);
            Exit();
        }
    }
}
