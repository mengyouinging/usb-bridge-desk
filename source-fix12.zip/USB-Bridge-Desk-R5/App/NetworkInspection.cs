// SPDX-License-Identifier: GPL-3.0-only
using System.ComponentModel;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using UsbBridge;

namespace Desk;

internal static class NetworkInspection
{
    public static LocalAddress[] Enumerate(LocalAddress[] previous)
    {
        var virtualIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            using var drivers = Registry.LocalMachine.OpenSubKey(
                @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}"
            );
            if (drivers != null)
                foreach (var key in drivers.GetSubKeyNames().Where(s => int.TryParse(s, out _)))
                {
                    using var driver = drivers.OpenSubKey(key);
                    if (
                        driver?.GetValue("Characteristics") is int bits
                        && (bits & 5) != 0
                        && driver.GetValue("NetCfgInstanceId") is string id
                    )
                        virtualIds.Add(id);
                }
        }
        catch (Exception ex)
            when (ex
                    is IOException
                        or UnauthorizedAccessException
                        or System.Security.SecurityException
            )
        {
            Program.Trace("Adapter driver metadata unavailable: " + ex.Message);
        }
        var rows = new List<LocalAddress>();
        var adapters = NetworkInterface.GetAllNetworkInterfaces();
        foreach (var adapter in adapters)
        {
            if (adapter.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                continue;
            try
            {
                foreach (var addr in adapter.GetIPProperties().UnicastAddresses)
                {
                    var ip = addr.Address;
                    if (
                        IPAddress.IsLoopback(ip)
                        || ip.IsIPv6LinkLocal
                        || ip.AddressFamily
                            is not (AddressFamily.InterNetwork or AddressFamily.InterNetworkV6)
                    )
                        continue;
                    rows.Add(
                        new(
                            adapter.Name,
                            adapter.Id,
                            ip,
                            adapter.OperationalStatus == OperationalStatus.Up,
                            addr.DuplicateAddressDetectionState
                                == DuplicateAddressDetectionState.Preferred
                                && addr.AddressValidLifetime != 0,
                            ip.AddressFamily == AddressFamily.InterNetworkV6
                                && addr.SuffixOrigin == SuffixOrigin.Random,
                            adapter.NetworkInterfaceType is NetworkInterfaceType.Tunnel or NetworkInterfaceType.Ppp
                                || adapter.Description.Contains("VMware", StringComparison.OrdinalIgnoreCase)
                                || adapter.Description.Contains("VirtualBox", StringComparison.OrdinalIgnoreCase)
                                || adapter.Description.Contains("Hyper-V Virtual", StringComparison.OrdinalIgnoreCase)
                                || adapter.Description.Contains("Wintun", StringComparison.OrdinalIgnoreCase)
                                || adapter.Description.Contains("TAP-Windows", StringComparison.OrdinalIgnoreCase)
                                || virtualIds.Contains(adapter.Id)
                                    && (adapter.NetworkInterfaceType is NetworkInterfaceType.Tunnel or NetworkInterfaceType.Ppp),
                            adapter.Description
                        )
                    );
                }
            }
            catch (NetworkInformationException)
            { /* Adapter disappeared during enumeration. */
            }
        }
        var current = rows.Select(r => (r.Id, r.IP)).ToHashSet();
        foreach (var old in previous)
            if (!current.Contains((old.Id, old.IP)))
                rows.Add(
                    old with
                    {
                        Valid = false,
                        Up = adapters.Any(n =>
                            n.Id == old.Id && n.OperationalStatus == OperationalStatus.Up
                        ),
                    }
                );
        return rows.ToArray();
    }

    [DllImport("advapi32", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern nint OpenSCManagerW(string? machine, string? db, uint access);

    [DllImport("advapi32", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern nint OpenServiceW(nint scm, string name, uint access);

    [DllImport("advapi32")]
    private static extern bool QueryServiceStatusEx(
        nint service,
        int level,
        [Out] byte[] data,
        int size,
        out int needed
    );

    [DllImport("advapi32")]
    private static extern bool CloseServiceHandle(nint service);

    private static int HostPid()
    {
        var scm = OpenSCManagerW(null, null, 1);
        if (scm == 0)
            return 0;
        try
        {
            var svc = OpenServiceW(scm, "usbipd", 4);
            if (svc == 0)
                return 0;
            try
            {
                var status = new byte[36];
                return
                    QueryServiceStatusEx(svc, 0, status, status.Length, out _)
                    && BitConverter.ToInt32(status, 4) == 4
                    ? BitConverter.ToInt32(status, 28)
                    : 0;
            }
            finally
            {
                CloseServiceHandle(svc);
            }
        }
        finally
        {
            CloseServiceHandle(scm);
        }
    }

    [DllImport("iphlpapi")]
    private static extern uint GetExtendedTcpTable(
        byte[]? table,
        ref int size,
        bool sort,
        int family,
        int tableClass,
        uint reserved
    );

    private sealed record Listener(IPAddress IP, int Pid);

    private static IEnumerable<Listener> Listeners(bool ipv6)
    {
        int size = 0;
        var family = ipv6 ? 23 : 2;
        uint result = GetExtendedTcpTable(null, ref size, false, family, 3, 0); // TCP_TABLE_OWNER_PID_LISTENER
        while (result == 122)
        {
            var data = new byte[size];
            result = GetExtendedTcpTable(data, ref size, false, family, 3, 0);
            if (result != 0)
                continue;
            int count = BitConverter.ToInt32(data);
            for (int i = 0; i < count; i++)
            {
                int pos = 4 + i * (ipv6 ? 56 : 24);
                int port = pos + (ipv6 ? 20 : 8);
                if (data[port] * 256 + data[port + 1] != 3240)
                    continue;
                var ip = ipv6
                    ? new IPAddress(data.AsSpan(pos, 16), BitConverter.ToUInt32(data, pos + 16))
                    : new IPAddress(data.AsSpan(pos + 4, 4));
                yield return new(ip, BitConverter.ToInt32(data, pos + (ipv6 ? 52 : 20)));
            }
        }
        if (result != 0)
            throw new Win32Exception((int)result);
    }

    public static Func<IPAddress, string?> SnapshotListeners()
    {
        int pid = HostPid();
        var entries = (Socket.OSSupportsIPv4 ? Listeners(false) : Enumerable.Empty<Listener>())
            .Concat(Socket.OSSupportsIPv6 ? Listeners(true) : [])
            .ToArray();
        return ip =>
        {
            if (pid == 0)
                return "无法确认共享服务进程，请刷新。";
            var exact = entries
                .Where(x =>
                    x.IP.Equals(ip)
                    || (
                        x.IP.AddressFamily == ip.AddressFamily
                        && (x.IP.Equals(IPAddress.Any) || x.IP.Equals(IPAddress.IPv6Any))
                    )
                )
                .ToArray();
            if (exact.Length > 0)
                return exact.All(x => x.Pid == pid) ? null : "TCP 3240 有其它进程监听。";
            // usbipd uses a dual-mode IPv6 socket. The per-address handshake checks IPv4 acceptance.
            if (
                ip.AddressFamily == AddressFamily.InterNetwork
                && entries.Any(x => x.IP.Equals(IPAddress.IPv6Any) && x.Pid == pid)
            )
                return null;
            return "此地址上未发现共享服务的 TCP 3240 监听。";
        };
    }
}
