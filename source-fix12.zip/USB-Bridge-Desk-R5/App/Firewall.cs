// SPDX-License-Identifier: GPL-3.0-only
using System.Net;
using System.Runtime.InteropServices;
using UsbBridge;

namespace Desk;

// A local handshake bypasses some inbound filters. Only report an explicit block
// when the rule applies independently of the remote address, identity and port.
internal static class Firewall
{
    private static bool IncludesPort(string? ports)
    {
        if (string.IsNullOrEmpty(ports) || ports == "*")
            return true;
        foreach (var entry in ports.Split(','))
        {
            var range = entry.Trim().Split('-');
            if (
                int.TryParse(range[0], out int low)
                && int.TryParse(range[^1], out int high)
                && low <= 3240
                && high >= 3240
            )
                return true;
        }
        return false;
    }

    public static HashSet<IPAddress> ExplicitBlocks(
        IEnumerable<LocalAddress> addresses,
        CancellationToken token
    )
    {
        var blocked = new HashSet<IPAddress>();
        var policyType = Type.GetTypeFromProgID("HNetCfg.FwPolicy2");
        if (policyType == null)
            return blocked;
        dynamic policy = Activator.CreateInstance(policyType)!;
        try
        {
            int profiles = policy.CurrentProfileTypes;
            if (profiles == 0)
                return blocked;
            foreach (int profile in new[] { 1, 2, 4 })
                if ((profiles & profile) != 0 && !(bool)policy.FirewallEnabled[profile])
                    return blocked;
            string host = Path.Combine(AppContext.BaseDirectory, "resources", "host", "usbipd.exe");
            foreach (dynamic rule in policy.Rules)
            {
                try
                {
                    token.ThrowIfCancellationRequested();
                    if (
                        !(bool)rule.Enabled
                        || (int)rule.Direction != 1
                        || (int)rule.Action != 0
                        || ((int)rule.Profiles & profiles) != profiles
                        || (int)rule.Protocol is not (6 or 256)
                    )
                        continue;
                    if (
                        !string.Equals(
                            (string?)rule.InterfaceTypes,
                            "All",
                            StringComparison.OrdinalIgnoreCase
                        ) || rule.Interfaces is Array { Length: > 0 }
                    )
                        continue;
                    string? app = rule.ApplicationName,
                        service = rule.ServiceName;
                    if (
                        !string.IsNullOrEmpty(app)
                        && !string.Equals(
                            Environment.ExpandEnvironmentVariables(app),
                            host,
                            StringComparison.OrdinalIgnoreCase
                        )
                    )
                        continue;
                    if (
                        !string.IsNullOrEmpty(service)
                        && !service.Equals("usbipd", StringComparison.OrdinalIgnoreCase)
                    )
                        continue;
                    if (
                        (string?)rule.RemoteAddresses is not ("*" or null or "")
                        || (
                            (int)rule.Protocol == 6
                            && (
                                (string?)rule.RemotePorts is not ("*" or null or "")
                                || !IncludesPort((string?)rule.LocalPorts)
                            )
                        )
                    )
                        continue;
                    if (
                        !string.IsNullOrEmpty((string?)rule.LocalAppPackageId)
                        || !string.IsNullOrEmpty((string?)rule.LocalUserAuthorizedList)
                        || !string.IsNullOrEmpty((string?)rule.RemoteMachineAuthorizedList)
                        || !string.IsNullOrEmpty((string?)rule.RemoteUserAuthorizedList)
                    )
                        continue;
                    string? filter = rule.LocalAddresses;
                    foreach (var a in addresses)
                        if (
                            string.IsNullOrEmpty(filter)
                            || filter == "*"
                            || filter
                                .Split(',')
                                .Any(x =>
                                    IPAddress.TryParse(x.Trim(), out var ip) && ip.Equals(a.IP)
                                    || IPNetwork.TryParse(x.Trim(), out var subnet)
                                        && subnet.Contains(a.IP)
                                )
                        )
                            blocked.Add(a.IP);
                }
                catch (COMException)
                { /* Unsupported rule scopes cannot establish a definite block. */
                }
                finally
                {
                    Marshal.ReleaseComObject(rule);
                }
            }
        }
        finally
        {
            Marshal.ReleaseComObject(policy);
        }
        return blocked;
    }
}
