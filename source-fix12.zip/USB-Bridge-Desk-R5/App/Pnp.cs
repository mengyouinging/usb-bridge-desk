// SPDX-License-Identifier: GPL-3.0-only
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Text.RegularExpressions;
using UsbBridge;

namespace Desk;

internal static class Pnp
{
    [DllImport("cfgmgr32.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint CM_Locate_DevNodeW(out uint node, string id, uint flags);

    [DllImport("cfgmgr32.dll")]
    private static extern uint CM_Get_Child(out uint child, uint node, uint flags);

    [DllImport("cfgmgr32.dll")]
    private static extern uint CM_Get_Sibling(out uint sibling, uint node, uint flags);

    [DllImport("cfgmgr32.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint CM_Get_Device_IDW(
        uint node,
        StringBuilder id,
        uint length,
        uint flags
    );

    [DllImport("cfgmgr32.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint CM_Get_DevNode_Registry_PropertyW(
        uint node,
        uint property,
        out uint type,
        byte[]? buffer,
        ref uint bytes,
        uint flags
    );

    private static readonly Guid ComPort = new("86e0d1e0-8089-11d0-9ce4-08003e301f73");

    [DllImport("cfgmgr32.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint CM_Get_Device_Interface_List_SizeW(
        out uint length,
        in Guid type,
        string instance,
        uint flags
    );

    private static string[] Read(uint node, uint key)
    {
        uint size = 0;
        CM_Get_DevNode_Registry_PropertyW(node, key, out _, null, ref size, 0);
        if (size == 0 || size > 65536)
            return [];
        var data = new byte[size];
        if (CM_Get_DevNode_Registry_PropertyW(node, key, out _, data, ref size, 0) != 0)
            return [];
        return Encoding
            .Unicode.GetString(data, 0, (int)size)
            .Split('\0', StringSplitOptions.RemoveEmptyEntries);
    }

    public static Local Identify(Local row)
    {
        var facts = new List<UsbEvidence>();
        if (row.Instance.Length != 0 && CM_Locate_DevNodeW(out var root, row.Instance, 0) == 0)
        {
            var pending = new Queue<uint>();
            pending.Enqueue(root);
            while (pending.TryDequeue(out uint node))
            {
                if (node != root)
                {
                    var id = new StringBuilder(256);
                    if (CM_Get_Device_IDW(node, id, 256, 0) != 0)
                        continue;
                    // Traverse functions of this peripheral, never a new physical USB child of a hub.
                    var idParts = id.ToString().Split('\\');
                    if (
                        idParts.Length > 1
                        && idParts[0].Equals("USB", StringComparison.OrdinalIgnoreCase)
                        && !idParts[1].Contains("&MI_", StringComparison.OrdinalIgnoreCase)
                    )
                        continue;
                }
                string guid = Read(node, 9).FirstOrDefault() ?? "";
                var ids = Read(node, 3);
                if (
                    guid.Equals(
                        "{4D36E978-E325-11CE-BFC1-08002BE10318}",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    var instance = new StringBuilder(256);
                    if (
                        CM_Get_Device_IDW(node, instance, 256, 0) == 0
                        && CM_Get_Device_Interface_List_SizeW(
                            out var length,
                            in ComPort,
                            instance.ToString(),
                            0
                        ) == 0
                        && length > 1
                    )
                        ids = [.. ids, "GUID_DEVINTERFACE_COMPORT"];
                }
                var deviceId = new StringBuilder(256);
                CM_Get_Device_IDW(node, deviceId, 256, 0);
                var hardwareIds = Read(node, 1);
                ids = [.. ids, .. hardwareIds];
                var parts = deviceId.ToString().Split('\\');
                var usbId = parts.Length > 1 ? parts[1] : "";
                var vid = Regex.Match(usbId, @"VID_([0-9A-F]{4})", RegexOptions.IgnoreCase).Groups[1].Value;
                var pid = Regex.Match(usbId, @"PID_([0-9A-F]{4})", RegexOptions.IgnoreCase).Groups[1].Value;
                facts.Add(new(guid, ids,
                    DeviceClass: ReadByte(node, 7),
                    DeviceSubClass: ReadByte(node, 8),
                    DeviceProtocol: ReadByte(node, 10),
                    ProductName: vid.Length == 4 && pid.Length == 4 ? DeviceTypes.ProductName(vid, pid) : ""));
                if (CM_Get_Child(out uint child, node, 0) == 0)
                {
                    do
                    {
                        pending.Enqueue(child);
                    } while (CM_Get_Sibling(out child, child, 0) == 0);
                }
            }
        }
        var d = row.Device;
        return row with
        {
            Device = d with { Kind = DeviceTypes.Classify(d.Name, d.Vid, d.Pid, facts) },
        };
    }

    private static byte? ReadByte(uint node, uint key)
    {
        var values = Read(node, key);
        return values.Length > 0 && byte.TryParse(values[0], System.Globalization.NumberStyles.HexNumber, null, out var value) ? value : null;
    }

}
