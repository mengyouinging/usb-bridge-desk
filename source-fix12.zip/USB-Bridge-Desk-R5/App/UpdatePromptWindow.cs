// SPDX-License-Identifier: GPL-3.0-only
using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Controls;

namespace Desk;

internal sealed class UpdatePromptWindow : Window
{
    private readonly TaskCompletionSource<bool> result = new(
        TaskCreationOptions.RunContinuationsAsynchronously
    );
    private readonly DispatcherQueueTimer heartbeat;
    private int ticks;
    private bool opened;

    internal UpdatePromptWindow(object content)
    {
        Title = "USB Bridge Desk 更新";
        var layout = new StackPanel
        {
            Spacing = 20,
            Margin = new Thickness(24),
            VerticalAlignment = VerticalAlignment.Center,
        };
        layout.Children.Add((UIElement)content);
        var actions = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Spacing = 8,
        };
        var later = new Button { Content = "稍后", MinWidth = 96 };
        var install = new AutomationTraceButton { Content = "下载并安装", MinWidth = 120 };
        later.Click += (_, _) => Finish(false);
        install.Click += (_, _) => Finish(true);
        actions.Children.Add(later);
        actions.Children.Add(install);
        layout.Children.Add(actions);
        Content = layout;

        AppWindow.Resize(new(520, 250));
        var area = DisplayArea.GetFromWindowId(AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        AppWindow.MoveAndResize(new(
            area.X + (area.Width - 520) / 2,
            area.Y + (area.Height - 250) / 2,
            520,
            250
        ));

        heartbeat = DispatcherQueue.GetForCurrentThread().CreateTimer();
        heartbeat.Interval = TimeSpan.FromSeconds(5);
        heartbeat.Tick += (_, _) =>
        {
            ticks++;
            Program.Trace($"Update prompt dispatcher heartbeat tick={ticks} elapsed_seconds={ticks * 5}");
            if (ticks >= 14) heartbeat.Stop();
        };
        Activated += (_, _) =>
        {
            if (opened) return;
            opened = true;
            Program.Trace("Update dialog Opened (top-level Window)");
            heartbeat.Start();
        };
        Closed += (_, _) =>
        {
            heartbeat.Stop();
            result.TrySetResult(false);
        };
    }

    internal Task<bool> ShowAsync()
    {
        Activate();
        return result.Task;
    }

    private void Finish(bool install)
    {
        result.TrySetResult(install);
        Close();
    }
}

internal sealed class AutomationTraceButton : Button
{
    protected override AutomationPeer OnCreateAutomationPeer()
    {
        var peer = base.OnCreateAutomationPeer();
        Program.Trace("Update prompt download button AutomationPeer created");
        return peer;
    }
}
