#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Download the pinned upstream release assets required to build Windows setup."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
from pathlib import Path
from shutil import copyfileobj
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
ASSETS = {
    'vendor/usbipd-win_5.3.0_x64.msi': (
        'https://github.com/dorssel/usbipd-win/releases/download/v5.3.0/usbipd-win_5.3.0_x64.msi',
        '1c984914aec944de19b64eff232421439629699f8138e3ddc29301175bc6d938',
    ),
    'vendor/USBip-0.9.8.1-x64.exe': (
        'https://github.com/vadimgrn/usbip-win2/releases/download/v.0.9.8.1/USBip-0.9.8.1-x64.exe',
        '38cad6d4432b52d5bb9409d9ad03b72fdffc4ada4cd3a48fbeca1a2752a8518a',
    ),
    'notices/usbipd-win-5.3.0-source.zip': (
        'https://codeload.github.com/dorssel/usbipd-win/zip/refs/tags/v5.3.0',
        'ba590c5f73a209683e8285a6fe6ff852f696bd433893cd6081e6d4223c893da4',
    ),
    'notices/usbip-win2-0.9.8.1-source.zip': (
        'https://codeload.github.com/vadimgrn/usbip-win2/zip/refs/tags/v.0.9.8.1',
        '39fdc6d115e77897c042994ddf8b5843ad5bcc77469a786ebf41688949c8fe4b',
    ),

}

def checksum(path):
    with path.open('rb') as data:
        return file_digest(data, 'sha256').hexdigest()

def fetch(item):
    name, (url, expected) = item
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or checksum(path) != expected:
        pending = path.with_name(path.name + '.partial')
        try:
            with urlopen(Request(url, headers={'User-Agent': 'USB-Bridge-Desk-Build/1.0'}), timeout=90) as remote:
                with pending.open('wb') as target:
                    copyfileobj(remote, target)
            if checksum(pending) != expected:
                raise ValueError(f'SHA-256 mismatch: {name}')
            pending.replace(path)
        finally:
            pending.unlink(missing_ok=True)
    print(f'OK {name}')

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(fetch, ASSETS.items()))
