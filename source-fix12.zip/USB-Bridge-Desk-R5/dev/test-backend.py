#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Exercise the installed Windows host and client on loopback, without attaching a device."""
import json
import os
from pathlib import Path
import re
import socket
import struct
import subprocess
import sys

ENDPOINT = ('127.0.0.1', 3240)


def command(*args, timeout=30):
    proc = subprocess.run(args, capture_output=True, timeout=timeout)
    if proc.returncode:
        detail = (proc.stderr or proc.stdout).decode('utf-8-sig', 'replace').strip()
        raise RuntimeError(f'{Path(args[0]).name} exit {proc.returncode}: {detail[:1200]}')
    return proc.stdout.decode('utf-8-sig', 'replace').strip()


def powershell(script):
    return command('powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                   "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); " + script)


def service():
    return json.loads(powershell(
        """Get-CimInstance Win32_Service -Filter "Name='usbipd'" |
           Select-Object State,ProcessId,PathName | ConvertTo-Json -Compress"""))


def read_exact(stream, size):
    data = stream.read(size)
    if len(data) != size:
        raise ValueError(f'Truncated USB/IP reply: expected {size} bytes, got {len(data)}')
    return data


def devlist(endpoint=ENDPOINT):
    with socket.create_connection(endpoint, timeout=6) as sock, sock.makefile('rb') as stream:
        sock.sendall(struct.pack('!HHI', 0x0111, 0x8005, 0))
        version, opcode, status = struct.unpack('!HHI', read_exact(stream, 8))
        if (version, opcode, status) != (0x0111, 0x0005, 0):
            raise ValueError(f'Unexpected DEVLIST reply: {version:#06x}, {opcode:#06x}, status {status}')
        count, = struct.unpack('!I', read_exact(stream, 4))
        for _ in range(count):
            device = read_exact(stream, 312)
            read_exact(stream, device[-1] * 4)
    return {'endpoint': f'{endpoint[0]}:{endpoint[1]}', 'version': '0x0111',
            'request': 'OP_REQ_DEVLIST', 'reply': 'OP_REP_DEVLIST', 'status': status, 'exports': count}


def main():
    report_file = Path(sys.argv[1])
    host = Path(os.environ['APP_PATH']).parent / 'resources/host/usbipd.exe'
    client = Path(os.environ['ProgramFiles']) / 'USB Bridge Desk Engines/Client/usbip.exe'
    checks = {}
    restore_stopped = False

    def check(name, fn):
        try:
            checks[name] = {'passed': True, 'evidence': fn()}
        except Exception as exc:
            checks[name] = {'passed': False, 'error': str(exc)}
        report_file.write_text(json.dumps(checks, indent=2), encoding='utf-8')
        print(name, json.dumps(checks[name]), flush=True)

    def start_service():
        nonlocal restore_stopped
        info = service()
        if info['PathName'].casefold() != f'"{host}" server'.casefold() or not host.is_file():
            raise ValueError(f"Unexpected installed service image: {info['PathName']}")
        restore_stopped = info['State'] == 'Stopped'
        powershell("""$s = Get-Service usbipd; Start-Service -InputObject $s;
                      $s.WaitForStatus('Running',[TimeSpan]::FromSeconds(15))""")
        info = service()
        if info['State'] != 'Running' or not info['ProcessId']:
            raise ValueError(f'Service did not enter Running: {info}')
        return info

    def listener():
        rows = json.loads(powershell("""
            $end=(Get-Date).AddSeconds(12)
            do {
                $s=Get-CimInstance Win32_Service -Filter "Name='usbipd'"
                $ls=@(Get-NetTCPConnection -LocalPort 3240 -State Listen -ErrorAction SilentlyContinue |
                      Where-Object { $s.State -eq 'Running' -and $_.OwningProcess -eq $s.ProcessId } |
                      Select-Object LocalAddress,LocalPort,OwningProcess)
                if ($ls.Count -gt 0) { ConvertTo-Json -InputObject $ls -Compress; return }
                Start-Sleep -Milliseconds 250
            } while ((Get-Date) -lt $end)
            throw 'No TCP 3240 listener owned by the usbipd service PID'
            """))
        return rows

    def host_devices():
        devices = json.loads(command(host, 'state'))['Devices']
        if not isinstance(devices, list) or any(not isinstance(d, dict) for d in devices):
            raise ValueError('usbipd state must return a Devices array of objects')
        return {'exitCode': 0, 'devices': len(devices)}

    def client_list():
        listing = command(client, '--tcp-port', str(ENDPOINT[1]), 'list', '-r', ENDPOINT[0])
        buses = re.findall(r'^\s*(\d+-\d+(?:\.\d+)*)\s*:', listing, re.MULTILINE)
        if listing and not buses:
            raise ValueError(f'Unrecognized USB/IP client list output: {listing[:400]}')
        return {'exitCode': 0, 'exports': len(buses), 'endpoint': '127.0.0.1:3240'}

    def client_ports():
        output = command(client, 'port')
        ports = re.findall(r'^Port\s+\d+:', output, re.MULTILINE | re.IGNORECASE)
        if output and not ports:
            raise ValueError(f'Unrecognized virtual controller output: {output[:400]}')
        return {'exitCode': 0, 'importedPorts': len(ports)}

    def stop_service():
        powershell("""$s=Get-Service usbipd; Stop-Service -InputObject $s;
                      $s.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(15))""")
        return {'restored': 'Stopped'}

    try:
        check('service_start', start_service)
        check('tcp_3240_listener', listener)
        check('host_device_enumeration', host_devices)
        check('usbip_devlist_handshake', devlist)
        check('installed_client_loopback_list', client_list)
        check('client_virtual_ports', client_ports)
    finally:
        if restore_stopped:
            check('restore_service', stop_service)
        elif checks.get('service_start', {}).get('passed'):
            def retained():
                state = service()['State']
                if state != 'Running':
                    raise RuntimeError(f'Unexpected final service state: {state}')
                return {'unchanged': state}
            check('restore_service', retained)
    return 0 if all(row['passed'] for row in checks.values()) else 1


if __name__ == '__main__':
    sys.exit(main())
