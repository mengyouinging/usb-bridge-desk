"""Read-only loopback DEVLIST fixture for the installed client's UI capture."""
import json
from pathlib import Path
import socket
import struct
import sys

def serve(port_file):
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0))
        listener.listen(2)
        port_file.write_text(json.dumps({'port':listener.getsockname()[1]}))
        while True:
            conn,_=listener.accept()
            with conn,conn.makefile('rb') as reader:
                conn.settimeout(4)
                try:
                    if reader.read(8)!=struct.pack('!HHI',0x111,0x8005,0):
                        continue
                    device=struct.pack('!256s32sIIIHHHBBBBBB',b'/fixture/1-2',b'1-2',
                                       1,2,2,0x046d,0xc077,0x0100,0,0,0,1,1,1)
                    conn.sendall(struct.pack('!HHII',0x111,5,0,1)+device+bytes([3,1,2,0]))
                except (TimeoutError,ConnectionError):
                    continue
if __name__=='__main__':
    serve(Path(sys.argv[1]))
