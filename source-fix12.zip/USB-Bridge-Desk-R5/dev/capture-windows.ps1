﻿# SPDX-License-Identifier: GPL-3.0-only
# Captures pixels from the interactive Windows desktop. Invoke in a separate console.
param([string]$OutputDirectory=(Join-Path $PWD 'screenshots'))
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class CaptureWindow {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h,int k,out Rect r,int n);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
}
'@
[void][CaptureWindow]::SetThreadDpiAwarenessContext([IntPtr](-4))
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
$exe=Join-Path $env:ProgramFiles 'USB Bridge Desk\UsbBridgeDesk.exe'
$record=@()
foreach ($shot in @(
    @('01-overview','显示连接概览'),
    @('02-local','显示共享本机 USB 页面'),
    @('03-remote','显示连接远端 USB 页面及目标'),
    @('04-mappings','显示映射列表'),
    @('05-acrylic','设置中打开黑夜与亚克力，让窗口后有可辨颜色，确保 Windows 透明效果开启'),
    @('06-tray','准备右键打开 USB Bridge Desk 托盘菜单。此张包含当前屏幕，请先移开其他私人内容')
)){
    Read-Host "$($shot[1])。回车后有 8 秒切换窗口或打开托盘菜单" | Out-Null
    Start-Sleep -Seconds 8
    if($shot[0] -eq '06-tray'){
        $rect=[Windows.Forms.Screen]::FromPoint([Windows.Forms.Cursor]::Position).Bounds
    } else {
        $proc=Get-Process -Name UsbBridgeDesk | Where-Object {$_.MainWindowHandle -ne 0 -and $_.Path -eq $exe} | Select-Object -First 1
        if(-not $proc){ throw '请先打开 R3 的主窗口。' }
        $r=New-Object CaptureWindow+Rect
        if([CaptureWindow]::DwmGetWindowAttribute($proc.MainWindowHandle,9,[ref]$r,16) -ne 0){throw '无法读取窗口范围。'}
        $rect=[Drawing.Rectangle]::FromLTRB($r.Left,$r.Top,$r.Right,$r.Bottom)
    }
    $file=Join-Path $OutputDirectory ($shot[0]+'.png')
    $bitmap=New-Object Drawing.Bitmap $rect.Width,$rect.Height
    $graphics=[Drawing.Graphics]::FromImage($bitmap)
    try{$graphics.CopyFromScreen($rect.Location,[Drawing.Point]::Empty,$rect.Size);$bitmap.Save($file,[Drawing.Imaging.ImageFormat]::Png)}
    finally{$graphics.Dispose();$bitmap.Dispose()}
    $record+=@{file=$shot[0]+'.png';sha256=(Get-FileHash $file).Hash;captured=(Get-Date -Format o)}
}
@{os=[Environment]::OSVersion.Version.ToString();appSha256=(Get-FileHash $exe).Hash;
  managedAppSha256=(Get-FileHash (Join-Path (Split-Path $exe) 'UsbBridgeDesk.dll')).Hash;
  screenshots=$record} | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory 'capture.json')
