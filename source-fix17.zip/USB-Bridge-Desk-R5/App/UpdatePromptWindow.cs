// SPDX-License-Identifier: GPL-3.0-only
using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using System.Runtime.InteropServices;
using Windows.UI;

namespace Desk;

internal sealed class UpdatePromptWindow : Window
{
    [StructLayout(LayoutKind.Sequential)]
    private struct WindowRect
    {
        internal int Left;
        internal int Top;
        internal int Right;
        internal int Bottom;
    }

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(nint hwnd);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(nint hwnd, out WindowRect rect);

    [DllImport("user32.dll")]
    private static extern nint GetForegroundWindow();

    private readonly TaskCompletionSource<bool> result = new(
        TaskCreationOptions.RunContinuationsAsynchronously
    );
    private readonly DispatcherQueueTimer heartbeat;
    private readonly UIElement installButton;
    private int ticks;
    private bool opened;

    internal UpdatePromptWindow(object content)
    {
        Title = "USB Bridge Desk 更新";
        var layout = new StackPanel
        {
            Spacing = 20,
            Margin = new Thickness(24),
            VerticalAlignment = VerticalAlignment.Center,
        };
        layout.Children.Add((UIElement)content);
        var actions = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Spacing = 8,
        };
        var later = new Button { Content = "稍后", MinWidth = 96 };
        var install = new AutomationTraceButton { Content = "下载并安装", MinWidth = 120 };
        installButton = install;
        later.Click += (_, _) => Finish(false);
        install.Click += (_, _) => Finish(true);
        actions.Children.Add(later);
        actions.Children.Add(install);
        layout.Children.Add(actions);
        Content = layout;

        AppWindow.Resize(new(520, 250));
        var area = DisplayArea.GetFromWindowId(AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        AppWindow.MoveAndResize(new(
            area.X + (area.Width - 520) / 2,
            area.Y + (area.Height - 250) / 2,
            520,
            250
        ));

        heartbeat = DispatcherQueue.GetForCurrentThread().CreateTimer();
        heartbeat.Interval = TimeSpan.FromSeconds(5);
        heartbeat.Tick += (_, _) =>
        {
            ticks++;
            Program.Trace($"Update prompt dispatcher heartbeat tick={ticks} elapsed_seconds={ticks * 5}");
            TraceAccessibilityState($"heartbeat-{ticks}");
            if (ticks >= 22) heartbeat.Stop();
        };
        Activated += (_, _) =>
        {
            if (opened) return;
            opened = true;
            Program.Trace("Update dialog Opened (top-level Window)");
            TraceAccessibilityState("opened");
            heartbeat.Start();
        };
        Closed += (_, _) =>
        {
            heartbeat.Stop();
            result.TrySetResult(false);
        };
    }

    internal Task<bool> ShowAsync()
    {
        Activate();
        return result.Task;
    }

    private void Finish(bool install)
    {
        result.TrySetResult(install);
        Close();
    }

    private void TraceAccessibilityState(string reason)
    {
        try
        {
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
            var hasRect = GetWindowRect(hwnd, out var rect);
            var foreground = GetForegroundWindow();
            var contentRoot = Content as FrameworkElement;
            var rootPeer = contentRoot is not null
                ? FrameworkElementAutomationPeer.CreatePeerForElement(contentRoot)
                : null;
            var buttonPeer = FindDownloadButtonPeer(rootPeer);
            var installPeer = installButton is FrameworkElement installElement
                ? FrameworkElementAutomationPeer.CreatePeerForElement(installElement)
                : null;
            var children = rootPeer?.GetChildren();
            Program.Trace(
                $"Update prompt UIA probe reason={reason} hwnd=0x{hwnd.ToInt64():X} " +
                $"visible={IsWindowVisible(hwnd)} rectAvailable={hasRect} " +
                $"rect={rect.Left},{rect.Top},{rect.Right},{rect.Bottom} " +
                $"foreground=0x{foreground.ToInt64():X} foregroundIsWindow={foreground == hwnd} " +
                $"fromHandle=peer-tree fromHandleError=not-used " +
                $"windowName='unavailable' windowType=unavailable " +
                $"contentIsLoaded={contentRoot?.IsLoaded.ToString() ?? "null"} " +
                $"contentHasXamlRoot={contentRoot?.XamlRoot is not null} " +
                $"installPeer={(installPeer is null ? "null" : installPeer.GetType().Name)} " +
                $"rootPeerChildren={children?.Count.ToString() ?? "null"} " +
                $"buttonFound={buttonPeer is not null} rootPeer={(rootPeer is null ? "null" : rootPeer.GetType().Name)} " +
                $"windowPattern=unavailable"
            );
        }
        catch (Exception e)
        {
            Program.Trace($"Update prompt UIA probe failed reason={reason} error=0x{e.HResult:X8}:{e}");
        }
    }

    private static AutomationPeer? FindDownloadButtonPeer(AutomationPeer? peer)
    {
        if (peer is null) return null;
        if (peer.GetAutomationControlType() == AutomationControlType.Button &&
            peer.GetName() == "下载并安装")
            return peer;

        var children = peer.GetChildren();
        if (children is null) return null;
        foreach (var child in children)
        {
            var found = FindDownloadButtonPeer(child);
            if (found is not null) return found;
        }
        return null;
    }
}

internal static class UpdatePromptPanel
{
    internal static Task<bool> ShowAsync(Grid host, UIElement content)
    {
        var result = new TaskCompletionSource<bool>(
            TaskCreationOptions.RunContinuationsAsynchronously
        );
        var overlay = new Grid
        {
            Background = new SolidColorBrush(Color.FromArgb(112, 0, 0, 0)),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
        };
        Grid.SetRowSpan(overlay, Math.Max(1, host.RowDefinitions.Count));
        AutomationProperties.SetAutomationId(overlay, "UpdatePrompt.Overlay");

        var panel = new Border
        {
            Width = 520,
            MaxWidth = 520,
            Padding = new Thickness(24),
            Background = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255)),
            BorderBrush = new SolidColorBrush(Color.FromArgb(255, 205, 205, 205)),
            BorderThickness = new Thickness(1),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            RequestedTheme = ElementTheme.Light,
        };
        var layout = new StackPanel { Spacing = 20 };
        layout.Children.Add(new TextBlock
        {
            Text = "USB Bridge Desk 更新",
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        });
        layout.Children.Add(content);

        var actions = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Spacing = 8,
        };
        var later = new Button { Content = "稍后", MinWidth = 96 };
        var install = new Button { Content = "下载并安装", MinWidth = 120 };
        AutomationProperties.SetAutomationId(later, "UpdatePrompt.Defer");
        AutomationProperties.SetAutomationId(install, "UpdatePrompt.Install");
        later.Click += (_, _) => Finish(false);
        install.Click += (_, _) => Finish(true);
        actions.Children.Add(later);
        actions.Children.Add(install);
        layout.Children.Add(actions);
        panel.Child = layout;
        overlay.Children.Add(panel);
        host.Children.Add(overlay);
        Program.Trace("Update dialog Opened (inline panel)");
        Program.Trace("Update prompt inline panel mounted in main-window UIA tree");
        install.Focus(FocusState.Programmatic);

        return result.Task;

        void Finish(bool shouldInstall)
        {
            host.Children.Remove(overlay);
            result.TrySetResult(shouldInstall);
        }
    }
}

internal sealed class AutomationTraceButton : Button
{
    protected override AutomationPeer OnCreateAutomationPeer()
    {
        var peer = base.OnCreateAutomationPeer();
        Program.Trace("Update prompt download button AutomationPeer created");
        return peer;
    }
}
