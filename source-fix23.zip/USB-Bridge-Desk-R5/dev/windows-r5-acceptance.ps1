param(
    [Parameter(Mandatory=$true)][string]$AppPath,
    [Parameter(Mandatory=$true)][string]$UninstallerPath,
    [Parameter(Mandatory=$true)][string]$InstallerPath,
    [Parameter(Mandatory=$true)][string]$FixtureUrl,
    [string]$OutDir=(Join-Path $PWD 'screenshots')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Drawing,System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class R5WindowProbe {
    public struct Rect { public int Left, Top, Right, Bottom; }
    private delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr data);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr data);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    public static IntPtr[] ForProcess(int processId) {
        var windows = new List<IntPtr>();
        EnumWindows((hwnd, data) => {
            uint owner;
            GetWindowThreadProcessId(hwnd, out owner);
            if (owner == processId) windows.Add(hwnd);
            return true;
        }, IntPtr.Zero);
        return windows.ToArray();
    }
}
'@
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$buttonType = [Windows.Automation.ControlType]::Button
$invoke = [Windows.Automation.InvokePattern]::Pattern
New-Item -ItemType Directory -Force $OutDir | Out-Null
$log = Join-Path $OutDir 'acceptance.log'
function Log([string]$text) { Add-Content -LiteralPath $log -Encoding UTF8 -Value "$(Get-Date -Format o) $text" }
function Get-StartupPromptOpenedAt {
    $startupLog=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (-not (Test-Path -LiteralPath $startupLog)) { return $null }
    $line=Get-Content -LiteralPath $startupLog | Where-Object { $_ -match 'Update dialog Opened \(' } | Select-Object -Last 1
    if ($line -match '^(\S+) Update dialog Opened \(') {
        try { return [DateTimeOffset]::Parse($Matches[1]).LocalDateTime }
        catch { return $null }
    }
    return $null
}
function Get-ButtonAutomationId([string[]]$names,[string]$label) {
    foreach ($name in $names) {
        if ($name -eq '下载并安装') { return 'UpdatePrompt.Install' }
        if ($name -eq '稍后') { return 'UpdatePrompt.Defer' }
    }
    switch ($label) {
        'Settings navigation' { return 'Nav.settings' }
        'settings update check' { return 'Settings.UpdateCheck' }
        { $_ -in @('running-app uninstall confirmation','uninstall confirmation') } { return '6' }
        'live-app uninstall guard dialog' { return '1' }
    }
    return $null
}
function Find-Button([string[]]$names, [int]$processId=0, [string]$label='') {
    $automationId=Get-ButtonAutomationId $names $label
    if ($automationId) {
        $automationIdCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::AutomationIdProperty,$automationId)
        $pidAndAutomationId=[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId),$automationIdCondition)
        if ($automationId -in @('UpdatePrompt.Install','UpdatePrompt.Defer','Nav.settings','Settings.UpdateCheck')) {
            if (-not $script:startupPromptLookupMode) { return $null }
            if ($script:startupPromptLookupMode -eq 'main-window-automation-id') {
                $searchRoot=$script:startupPromptMainWindow
            } else {
                $searchRoot=$root
            }
            $item=$searchRoot.FindFirst($scope,$pidAndAutomationId)
        } else {
            $item=$root.FindFirst($scope,$pidAndAutomationId)
        }
        if ($item -and ($processId -le 0 -or $item.Current.ProcessId -eq $processId)) {
            $script:lastButtonLookup="AutomationId='$automationId' via=$($script:startupPromptLookupMode)"
            return $item
        }
        $script:lastButtonLookup="AutomationId='$automationId' miss"
        return $null
    }
    $pidCondition=$null
    if ($processId -gt 0) {
        $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    } else {
        $pidCondition=[Windows.Automation.Condition]::TrueCondition
    }
    $items=$root.FindAll($scope,$pidCondition)
    foreach ($name in $names) {
        foreach ($candidate in $items) {
            $candidateName=$candidate.Current.Name
            $candidateType=$candidate.Current.ControlType.ProgrammaticName
            if ($candidateType -eq 'ControlType.Button' -and $candidateName -eq $name) {
                if ($processId -gt 0) {
                    $candidateProcessId=$candidate.Current.ProcessId
                    if ($candidateProcessId -ne $processId) {
                        Log "Find-Button PID verification failed name='$candidateName' expected=$processId actual=$candidateProcessId"
                        continue
                    }
                }
                $script:lastButtonLookup = 'FindAll(PID)+dump-style Current Name/ProgrammaticName string filter'
                return $candidate
            }
        }
    }
    $script:lastButtonLookup = 'miss'
    return $null
}
function Wait-Window([int]$processId,[int]$seconds=30) {
    $windowType=[Windows.Automation.ControlType]::Window
    $condition=[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $until=(Get-Date).AddSeconds($seconds)
    do {
        $item=$root.FindFirst([Windows.Automation.TreeScope]::Children,$condition)
        if ($item) { return $item }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    throw "Timed out waiting for application main window (PID $processId)."
}
function Write-StartupPromptProbe([int]$processId) {
    if (-not $script:startupPromptProbeStart) { $script:startupPromptProbeStart=Get-Date }
    $elapsed=[math]::Round(((Get-Date)-$script:startupPromptProbeStart).TotalSeconds,1)
    $buttonName='下载并安装'
    $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    $elements=$root.FindAll($scope,$pidCondition)
    $dumpRows=[Collections.Generic.List[string]]::new()
    $firstPassButton=$null
    foreach ($candidate in $elements) {
        try {
            $candidateName=$candidate.Current.Name
            $candidateType=$candidate.Current.ControlType.ProgrammaticName
            $dumpRows.Add("$candidateType|$candidateName")
        } catch { $dumpRows.Add("<property-error:$($_.Exception.GetType().Name)>") }
    }
    $dumpButtons=@($dumpRows | Where-Object { $_ -match '^ControlType\.Button\|' })
    $dumpButtonsText=$dumpButtons -join '; '
    $dumpRowsText=$dumpRows -join ' || '
    $elementCount=$elements.Count
    Log "startup prompt probe elapsed_since_first_probe=${elapsed}s pass1-dump count=$elementCount buttons=$dumpButtonsText tree=$dumpRowsText"

    $exactMatches=[Collections.Generic.List[Windows.Automation.AutomationElement]]::new()
    foreach ($candidate in $elements) {
        try {
            if ($candidate.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and
                $candidate.Current.Name -eq $buttonName) {
                $exactMatches.Add($candidate)
                if (-not $firstPassButton) { $firstPassButton=$candidate }
            }
        } catch {
            Log "startup prompt probe pass2-property-error type=$($_.Exception.GetType().Name)"
        }
    }
    Log "startup prompt probe elapsed_since_first_probe=${elapsed}s pass2-string-match collectionCount=$($elements.Count) targetButton=$($exactMatches.Count -gt 0) matches=$($exactMatches.Count)"

    $broadMatches=[Collections.Generic.List[Windows.Automation.AutomationElement]]::new()
    foreach ($candidate in $elements) {
        try {
            $firstCurrent=$candidate.Current
            $candidateName=$firstCurrent.Name
            $candidateType=$firstCurrent.ControlType
            if ($candidateName.Contains('下载')) {
                $controlTypeEquals=$candidateType -eq $buttonType
                $nameEquals=$candidateName -eq $buttonName
                $processIdEquals=$firstCurrent.ProcessId -eq $processId
                $programmaticNameEquals=$firstCurrent.ControlType.ProgrammaticName -eq 'ControlType.Button'
                $secondCurrent=$candidate.Current
                $sameCurrentObject=[Object]::ReferenceEquals($firstCurrent,$secondCurrent)
                $codepointList=[Collections.Generic.List[string]]::new()
                for ($i=0; $i -lt $candidateName.Length; $i++) {
                    $codepoint=[int][char]$candidateName[$i]
                    if ([char]::IsHighSurrogate($candidateName[$i]) -and $i+1 -lt $candidateName.Length -and
                        [char]::IsLowSurrogate($candidateName[$i+1])) {
                        $codepoint=[char]::ConvertToUtf32($candidateName,$i)
                        $i++
                    }
                    $codepointList.Add(('U+{0:X4}' -f $codepoint))
                }
                $codepoints=$codepointList -join ','
                $automationId=$firstCurrent.AutomationId
                Log "startup prompt probe elapsed_since_first_probe=${elapsed}s pass3-candidate Name='$candidateName' NameLength=$($candidateName.Length) Codepoints=$codepoints ControlType=$($candidateType.ProgrammaticName) ProcessId=$($firstCurrent.ProcessId) AutomationId='$automationId' ControlTypeEquals=$controlTypeEquals NameEquals=$nameEquals ProcessIdEquals=$processIdEquals ProgrammaticNameEquals=$programmaticNameEquals CurrentReferenceEquals=$sameCurrentObject CurrentType=$($firstCurrent.GetType().FullName)"
                if ($controlTypeEquals -and $nameEquals -and $processIdEquals -and $programmaticNameEquals) {
                    $broadMatches.Add($candidate)
                }
            }
        } catch {
            Log "startup prompt probe elapsed_since_first_probe=${elapsed}s pass3-property-error type=$($_.Exception.GetType().Name)"
        }
    }

    $secondElements=$root.FindAll($scope,$pidCondition)
    $secondFindAllButton=$false
    foreach ($candidate in $secondElements) {
        try {
            if ($candidate.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and
                $candidate.Current.Name -eq $buttonName) { $secondFindAllButton=$true; break }
        } catch { }
    }
    Log "startup prompt probe elapsed_since_first_probe=${elapsed}s FindAll-count-comparison first=$($elements.Count) second=$($secondElements.Count) sameCount=$($elements.Count -eq $secondElements.Count) secondContainsButton=$secondFindAllButton"

    $windowType=[Windows.Automation.ControlType]::Window
    $mainWindowCondition=[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::Window),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $mainWindow=$root.FindFirst([Windows.Automation.TreeScope]::Children,$mainWindowCondition)
    $script:startupPromptMainWindow=$mainWindow
    $mainWindowName='<not found>'
    if ($mainWindow) { $mainWindowName=$mainWindow.Current.Name }
    $mainElements=$null
    $mainWindowButton=$null
    if ($mainWindow) {
        $mainElements=$mainWindow.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)
        foreach ($candidate in $mainElements) {
            try {
                if ($candidate.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and
                    $candidate.Current.Name -eq $buttonName -and $candidate.Current.ProcessId -eq $processId) {
                    $mainWindowButton=$candidate
                    break
                }
            } catch { }
        }
    }
    $installIdCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::AutomationIdProperty,'UpdatePrompt.Install')
    $installIdAndPid=[Windows.Automation.AndCondition]::new($installIdCondition,$pidCondition)
    $updateWindowCondition=[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,'USB Bridge Desk 更新'),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $topLevelWindowHit=$null -ne $root.FindFirst([Windows.Automation.TreeScope]::Children,$updateWindowCondition)
    $rootAutomationIdButton=$root.FindFirst($scope,$installIdAndPid)
    $mainAutomationIdButton=$null
    if ($mainWindow) { $mainAutomationIdButton=$mainWindow.FindFirst($scope,$installIdAndPid) }
    $deferIdCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::AutomationIdProperty,'UpdatePrompt.Defer')
    $deferIdAndPid=[Windows.Automation.AndCondition]::new($deferIdCondition,$pidCondition)
    $rootDeferButton=$root.FindFirst($scope,$deferIdAndPid)
    $mainDeferButton=$null
    if ($mainWindow) { $mainDeferButton=$mainWindow.FindFirst($scope,$deferIdAndPid) }
    if (-not $script:startupPromptLookupMode) {
        if ($mainAutomationIdButton) { $script:startupPromptLookupMode='main-window-automation-id' }
        elseif ($rootAutomationIdButton) { $script:startupPromptLookupMode='root-automation-id' }
    }
    Log "startup prompt probe elapsed_since_first_probe=${elapsed}s main-window-root count=$(if ($mainElements) {$mainElements.Count} else {0}) installAutomationIdRoot=$($null -ne $rootAutomationIdButton) installAutomationIdMainWindow=$($null -ne $mainAutomationIdButton) deferAutomationIdRoot=$($null -ne $rootDeferButton) deferAutomationIdMainWindow=$($null -ne $mainDeferButton) selectedLookup=$($script:startupPromptLookupMode)"
    $pidConditionForWindows=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    $windowByTypePid=$root.FindFirst([Windows.Automation.TreeScope]::Children,[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),$pidConditionForWindows))
    $windowByNamePid=$root.FindFirst([Windows.Automation.TreeScope]::Children,[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,'USB Bridge Desk 更新'),$pidConditionForWindows))
    $windowByNameOnly=$root.FindFirst([Windows.Automation.TreeScope]::Children,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,'USB Bridge Desk 更新'))
    if ($windowByTypePid) {
        $currentProperties='unavailable'
        $cachedProperties='unavailable'
        try {
            $current=$windowByTypePid.Current
            $currentProperties="type=$($current.ControlType.ProgrammaticName) name='$($current.Name)' pid=$($current.ProcessId) automationId='$($current.AutomationId)' class='$($current.ClassName)' hwnd=$($current.NativeWindowHandle) control=$($current.IsControlElement) content=$($current.IsContentElement) rect=$($current.BoundingRectangle)"
        } catch { $currentProperties="propertyReadError=$($_.Exception.GetType().Name):$($_.Exception.Message)" }
        try {
            $cached=$windowByTypePid.Cached
            $cachedProperties="type=$($cached.ControlType.ProgrammaticName) name='$($cached.Name)' pid=$($cached.ProcessId) automationId='$($cached.AutomationId)' class='$($cached.ClassName)' hwnd=$($cached.NativeWindowHandle) control=$($cached.IsControlElement) content=$($cached.IsContentElement) rect=$($cached.BoundingRectangle)"
        } catch { $cachedProperties="unavailable=$($_.Exception.GetType().Name):$($_.Exception.Message)" }
        $windowProperties="current[$currentProperties] cached[$cachedProperties]"
    } else { $windowProperties='<not found>' }
    Log "startup prompt probe elapsed_since_first_probe=${elapsed}s UpdateWindow=$topLevelWindowHit MainWindow='$mainWindowName' WindowTypePid=$($null -ne $windowByTypePid) WindowNamePid=$($null -ne $windowByNamePid) WindowNameOnly=$($null -ne $windowByNameOnly) typePidCurrent=[$windowProperties]"
    $parts = [Collections.Generic.List[Windows.Automation.Condition]]::new()
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$buttonType))
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,$buttonName))
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $hwndHits=@()
    foreach ($hwnd in [R5WindowProbe]::ForProcess($processId)) {
        $rect=[R5WindowProbe+Rect]::new()
        $rectAvailable=[R5WindowProbe]::GetWindowRect($hwnd,[ref]$rect)
        $visible=[R5WindowProbe]::IsWindowVisible($hwnd)
        $element=$null
        $fromHandleError='none'
        try { $element=[Windows.Automation.AutomationElement]::FromHandle($hwnd) }
        catch { $fromHandleError=$_.Exception.GetType().Name }
        $button=$null
        if ($element) {
            try { $button=$element.FindFirst([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.AndCondition]::new($parts.ToArray())) }
            catch { $fromHandleError="FindFirst:$($_.Exception.GetType().Name)" }
        }
        $title='<null>'
        if ($element) {
            try { $title=$element.Current.Name }
            catch { $title='<property error>' }
        }
        Log ("startup HWND probe hwnd=0x{0:X} visible={1} rectAvailable={2} rect={3},{4},{5},{6} FromHandle={7} fromHandleError={8} title='{9}' buttonFound={10}" -f $hwnd.ToInt64(),$visible,$rectAvailable,$rect.Left,$rect.Top,$rect.Right,$rect.Bottom,($null -ne $element),$fromHandleError,$title,($null -ne $button))
        if ($button) { $hwndHits+=,$button }
    }
    $script:lastStartupHwndButton=$hwndHits | Select-Object -First 1
    Log "startup prompt probe HWNDButton=$($null -ne $script:lastStartupHwndButton)"
}
function Wait-Button([string]$label,[string[]]$names,[int]$processId=0,[int]$seconds=20) {
    $until=(Get-Date).AddSeconds($seconds)
    $nextProbe=Get-Date
    do {
        if ($label -eq 'startup update prompt' -and (Get-Date) -ge $nextProbe) {
            Write-StartupPromptProbe $processId
            $nextProbe=(Get-Date).AddSeconds(5)
        }
        $item=Find-Button $names $processId $label
        if ($item) {
            if ($label -eq 'startup update prompt') {
                $openedAt=Get-StartupPromptOpenedAt
                $latencyBasis='first-probe-fallback'
                $latencyStart=$script:startupPromptProbeStart
                if ($openedAt) { $latencyBasis='app-Opened'; $latencyStart=$openedAt }
                $latency=[math]::Round(((Get-Date)-$latencyStart).TotalSeconds,1)
                $script:startupPromptLatency=$latency
                $script:startupPromptLatencyExceeded=$latency -gt 10
                Log "startup prompt first-hit timestamp=$(Get-Date -Format o) elapsed_since=$latencyBasis ${latency}s via=$script:lastButtonLookup acceptanceWithin10s=$(-not $script:startupPromptLatencyExceeded)"
                Write-StartupPromptProbe $processId
                Shot 'update-prompt-first-hit.png'
                Log "startup prompt first-hit screenshot timestamp=$(Get-Date -Format o) path=update-prompt-first-hit.png"
                Log "startup update prompt button found via=$script:lastButtonLookup"
            }
            return $item
        }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    if ($processId -gt 0) {
        $elements=$root.FindAll($scope,$pidCondition)
        $namesDump=@($elements | ForEach-Object {
            $elementName=$_.Current.Name
            $controlType=$_.Current.ControlType.ProgrammaticName
            if ($controlType -eq 'ControlType.Window') { "WINDOW title='$elementName'" }
            if ($controlType -eq 'ControlType.Button') { "BUTTON name='$elementName'" }
            if ($elementName) { "ELEMENT type=$controlType name='$elementName'" }
        } | Where-Object { $_ })
        $timeoutElementCount=$elements.Count
        $newLine="`n"
        $namesDumpText=$namesDump -join $newLine
        Log "UIA timeout dump for PID $processId ($label) elements=$timeoutElementCount`:`n$namesDumpText"
    } else {
        Log "UIA timeout dump unavailable for ${label}: no process ID was supplied."
    }
    Shot 'update-prompt-timeout.png'
    $nameSeparator=', '
    $namesText=$names -join $nameSeparator
    throw "Timed out waiting for $label ($namesText)."
}
function Click([Windows.Automation.AutomationElement]$item) {
    $pattern=$null
    if ($item.TryGetCurrentPattern($invoke,[ref]$pattern)) { $pattern.Invoke(); return }
    $selection=$null
    if ($item.TryGetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern,[ref]$selection)) { $selection.Select(); return }
    $item.SetFocus()
    [Windows.Forms.SendKeys]::SendWait('{ENTER}')
}
function Confirm-AppAutomationId([string]$automationId,[string]$label,[int]$processId) {
    $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    $elements=$root.FindAll($scope,$pidCondition)
    $matches=@($elements | Where-Object { $_.Current.AutomationId -ceq $automationId })
    if ($matches.Count -ne 1) {
        throw "Independent UIA enumeration found $($matches.Count) elements with AutomationId '$automationId' for $label."
    }
    $element=$matches[0]
    $controlType=$element.Current.ControlType.ProgrammaticName
    Log "Independent UIA enumeration label='$label' AutomationId='$automationId' ControlType=$controlType ProcessId=$($element.Current.ProcessId)"
    if ($label -eq 'Settings navigation' -and $controlType -ne 'ControlType.ListItem') {
        throw "Settings navigation AutomationId resolved to unexpected ControlType $controlType."
    }
    return $element
}
function Wait-HashFailure([int]$processId,[int]$seconds=60) {
    $until=(Get-Date).AddSeconds($seconds)
    $trace=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    $lastNames=@()
    $hasBanner=$false
    $hasFailureText=$false
    $traceConfirmed=$false
    $space=' '
    $nameSeparator=' | '
    $newLine="`n"
    do {
        # Reacquire the full UIA subtree every time; live peers can appear late.
        $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
        $elements=$root.FindAll($scope,$pidCondition)
        $lastNames=@($elements | ForEach-Object { $_.Current.Name } | Where-Object { $_ })
        $hasBanner=@($elements | Where-Object { $_.Current.AutomationId -ceq 'UpdateNotice' }).Count -gt 0
        $lastNamesText=$lastNames -join $space
        $hasFailureText=$lastNamesText -match 'SHA-256 校验失败，未启动安装程序'
        $traceText=''
        if (Test-Path -LiteralPath $trace) {
            $traceText=Get-Content -LiteralPath $trace -Raw
        }
        $tracePrefix='Update check/download failed: '
        $traceFailure=[regex]::Escape('System.IO.InvalidDataException: 更新包 SHA-256 校验失败，未启动安装程序。')
        $tracePattern=$tracePrefix + $traceFailure
        $traceConfirmed=$traceText -match $tracePattern
        if ($hasBanner -and $hasFailureText -and $traceConfirmed) {
            $closeCondition=[Windows.Automation.AndCondition]::new([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId),[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::AutomationIdProperty,'UpdateNotice.Close'))
            $close=$root.FindFirst($scope,$closeCondition)
            if ($close) {
                Log "Wrong SHA-256 rejection confirmed: UpdateNotice AutomationId present, UIA failure text visible, and startup trace records InvalidDataException."
                return $close
            }
        }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $until)
    $lastNamesJoined=$lastNames -join $nameSeparator
    Log "Wrong SHA-256 rejection timeout: banner=$hasBanner UIAText=$hasFailureText trace=$traceConfirmed names=$lastNamesJoined"
    $lastNamesDump=$lastNames -join $newLine
    Log "UIA timeout dump for PID $processId (SHA-256 failure):`n$lastNamesDump"
    Shot 'update-hash-failure-timeout.png'
    throw "Timed out waiting for SHA-256 failure banner, text, and application trace ($seconds seconds)."
}
function Shot([string]$name) {
    $bounds=[Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp=[Drawing.Bitmap]::new($bounds.Width,$bounds.Height)
    $g=[Drawing.Graphics]::FromImage($bmp)
    try { $g.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size); $bmp.Save((Join-Path $OutDir $name),[Drawing.Imaging.ImageFormat]::Png) }
    finally { $g.Dispose(); $bmp.Dispose() }
}
function Set-Manifest([string]$hash) {
    $json=@{latest_version='9.9.9';download_url=($FixtureUrl.TrimEnd('/')+'/USB-Bridge-Desk-R5-1.3.0-x64.exe');sha256=$hash;release_notes='Windows updater acceptance fixture'} | ConvertTo-Json
    [IO.File]::WriteAllText((Join-Path (Split-Path $log) 'version.json'),$json,[Text.UTF8Encoding]::new($false))
}
function Check-Update([int]$processId) {
    $settings=Wait-Button 'Settings navigation' @('设置') $processId
    Confirm-AppAutomationId 'Nav.settings' 'Settings navigation' $processId | Out-Null
    Click $settings
    $check=Wait-Button 'settings update check' @('检查更新') $processId
    Confirm-AppAutomationId 'Settings.UpdateCheck' 'settings update check' $processId | Out-Null
    Click $check
    return Wait-Button 'new version dialog' @('下载并安装') $processId
}
try {
    $validHash=(Get-FileHash -LiteralPath $InstallerPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $fixtureRoot=Split-Path $log
    Copy-Item -LiteralPath $InstallerPath -Destination (Join-Path $fixtureRoot 'USB-Bridge-Desk-R5-1.3.0-x64.exe') -Force
    Set-Manifest $validHash
    $env:USB_BRIDGE_DESK_UPDATE_URL=$FixtureUrl.TrimEnd('/')+'/version.json'
    $app=Start-Process -FilePath $AppPath -PassThru
    $null=Wait-Window $app.Id
    $prompt=Wait-Button 'startup update prompt' @('下载并安装') $app.Id 90
    Shot 'update-available.png'
    Log 'New-version prompt visible at startup; download button has not been clicked.'
    Click (Wait-Button 'defer update' @('稍后') $app.Id)
    $prompt=Check-Update $app.Id
    $requests=Join-Path $fixtureRoot 'requests.log'
    if ((Test-Path $requests) -and (Get-Content $requests -Raw) -match 'USB-Bridge-Desk-R5-1.3.0-x64.exe') {
        throw 'Installer download began before the user chose 下载并安装.'
    }
    Log 'Settings check showed the update; server log confirms no installer download before explicit choice.'
    Click (Wait-Button 'defer settings update' @('稍后') $app.Id)
    Shot 'settings-update-result.png'

    Set-Manifest ('0' * 64)
    $prompt=Check-Update $app.Id
    Click $prompt
    $failure=Wait-HashFailure $app.Id 60
    Shot 'update-hash-failure.png'
    Log 'Wrong SHA-256 manifest was rejected and the UI reported verification failure.'
    Click $failure

    Set-Manifest $validHash
    $prompt=Check-Update $app.Id
    Click $prompt
    if (-not $app.WaitForExit(30000)) { throw 'Application did not exit after handing the verified installer to Windows.' }
    $deadline=(Get-Date).AddSeconds(30)
    $installerProcess=$null
    do {
        $installerProcess=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'USB-Bridge-Desk-*.exe' -and $_.ExecutablePath -ne $AppPath } | Select-Object -First 1
        if ($installerProcess) { break }
        Start-Sleep -Milliseconds 250
    } while ((Get-Date) -lt $deadline)
    if (-not $installerProcess) { throw 'Verified update download did not launch the downloaded installer.' }
    Log "Correct SHA-256 download launched installer PID $($installerProcess.ProcessId)."
    Stop-Process -Id $installerProcess.ProcessId -Force
    $downloaded=Get-Content $requests -Raw
    if ($downloaded -notmatch 'USB-Bridge-Desk-R5-1.3.0-x64.exe') { throw 'Fixture server did not record the installer download.' }
    Log 'Verified installer was downloaded and launched; setup process was stopped before modifying the installation.'
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue

    $app=Start-Process -FilePath $AppPath -PassThru
    Start-Sleep -Seconds 3
    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $liveConfirm=Wait-Button 'running-app uninstall confirmation' @('是','Yes') $un.Id 30
    Click $liveConfirm
    $ok=Wait-Button 'live-app uninstall guard dialog' @('确定','OK') $un.Id 30
    Shot 'uninstall-running-app-guard.png'
    $guardItems=$root.FindAll($scope,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$un.Id))
    $guardText=(@($guardItems | ForEach-Object { $_.Current.Name }) -join ' ')
    if ($guardText -notmatch '请先关闭 USB Bridge Desk') { throw 'Running-app guard dialog did not show its expected Chinese message.' }
    Log 'Running-app uninstall guard dialog captured and asserted in Simplified Chinese.'
    Click $ok
    if (-not $un.WaitForExit(10000)) { Stop-Process -Id $un.Id -Force }
    Stop-Process -Id $app.Id -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2

    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $yes=Wait-Button 'uninstall confirmation' @('是','Yes') $un.Id 30
    Shot 'uninstall-confirmation.png'
    Log 'Uninstall confirmation dialog captured in Simplified Chinese.'
    Click $yes
    if (-not $un.WaitForExit(300000)) { throw 'Uninstaller did not finish within five minutes.' }
    $installDir=Split-Path $AppPath
    if (Test-Path -LiteralPath $installDir) { throw "Application installation directory remains after uninstall: $installDir" }
    Log 'Uninstall completed and application installation directory is absent.'
    if ($script:startupPromptLatencyExceeded) {
        Log "ACCEPTANCE FAILURE: startup update button first appeared after $($script:startupPromptLatency)s; required latency is <=10s after Opened. UIA black hole remains although updater and uninstall completed."
        throw "UIA startup prompt latency exceeded 10 seconds ($($script:startupPromptLatency)s); full flow completed but acceptance failed."
    }
    Log "ACCEPTANCE PASS: startup update button first appeared after $($script:startupPromptLatency)s (required <=10s)."
} finally {
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue
}
