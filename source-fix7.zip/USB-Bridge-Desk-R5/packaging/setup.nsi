; SPDX-License-Identifier: GPL-3.0-only
Unicode true
!pragma encoding UTF-8
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"

Name "USB Bridge Desk"
InstallDir "$PROGRAMFILES64\USB Bridge Desk"
OutFile "..\release\USB-Bridge-Desk-R5-1.3.0-x64.exe"
RequestExecutionLevel admin
BrandingText "USB Bridge Desk"
SetCompressor /SOLID lzma
SetCompressorDictSize 32
ShowInstDetails show
ShowUninstDetails show
Icon "icon.ico"
UninstallIcon "icon.ico"
VIProductVersion "1.3.0.0"
VIAddVersionKey /LANG=2052 "ProductName" "USB Bridge Desk"
VIAddVersionKey /LANG=2052 "FileDescription" "USB Bridge Desk x64 Setup"
VIAddVersionKey /LANG=2052 "ProductVersion" "1.3.0"
VIAddVersionKey /LANG=2052 "FileVersion" "1.3.0"
VIAddVersionKey /LANG=2052 "LegalCopyright" "USB Bridge Desk contributors"
!define MUI_ABORTWARNING
!define KEY "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\USBBridgeDesk"
!define MUI_FINISHPAGE_NOAUTOCLOSE
!define MUI_UNFINISHPAGE_NOAUTOCLOSE
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH
!insertmacro MUI_LANGUAGE "SimpChinese"
!insertmacro MUI_LANGUAGE "English"

LangString NeedX64 ${LANG_SIMPCHINESE} "此安装包需要原生 x64 Windows 10 22H2 或 Windows 11。"
LangString NeedX64 ${LANG_ENGLISH} "This installer requires native x64 Windows 10 22H2 or Windows 11."
LangString CloseApp ${LANG_SIMPCHINESE} "请先关闭 USB Bridge Desk，然后重试。"
LangString CloseApp ${LANG_ENGLISH} "Close USB Bridge Desk, then try again."
LangString Checking ${LANG_SIMPCHINESE} "正在检查系统与已安装的 USB/IP 组件…"
LangString Checking ${LANG_ENGLISH} "Checking Windows and installed USB/IP components..."
LangString Provision ${LANG_SIMPCHINESE} "正在安装共享服务和虚拟 USB 控制器…"
LangString Provision ${LANG_ENGLISH} "Installing the USB/IP host service and virtual USB controller..."
LangString ProvisionError ${LANG_SIMPCHINESE} "USB/IP 组件安装未完成。请查看 %TEMP%\usb-bridge-*.log。"
LangString ProvisionError ${LANG_ENGLISH} "USB/IP component setup did not finish. See %TEMP%\usb-bridge-*.log."
LangString Removing ${LANG_SIMPCHINESE} "正在卸载此安装包安装的 USB/IP 组件…"
LangString Removing ${LANG_ENGLISH} "Removing the USB/IP components installed by this package..."
LangString RemovalError ${LANG_SIMPCHINESE} "USB/IP 组件卸载未完成。请结束 USB 读写后重试。"
LangString RemovalError ${LANG_ENGLISH} "USB/IP removal did not finish. End active USB transfers, then retry."

Function .onInit
  ${IfNot} ${IsNativeAMD64}
    MessageBox MB_ICONSTOP "$(NeedX64)"
    SetErrorLevel 2
    Quit
  ${EndIf}
  SetRegView 64
  ReadRegDWORD $0 HKLM "SOFTWARE\Microsoft\Windows NT\CurrentVersion" "CurrentMajorVersionNumber"
  ReadRegStr $1 HKLM "SOFTWARE\Microsoft\Windows NT\CurrentVersion" "CurrentBuildNumber"
  ${If} $0 != 10
  ${OrIf} $1 < 19045
    MessageBox MB_ICONSTOP "$(NeedX64)"
    SetErrorLevel 2
    Quit
  ${EndIf}
  StrCpy $INSTDIR "$PROGRAMFILES64\USB Bridge Desk"
  SetShellVarContext all
FunctionEnd

; Use the true 64-bit Windows PowerShell from the NSIS x86 stub.
!macro Powershell Mode Args
  nsExec::ExecToStack '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${Args}" -Mode ${Mode}'
  Pop $R0
  Pop $R1
  DetailPrint "$R1"
!macroend

Section "USB Bridge Desk"
  DetailPrint "$(Checking)"
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File "provision.ps1"
  !insertmacro Powershell check "$PLUGINSDIR\provision.ps1"
  ${If} $R0 != "0"
    IfSilent +2
    MessageBox MB_ICONSTOP "$R1"
    SetErrorLevel 2
    Quit
  ${EndIf}

  File "runtimes.ps1"
  DetailPrint "Checking .NET Desktop Runtime 10 and Windows App Runtime 1.8..."
  nsExec::ExecToStack '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$PLUGINSDIR\runtimes.ps1"'
  Pop $R0
  Pop $R1
  DetailPrint "$R1"
  ${If} $R0 != "0"
    IfSilent +2
    MessageBox MB_ICONSTOP "$R1"
    SetErrorLevel 2
    Quit
  ${EndIf}
  SetOutPath "$INSTDIR"
  File /r "..\build\stage\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "${KEY}" "DisplayName" "USB Bridge Desk"
  WriteRegStr HKLM "${KEY}" "DisplayVersion" "1.3.0"
  WriteRegStr HKLM "${KEY}" "Publisher" "USB Bridge Desk contributors"
  WriteRegStr HKLM "${KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "${KEY}" "DisplayIcon" "$INSTDIR\UsbBridgeDesk.exe"
  WriteRegStr HKLM "${KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKLM "${KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${KEY}" "NoRepair" 1
  DetailPrint "$(Provision)"
  !insertmacro Powershell install "$INSTDIR\resources\engines\provision.ps1"
  ${If} $R0 != "0"
    IfSilent +2
    MessageBox MB_ICONSTOP "$(ProvisionError)$\r$\n$R1"
    SetErrorLevel 2
    Quit
  ${EndIf}
  CreateShortCut "$SMPROGRAMS\USB Bridge Desk.lnk" "$INSTDIR\UsbBridgeDesk.exe"
SectionEnd

Function un.onInit
  SetRegView 64
  SetShellVarContext all
  StrCpy $INSTDIR "$PROGRAMFILES64\USB Bridge Desk"
FunctionEnd

Section "Uninstall"
  DetailPrint "$(Removing)"
  !insertmacro Powershell uninstall "$INSTDIR\resources\engines\provision.ps1"
  ${If} $R0 != "0"
    IfSilent +2
    MessageBox MB_ICONSTOP "$(RemovalError)$\r$\n$R1"
    SetErrorLevel 2
    Quit
  ${EndIf}
  Delete "$SMPROGRAMS\USB Bridge Desk.lnk"
  DeleteRegKey HKLM "${KEY}"
  SetOutPath "$PROGRAMFILES64"
  RMDir /r /REBOOTOK "$INSTDIR"
SectionEnd
