// SPDX-License-Identifier: GPL-3.0-only
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace UsbBridge;

public sealed record UpdateManifest(
    [property: JsonPropertyName("latest_version")] string LatestVersion,
    [property: JsonPropertyName("download_url")] Uri DownloadUrl,
    [property: JsonPropertyName("sha256")] string Sha256,
    [property: JsonPropertyName("release_notes")] string? ReleaseNotes
);

public static class UpdateLogic
{
    public static string ValidateSha256(string value)
    {
        if (value is null || value.Length != 64 || !value.All(Uri.IsHexDigit))
            throw new InvalidDataException("更新包 SHA-256 格式无效。");
        return value.ToUpperInvariant();
    }

    public static UpdateManifest ParseManifest(string json)
    {
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;
        var latest = root.GetProperty("latest_version").GetString() ?? "";
        var download = new Uri(root.GetProperty("download_url").GetString() ?? "", UriKind.Absolute);
        var hash = root.GetProperty("sha256").GetString() ?? "";
        var notes = root.TryGetProperty("release_notes", out var notesElement) ? notesElement.GetString() : null;
        var m = new UpdateManifest(latest, download, hash, notes);
        if (!Version.TryParse(m.LatestVersion, out _))
            throw new InvalidDataException("更新版本号无效。");
        if (m.DownloadUrl.Scheme != Uri.UriSchemeHttps)
            throw new InvalidDataException("更新下载地址必须使用 HTTPS。");
        ValidateSha256(m.Sha256);
        if (string.IsNullOrWhiteSpace(m.ReleaseNotes))
            m = m with { ReleaseNotes = "此版本包含稳定性与兼容性改进。" };
        return m;
    }

    public static bool IsNewer(string current, string candidate) =>
        Version.TryParse(current, out var installed)
        && Version.TryParse(candidate, out var offered)
        && offered > installed;

    public static bool HasSha256(string path, string expected)
    {
        try
        {
            return CryptographicOperations.FixedTimeEquals(
                Convert.FromHexString(ValidateSha256(expected)), SHA256.HashData(File.ReadAllBytes(path))
            );
        }
        catch (InvalidDataException) { return false; }
    }
}

public sealed class UpdateClient
{
    public static readonly Uri ManifestUri = new("https://ppt-auto-bakeup.cnnb.dpdns.org/usb/version.json");
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(20) };

    public async Task<UpdateManifest> CheckAsync(CancellationToken token = default)
    {
        return await CheckAsync(ManifestUri, token);
    }

    public async Task<UpdateManifest> CheckAsync(Uri manifestUri, CancellationToken token = default)
    {
        var json = await Http.GetStringAsync(manifestUri, token);
        return UpdateLogic.ParseManifest(json);
    }

    public async Task<string> DownloadVerifiedAsync(UpdateManifest manifest, CancellationToken token = default)
    {
        if (manifest.DownloadUrl.Scheme != Uri.UriSchemeHttps)
            throw new InvalidDataException("更新下载地址必须使用 HTTPS。");
        UpdateLogic.ValidateSha256(manifest.Sha256);
        var path = Path.Combine(Path.GetTempPath(), $"USB-Bridge-Desk-{Guid.NewGuid():N}.exe");
        try
        {
            await using (var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true))
            await using (var input = await Http.GetStreamAsync(manifest.DownloadUrl, token))
                await input.CopyToAsync(output, token);
            if (!UpdateLogic.HasSha256(path, manifest.Sha256))
                throw new InvalidDataException("更新包 SHA-256 校验失败，未启动安装程序。");
            return path;
        }
        catch
        {
            try { File.Delete(path); } catch (IOException) { }
            throw;
        }
    }

}
