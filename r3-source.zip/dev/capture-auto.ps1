﻿# SPDX-License-Identifier: GPL-3.0-only
# Run in the interactive Windows runner session after installing the product.
param([Parameter(Mandatory=$true)][string]$AppPath, [string]$OutDir=(Join-Path $PWD 'screenshots'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing,UIAutomationClient,UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class DeskCapture {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hwnd, int key, out Rect rect, int size);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr info);
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls,string title);
}
'@
[void][DeskCapture]::SetThreadDpiAwarenessContext([IntPtr](-4))
New-Item -ItemType Directory -Force $OutDir | Out-Null
$logFile = Join-Path $OutDir 'driver.log'
$shots = [Collections.Generic.List[object]]::new()
$failures = [Collections.Generic.List[string]]::new()
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$prop = [Windows.Automation.AutomationElement]
$inv = [Windows.Automation.InvokePattern]::Pattern
$sel = [Windows.Automation.SelectionItemPattern]::Pattern
$selList = [Windows.Automation.SelectionPattern]::Pattern
$expand = [Windows.Automation.ExpandCollapsePattern]::Pattern
$proc = $null
$backdrop = $null
$alive = $false
$clean = $false
$forced = $false
$exitCode = $null
function Log([string]$text) {
    $line = "$(Get-Date -Format HH:mm:ss) $text"
    Write-Host $line
    Add-Content -LiteralPath $logFile -Encoding UTF8 -Value $line
}
function Wait-For([string]$description, [scriptblock]$probe, [int]$seconds=10) {
    $timer = [Diagnostics.Stopwatch]::StartNew()
    do {
        if ($proc -and $proc.HasExited) { throw "App exited ($($proc.ExitCode)) while waiting for $description" }
        [Windows.Forms.Application]::DoEvents()
        try { $probeResult = & $probe; if ($probeResult) { return $probeResult } }
        catch [Windows.Automation.ElementNotAvailableException] {}
        Start-Sleep -Milliseconds 150
    } while ($timer.Elapsed.TotalSeconds -lt $seconds)
    throw "Timed out waiting for $description"
}
function By-Property($element,$property,$value) {
    $condition = [Windows.Automation.PropertyCondition]::new($property,$value)
    return $element.FindFirst($scope,$condition)
}
function By-ID($id) { return By-Property $win $prop::AutomationIdProperty $id }
function Click-Element($item,[bool]$right=$false) {
    $point = $item.GetClickablePoint()
    if (-not [DeskCapture]::SetCursorPos([int]$point.X,[int]$point.Y)) { throw 'Cannot position pointer on interactive desktop' }
    if ($right) { $down=8; $up=16 } else { $down=2; $up=4 }
    [DeskCapture]::mouse_event($down,0,0,0,[UIntPtr]::Zero)
    [DeskCapture]::mouse_event($up,0,0,0,[UIntPtr]::Zero)
}
function Navigate($id,$heading) {
    $item = Wait-For "navigation $id" { By-ID "Nav.$id" }
    $p = $null
    if ($item.TryGetCurrentPattern($inv,[ref]$p)) { $p.Invoke() }
    elseif ($item.TryGetCurrentPattern($sel,[ref]$p)) { $p.Select() }
    else { Click-Element $item }
    [void](Wait-For "page $heading" { $h = By-ID 'PageHeading'; $h -and $h.Current.Name -eq $heading })
}
function Select-Setting($id,$value) {
    $combo = Wait-For "combo $id" { By-ID "Settings.$id" }
    $combo.GetCurrentPattern($expand).Expand()
    $condition = [Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,$value),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::ListItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
    $option = Wait-For "option $value" {
        $o=$win.FindFirst($scope,$condition)
        if (-not $o) { $o=$root.FindFirst($scope,$condition) }
        $o
    }
    $option.GetCurrentPattern($sel).Select()
    # Applying a theme rebuilds the settings page. Reacquire the UIA peer.
    [void](Wait-For "selected $value" {
        $c=By-ID "Settings.$id"
        if ($c) {
            $choices=$c.GetCurrentPattern($selList).Current.GetSelection()
            $choices.Count -gt 0 -and $choices[0].Current.Name -eq $value
        }
    })
    $c=By-ID "Settings.$id"
    $p=$c.GetCurrentPattern($expand)
    if ($p.Current.ExpandCollapseState -eq 'Expanded') { $p.Collapse() }
}
function Save-Shot($name,$label,[Drawing.Rectangle]$bounds) {
    if ($bounds.Width -le 0 -or $bounds.Height -le 0) { throw "Empty capture bounds: $name" }
    $image=[Drawing.Bitmap]::new($bounds.Width,$bounds.Height)
    try {
        $g=[Drawing.Graphics]::FromImage($image)
        try { $g.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size) } finally { $g.Dispose() }
        $file=Join-Path $OutDir "$name.png"
        $image.Save($file,[Drawing.Imaging.ImageFormat]::Png)
    } finally { $image.Dispose() }
    $hash=(Get-FileHash -LiteralPath $file).Hash
    $shots.Add(@{file="$name.png";label=$label;sha256=$hash;captured=(Get-Date -Format o)})
    Log "SHOT $name $hash"
}
function Window-Shot($name,$label) {
    Start-Sleep -Milliseconds 800
    $r=[DeskCapture+Rect]::new()
    if ([DeskCapture]::DwmGetWindowAttribute($hwnd,9,[ref]$r,16) -ne 0) { throw 'Cannot read DWM bounds' }
    Save-Shot $name $label ([Drawing.Rectangle]::FromLTRB($r.Left,$r.Top,$r.Right,$r.Bottom))
}
function Shell-Window($class) {
    $h=[DeskCapture]::FindWindow($class,$null)
    if ($h -ne [IntPtr]::Zero) { return [Windows.Automation.AutomationElement]::FromHandle($h) }
}
function Find-Icon($parent) {
    if (-not $parent) { return }
    foreach ($el in $parent.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        if ($el.Current.Name -like 'USB Bridge Desk*' -and -not $el.Current.IsOffscreen -and $el.Current.BoundingRectangle.Width -gt 0) { return $el }
    }
}
function Open-TrayMenu {
    $bar=Wait-For 'Explorer taskbar' { Shell-Window 'Shell_TrayWnd' }
    $icon=Find-Icon $bar
    if (-not $icon) {
        $chevron=By-Property $bar $prop::AutomationIdProperty 'SystemTrayIcon'
        if (-not $chevron -or $chevron.Current.Name -notmatch 'hidden|overflow') {
            $chevron=By-Property $bar $prop::NameProperty 'Show hidden icons'
        }
        if (-not $chevron) { $chevron=By-Property $bar $prop::NameProperty 'Show Hidden Icons' }
        if (-not $chevron) { throw 'Notification overflow button unavailable' }
        Click-Element $chevron
        $icon=Wait-For 'USB Bridge Desk in notification overflow' {
            foreach ($class in 'TopLevelWindowForOverflowXamlIsland','NotifyIconOverflowWindow') {
                $found=Find-Icon (Shell-Window $class)
                if ($found) { return $found }
            }
        }
    }
    Click-Element $icon $true
    $condition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,'退出'),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::MenuItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
    return Wait-For 'application tray exit command' { $root.FindFirst($scope,$condition) }
}
$started=Get-Date
try {
    $resolved=(Resolve-Path -LiteralPath $AppPath).Path
    $exeHash=(Get-FileHash $resolved).Hash
    $dllHash=(Get-FileHash (Join-Path (Split-Path $resolved) 'UsbBridgeDesk.dll')).Hash
    $backdrop=[Windows.Forms.Form]::new()
    $backdrop.FormBorderStyle='None'
    $backdrop.WindowState='Maximized'
    $backdrop.ShowInTaskbar=$false
    $backdrop.Add_Paint({
        param($form,$e)
        $brush=[Drawing.Drawing2D.LinearGradientBrush]::new($form.ClientRectangle,[Drawing.Color]::Teal,[Drawing.Color]::DarkOrange,30.0)
        try { $e.Graphics.FillRectangle($brush,$form.ClientRectangle) } finally { $brush.Dispose() }
    })
    $backdrop.Show()
    [Windows.Forms.Application]::DoEvents()
    $started=Get-Date
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $proc=Start-Process -FilePath $resolved -PassThru
    $hwnd=Wait-For 'native main window' {
        $proc.Refresh()
        if ($proc.MainWindowHandle -ne [IntPtr]::Zero) { $proc.MainWindowHandle }
    } 60
    $win=[Windows.Automation.AutomationElement]::FromHandle($hwnd)
    [void][DeskCapture]::SetForegroundWindow($hwnd)
    Navigate 'home' '连接概览'
    Window-Shot '01-overview' 'overview'
    while ($timer.Elapsed.TotalSeconds -lt 30 -and -not $proc.HasExited) {
        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
    }
    $alive=-not $proc.HasExited
    if (-not $alive) { throw 'App exited before 30 seconds' }
    Log 'ALIVE30 true'
    Navigate 'host' '共享本机 USB'; Window-Shot '02-local' 'host'
    Navigate 'client' '连接远端 USB'; Window-Shot '03-remote' 'client'
    Navigate 'maps' '映射列表'; Window-Shot '04-mappings' 'mappings'
    Navigate 'settings' '设置'
    Select-Setting 'theme' '黑夜'; Select-Setting 'material' '亚克力'
    Window-Shot '05-dark-acrylic' 'settings dark / acrylic selected'
    Navigate 'home' '连接概览'; Window-Shot '06-dark-overview' 'overview dark / acrylic selected'
    $exitItem=Open-TrayMenu
    Start-Sleep -Milliseconds 350
    Save-Shot '07-tray' 'tray menu' ([Windows.Forms.Screen]::FromPoint([Windows.Forms.Cursor]::Position).Bounds)
    $exitItem.GetCurrentPattern($inv).Invoke()
    $clean=$proc.WaitForExit(15000) -and $proc.ExitCode -eq 0
    if (-not $clean) { throw 'Tray exit did not finish successfully' }
} catch {
    $failures.Add($_.Exception.Message)
    Log "FAIL $($_.Exception.Message)"
} finally {
    if ($proc -and -not $proc.HasExited) { $proc.Kill(); $proc.WaitForExit(); $forced=$true }
    if ($proc -and $proc.HasExited) { $exitCode=$proc.ExitCode }
    if ($backdrop) { $backdrop.Dispose() }
    $logSrc=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (Test-Path $logSrc) { Copy-Item $logSrc $OutDir -Force }
    @{os=[Environment]::OSVersion.Version.ToString();appPath=$AppPath;appSha256=$exeHash;
      managedAppSha256=$dllHash;launched=$started.ToString('o');alive30s=$alive;exitClean=$clean;
      forcedExit=$forced;exitCode=$exitCode;screenshots=$shots.ToArray();failures=$failures.ToArray()} |
      ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $OutDir 'capture.json')
}
if ($failures.Count -or $shots.Count -ne 7 -or -not $alive -or -not $clean) { exit 1 }
exit 0
