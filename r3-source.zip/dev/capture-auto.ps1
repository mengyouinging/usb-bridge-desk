# SPDX-License-Identifier: GPL-3.0-only
# Automated R3 acceptance driver: launches the app, verifies 30 s survival,
# walks the main pages, switches to dark + acrylic, captures the tray menu,
# then exits cleanly via the tray menu. No human input.
param(
    [Parameter(Mandatory = $true)][string]$AppPath,
    [string]$OutDir = (Join-Path $PWD 'screenshots')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, UIAutomationClient, UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class Win32 {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int k, out Rect r, int n);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, UIntPtr e);
    public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
    public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
}
'@
$logFile = Join-Path $OutDir 'driver.log'
$failures = [System.Collections.Generic.List[string]]::new()
$shots = [System.Collections.Generic.List[object]]::new()
function Log($m) {
    $line = "$(Get-Date -Format 'HH:mm:ss') $m"
    Write-Output $line
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
}
New-Item -ItemType Directory -Force $OutDir | Out-Null
New-Item -ItemType File -Force $logFile | Out-Null
function Fail($m) { $failures.Add($m); Log "FAIL: $m" }
function Shot-Window($proc, $name, $label) {
    $rect = New-Object Win32+Rect
    if ([Win32]::DwmGetWindowAttribute($proc.MainWindowHandle, 9, [ref]$rect, 16) -ne 0) { Fail "cannot read window rect for $name"; return $null }
    $w = $rect.Right - $rect.Left; $h = $rect.Bottom - $rect.Top
    if ($w -le 0 -or $h -le 0) { Fail "empty window rect for $name"; return $null }
    $bmp = New-Object Drawing.Bitmap $w, $h
    $g = [Drawing.Graphics]::FromImage($bmp)
    try { $g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bmp.Size) } finally { $g.Dispose() }
    $file = Join-Path $OutDir ($name + '.png')
    $bmp.Save($file, [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
    $sha = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    $shots.Add(@{ file = $name + '.png'; label = $label; sha256 = $sha; captured = (Get-Date -Format o) })
    Log "SHOT $name ${w}x${h} sha256=$sha"
    return $file
}
function Shot-Screen($name, $label) {
    $b = [Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp = New-Object Drawing.Bitmap $b.Width, $b.Height
    $g = [Drawing.Graphics]::FromImage($bmp)
    try { $g.CopyFromScreen($b.Location, [Drawing.Point]::Empty, $bmp.Size) } finally { $g.Dispose() }
    $file = Join-Path $OutDir ($name + '.png')
    $bmp.Save($file, [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
    $sha = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    $shots.Add(@{ file = $name + '.png'; label = $label; sha256 = $sha; captured = (Get-Date -Format o) })
    Log "SHOT $name ${b.Width}x${b.Height} sha256=$sha"
    return $file
}
function Find-UIA($root, $type, $name) {
    $cond = [System.Windows.Automation.Condition]::TrueCondition
    if ($type) { $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $type) }
    if ($name) {
        $nc = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty, $name)
        $cond = New-Object System.Windows.Automation.AndCondition($cond, $nc)
    }
    return $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond)
}
function Find-AllUIA($root, $type) {
    $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $type)
    return $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
}
function Select-Nav($win, $name) {
    for ($i = 0; $i -lt 10; $i++) {
        $item = Find-UIA $win ([System.Windows.Automation.ControlType]::ListItem) $name
        if ($item) {
            try {
                $pat = $item.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
                $pat.Select()
                Log "NAV $name"
                return $true
            } catch { Start-Sleep -Milliseconds 500 }
        } else { Start-Sleep -Milliseconds 500 }
    }
    Fail "nav item not found: $name"
    return $false
}
function Select-ComboValue($win, $currentValue, $target) {
    $combos = Find-AllUIA $win ([System.Windows.Automation.ControlType]::ComboBox)
    foreach ($c in $combos) {
        try { $val = $c.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Value } catch { $val = '' }
        if ($val -ne $currentValue) { continue }
        try {
            $c.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
        } catch { Fail "cannot expand combo ($currentValue)"; return $false }
        Start-Sleep -Milliseconds 700
        $opt = $null
        for ($i = 0; $i -lt 10 -and -not $opt; $i++) {
            $opt = Find-UIA $win ([System.Windows.Automation.ControlType]::ListItem) $target
            if (-not $opt) { Start-Sleep -Milliseconds 500 }
        }
        if (-not $opt) { Fail "combo option not found: $target"; return $false }
        try {
            $opt.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select()
        } catch { Fail "cannot select combo option: $target"; return $false }
        Start-Sleep -Milliseconds 800
        try { $after = $c.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Value } catch { $after = '' }
        if ($after -eq $target) { Log "COMBO $currentValue -> $target"; return $true }
        Fail "combo value after select is '$after', want '$target'"
        return $false
    }
    Fail "combo with value '$currentValue' not found"
    return $false
}
function Avg-Brightness($file) {
    $bmp = [Drawing.Bitmap]::FromFile($file)
    $small = New-Object Drawing.Bitmap $bmp, 32, 18
    $sum = 0; $n = 0
    for ($x = 0; $x -lt 32; $x++) { for ($y = 0; $y -lt 18; $y++) { $c = $small.GetPixel($x, $y); $sum += ($c.R + $c.G + $c.B) / 3; $n++ } }
    $small.Dispose(); $bmp.Dispose()
    return [math]::Round($sum / $n, 1)
}

# --- colorful backdrop so acrylic has something to show through ---
$backdrop = $null
try {
    $bmp = New-Object Drawing.Bitmap 1920, 1080
    $g = [Drawing.Graphics]::FromImage($bmp)
    $cols = @([Drawing.Color]::Crimson, [Drawing.Color]::Gold, [Drawing.Color]::Teal, [Drawing.Color]::RoyalBlue, [Drawing.Color]::ForestGreen, [Drawing.Color]::DarkOrange)
    for ($i = 0; $i -lt 6; $i++) { $g.FillRectangle((New-Object Drawing.SolidBrush $cols[$i]), ($i * 320), 0, 320, 1080) }
    $font = New-Object Drawing.Font 'Segoe UI', 72, ([Drawing.FontStyle]::Bold)
    $g.DrawString('BACKDROP', $font, [Drawing.Brushes]::White, 480, 480)
    $g.Dispose()
    $backdrop = New-Object Windows.Forms.Form
    $backdrop.FormBorderStyle = 'None'
    $backdrop.WindowState = 'Maximized'
    $backdrop.BackgroundImage = $bmp
    $backdrop.BackgroundImageLayout = 'Stretch'
    $backdrop.Show()
    [Windows.Forms.Application]::DoEvents()
    Log 'BACKDROP shown'
} catch { Log "backdrop skipped: $($_.Exception.Message)" }

# --- launch ---
$exeHash = (Get-FileHash -LiteralPath $AppPath -Algorithm SHA256).Hash
$dll = Join-Path (Split-Path $AppPath) 'UsbBridgeDesk.dll'
$dllHash = if (Test-Path $dll) { (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash } else { '' }
Log "APP $AppPath sha256=$exeHash dll=$dllHash"
$proc = Start-Process -FilePath $AppPath -PassThru
$launched = Get-Date
Log "LAUNCHED pid=$($proc.Id) at $launched"
$win = $null
for ($i = 0; $i -lt 60 -and -not $win; $i++) {
    Start-Sleep -Seconds 1
    [Windows.Forms.Application]::DoEvents()
    $proc.Refresh()
    if ($proc.HasExited) { break }
    $root = [System.Windows.Automation.AutomationElement]::RootElement
    $win = Find-UIA $root ([System.Windows.Automation.ControlType]::Window) 'USB Bridge Desk'
}
if (-not $win) {
    if ($proc.HasExited) { Fail "app exited during startup, exit code $($proc.ExitCode)" }
    else { Fail 'app window did not appear within 60 s' }
    throw 'startup failed'
}
[Win32]::SetForegroundWindow($proc.MainWindowHandle) | Out-Null
Start-Sleep -Seconds 4
Log "WINDOW found handle=$($proc.MainWindowHandle)"

# --- 30 s survival: overview shot early, then confirm alive at T+30s ---
Shot-Window $proc '01-overview' 'home light' | Out-Null
$elapsed = (Get-Date) - $launched
if ($elapsed.TotalSeconds -lt 30) { Start-Sleep -Seconds ([math]::Ceiling(30 - $elapsed.TotalSeconds)) }
$proc.Refresh()
$alive30 = -not $proc.HasExited
Log "ALIVE30 $alive30 at $(Get-Date -Format 'HH:mm:ss')"
if (-not $alive30) { Fail 'process died before 30 s'; throw 'died before 30 s' }

# --- walk pages (light) ---
if (Select-Nav $win '共享本机 USB') { Start-Sleep -Milliseconds 1500; Shot-Window $proc '02-local' 'host page light' | Out-Null }
if (Select-Nav $win '连接远端 USB') { Start-Sleep -Milliseconds 1500; Shot-Window $proc '03-remote' 'client page light' | Out-Null }
if (Select-Nav $win '映射列表') { Start-Sleep -Milliseconds 1500; Shot-Window $proc '04-mappings' 'maps page light' | Out-Null }

# --- settings: dark + acrylic ---
if (Select-Nav $win '设置') {
    Start-Sleep -Milliseconds 1500
    $okTheme = Select-ComboValue $win '跟随系统' '黑夜'
    if (-not $okTheme) { $okTheme = Select-ComboValue $win '浅色' '黑夜' }
    $okMat = Select-ComboValue $win '云母' '亚克力'
    Start-Sleep -Milliseconds 1200
    $f5 = Shot-Window $proc '05-dark-acrylic' 'settings dark acrylic'
    if ($f5) { Log "BRIGHTNESS 05 = $(Avg-Brightness $f5) (dark expected < 90)" }
    if (Select-Nav $win '连接概览') {
        Start-Sleep -Milliseconds 1500
        $f6 = Shot-Window $proc '06-dark-overview' 'home dark acrylic'
        if ($f6) { Log "BRIGHTNESS 06 = $(Avg-Brightness $f6) (dark expected < 90)" }
    }
}

# --- tray menu ---
$trayFound = $false
try {
    $root = [System.Windows.Automation.AutomationElement]::RootElement
    $taskbar = $null
    foreach ($w in $root.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
        try { if ($w.Current.ClassName -eq 'Shell_TrayWnd') { $taskbar = $w; break } } catch {}
    }
    if ($taskbar) {
        $tb = Find-UIA $taskbar ([System.Windows.Automation.ControlType]::ToolBar) 'User Promoted Notification Area'
        if ($tb) {
            foreach ($b in $tb.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
                try {
                    if ($b.Current.Name -like 'USB Bridge Desk*') {
                        $r = $b.Current.BoundingRectangle
                        [Win32]::SetCursorPos([int]($r.Left + $r.Width / 2), [int]($r.Top + $r.Height / 2)) | Out-Null
                        [Win32]::mouse_event([Win32]::MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, [UIntPtr]::Zero)
                        [Win32]::mouse_event([Win32]::MOUSEEVENTF_RIGHTUP, 0, 0, 0, [UIntPtr]::Zero)
                        $trayFound = $true
                        Log "TRAY right-clicked icon '$($b.Current.Name)'"
                        break
                    }
                } catch {}
            }
        }
    }
    if (-not $trayFound) {
        # overflow chevron
        $chev = Find-UIA $root ([System.Windows.Automation.ControlType]::Button) 'Show hidden icons'
        if ($chev) {
            $chev.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
            Start-Sleep -Milliseconds 1000
            $ovf = $null
            foreach ($w in $root.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
                try { if ($w.Current.ClassName -eq 'NotifyIconOverflowWindow') { $ovf = $w; break } } catch {}
            }
            if ($ovf) {
                foreach ($b in $ovf.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)) {
                    try {
                        if ($b.Current.Name -like 'USB Bridge Desk*') {
                            $r = $b.Current.BoundingRectangle
                            [Win32]::SetCursorPos([int]($r.Left + $r.Width / 2), [int]($r.Top + $r.Height / 2)) | Out-Null
                            [Win32]::mouse_event([Win32]::MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, [UIntPtr]::Zero)
                            [Win32]::mouse_event([Win32]::MOUSEEVENTF_RIGHTUP, 0, 0, 0, [UIntPtr]::Zero)
                            $trayFound = $true
                            Log "TRAY right-clicked icon in overflow '$($b.Current.Name)'"
                            break
                        }
                    } catch {}
                }
            }
        }
    }
} catch { Log "tray lookup error: $($_.Exception.Message)" }
if ($trayFound) {
    Start-Sleep -Milliseconds 1200
    Shot-Screen '07-tray' 'tray context menu full screen' | Out-Null
} else {
    Fail 'tray icon not found (promoted area nor overflow)'
}

# --- clean exit via tray menu item 退出 ---
$exited = $false
try {
    $root = [System.Windows.Automation.AutomationElement]::RootElement
    $exitItem = Find-UIA $root ([System.Windows.Automation.ControlType]::MenuItem) '退出'
    if ($exitItem) {
        $exitItem.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
        Log 'TRAY menu 退出 invoked'
    } else { Log 'tray menu 退出 item not found, will close window instead' }
} catch { Log "exit invoke error: $($_.Exception.Message)" }
for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Seconds 1
    $proc.Refresh()
    if ($proc.HasExited) { $exited = $true; break }
}
if (-not $exited) {
    try { [void]$proc.CloseMainWindow(); Start-Sleep -Seconds 5; $proc.Refresh(); $exited = $proc.HasExited } catch {}
}
$forced = $false
if (-not $exited) {
    Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
    $forced = $true
    Fail 'process did not exit cleanly, killed'
}
$exitCode = $null
try { $exitCode = $proc.ExitCode } catch {}
Log "EXIT exited=$exited forced=$forced code=$exitCode"
if ($backdrop) { $backdrop.Close() }

# --- startup log ---
$logSrc = Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
if (Test-Path $logSrc) { Copy-Item $logSrc (Join-Path $OutDir 'startup.log') -Force; Log 'startup.log copied' }
else { Log 'no startup.log found' }

$result = @{
    os            = [Environment]::OSVersion.Version.ToString()
    appPath       = $AppPath
    appSha256     = $exeHash
    managedAppSha256 = $dllHash
    launched      = $launched.ToString('o')
    alive30s      = $alive30
    exitClean     = ($exited -and -not $forced)
    forcedExit    = $forced
    exitCode      = $exitCode
    screenshots   = $shots
    failures      = $failures
}
$result | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $OutDir 'capture.json')
Log "DONE shots=$($shots.Count) failures=$($failures.Count)"
if ($failures.Count -gt 0 -or $shots.Count -lt 7) { exit 1 }
exit 0
