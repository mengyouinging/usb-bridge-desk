﻿# SPDX-License-Identifier: GPL-3.0-only
# Run in the interactive Windows runner session after installing the product.
param([Parameter(Mandatory=$true)][string]$AppPath, [string]$OutDir=(Join-Path $PWD 'screenshots'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing,UIAutomationClient,UIAutomationTypes
Add-Type -ReferencedAssemblies 'System.Drawing.dll' @'
using System;
using System.Runtime.InteropServices;
public static class DeskCapture {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct MonitorInfo { public int Size; public Rect Monitor, Work; public uint Flags; }
    [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int cmd);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hwnd,IntPtr after,int x,int y,int w,int h,uint flags);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(System.Drawing.Point point);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessageTimeout(IntPtr hwnd,uint message,UIntPtr wParam,string section,uint flags,uint timeout,out UIntPtr result);
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hwnd, int key, out Rect rect, int size);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr info);
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls,string title);
}
'@
[void][DeskCapture]::SetThreadDpiAwarenessContext([IntPtr](-4))
New-Item -ItemType Directory -Force $OutDir | Out-Null
$logFile = Join-Path $OutDir 'driver.log'
$shots = [Collections.Generic.List[object]]::new()
$failures = [Collections.Generic.List[string]]::new()
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$prop = [Windows.Automation.AutomationElement]
$inv = [Windows.Automation.InvokePattern]::Pattern
$sel = [Windows.Automation.SelectionItemPattern]::Pattern
$selList = [Windows.Automation.SelectionPattern]::Pattern
$expand = [Windows.Automation.ExpandCollapsePattern]::Pattern
$proc = $null
$backdrop = $null
$transparencyChanged=$false
$transparencyKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$previousTransparency=$null
function Notify-Transparency {
    $result=[UIntPtr]::Zero
    [void][DeskCapture]::SendMessageTimeout([IntPtr]0xffff,0x1a,[UIntPtr]::Zero,'ImmersiveColorSet',2,200,[ref]$result)
}
$acrylicEvidence = $null
$alive = $false
$clean = $false
$forced = $false
$exitCode = $null
function Log([string]$text) {
    $line = "$(Get-Date -Format HH:mm:ss) $text"
    Write-Host $line
    Add-Content -LiteralPath $logFile -Encoding UTF8 -Value $line
}
function Wait-For([string]$description, [scriptblock]$probe, [int]$seconds=10) {
    $timer = [Diagnostics.Stopwatch]::StartNew()
    do {
        if ($proc -and $proc.HasExited) { throw "App exited ($($proc.ExitCode)) while waiting for $description" }
        [Windows.Forms.Application]::DoEvents()
        try { $probeResult = & $probe; if ($probeResult) { return $probeResult } }
        catch [Windows.Automation.ElementNotAvailableException] {}
        Start-Sleep -Milliseconds 150
    } while ($timer.Elapsed.TotalSeconds -lt $seconds)
    throw "Timed out waiting for $description"
}
function By-Property($element,$property,$value) {
    $condition = [Windows.Automation.PropertyCondition]::new($property,$value)
    return $element.FindFirst($scope,$condition)
}
function By-ID($id) { return By-Property $win $prop::AutomationIdProperty $id }
function Click-Element($item,[bool]$right=$false,[bool]$usePatterns=$true) {
    $pattern=$null
    if ($usePatterns -and -not $right) {
        foreach ($action in @($inv,$sel)) {
            try {
                if ($item.TryGetCurrentPattern($action,[ref]$pattern)) {
                    if ($action -eq $inv) { $pattern.Invoke() } else { $pattern.Select() }
                    return
                }
            } catch { Log "UIA pattern unavailable: $($_.Exception.Message)" }
        }
    }
    if ($item.Current.IsOffscreen -and $item.TryGetCurrentPattern([Windows.Automation.ScrollItemPattern]::Pattern,[ref]$pattern)) {
        $pattern.ScrollIntoView()
        Start-Sleep -Milliseconds 150
    }
    try { $point=$item.GetClickablePoint() } catch {
        $bounds=$item.Current.BoundingRectangle
        if ($bounds.IsEmpty -or $bounds.Width -le 0 -or $bounds.Height -le 0) {
            $item.SetFocus()
            if ($right) { [Windows.Forms.SendKeys]::SendWait('+{F10}') } else { [Windows.Forms.SendKeys]::SendWait('{ENTER}') }
            return
        }
        $point=[Drawing.Point]::new([int]($bounds.Left+$bounds.Width/2),[int]($bounds.Top+$bounds.Height/2))
        Log "Using bounds center for $($item.Current.Name)"
    }
    if (-not [DeskCapture]::SetCursorPos([int]$point.X,[int]$point.Y)) { throw 'Cannot position pointer on interactive desktop' }
    if ($right) { $down=8; $up=16 } else { $down=2; $up=4 }
    [DeskCapture]::mouse_event($down,0,0,0,[UIntPtr]::Zero)
    [DeskCapture]::mouse_event($up,0,0,0,[UIntPtr]::Zero)
}
function Navigate($id,$heading) {
    $item = Wait-For "navigation $id" { By-ID "Nav.$id" }
    Click-Element $item
    [void](Wait-For "page $heading" { $h = By-ID 'PageHeading'; $h -and $h.Current.Name -eq $heading })
}
function Select-Setting($id,$value) {
    $combo = Wait-For "combo $id" { By-ID "Settings.$id" }
    $combo.GetCurrentPattern($expand).Expand()
    $condition = [Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,$value),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::ListItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
    $option = Wait-For "option $value" {
        $o=$win.FindFirst($scope,$condition)
        if (-not $o) { $o=$root.FindFirst($scope,$condition) }
        $o
    }
    $selection=$null
    try {
        if ($option.TryGetCurrentPattern($sel,[ref]$selection)) { $selection.Select() } else { Click-Element $option }
    } catch {
        $option=Wait-For "visible option $value" { $root.FindFirst($scope,$condition) }
        Click-Element $option $false $false
    }
    # Applying a theme rebuilds the settings page. Reacquire the UIA peer.
    [void](Wait-For "selected $value" {
        $c=By-ID "Settings.$id"
        if ($c) {
            $choices=$c.GetCurrentPattern($selList).Current.GetSelection()
            $choices.Count -gt 0 -and $choices[0].Current.Name -eq $value
        }
    })
    $c=By-ID "Settings.$id"
    $p=$c.GetCurrentPattern($expand)
    if ($p.Current.ExpandCollapseState -eq 'Expanded') { $p.Collapse() }
}
function Save-Shot($name,$label,[Drawing.Rectangle]$bounds) {
    if ($bounds.Width -le 0 -or $bounds.Height -le 0) { throw "Empty capture bounds: $name" }
    $image=[Drawing.Bitmap]::new($bounds.Width,$bounds.Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb)
    try {
        $g=[Drawing.Graphics]::FromImage($image)
        try { $g.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size) } finally { $g.Dispose() }
        $file=Join-Path $OutDir "$name.png"
        $image.Save($file,[Drawing.Imaging.ImageFormat]::Png)
    } finally { $image.Dispose() }
    $hash=(Get-FileHash -LiteralPath $file).Hash
    $shots.Add(@{file="$name.png";label=$label;width=$bounds.Width;height=$bounds.Height;left=$bounds.Left;top=$bounds.Top;sha256=$hash;captured=(Get-Date -Format o)})
    Log "SHOT $name $hash"
}
function Work-Area {
    $m=[DeskCapture+MonitorInfo]::new()
    $m.Size=[Runtime.InteropServices.Marshal]::SizeOf($m)
    if (-not [DeskCapture]::GetMonitorInfo([DeskCapture]::MonitorFromWindow($hwnd,2),[ref]$m)) { throw 'Cannot determine monitor work area' }
    return [Drawing.Rectangle]::FromLTRB($m.Work.Left,$m.Work.Top,$m.Work.Right,$m.Work.Bottom)
}
function Frame-Bounds {
    $r=[DeskCapture+Rect]::new()
    if ([DeskCapture]::DwmGetWindowAttribute($hwnd,9,[ref]$r,16) -ne 0) { throw 'Cannot read DWM bounds' }
    return [Drawing.Rectangle]::FromLTRB($r.Left,$r.Top,$r.Right,$r.Bottom)
}
function Fit-Window {
    [void][DeskCapture]::ShowWindow($hwnd,9)
    $area=Work-Area
    $frame=Frame-Bounds
    $width=[Math]::Min($area.Width-24,$frame.Width)
    $height=[Math]::Min($area.Height-24,$frame.Height)
    $x=$area.Left+[int](($area.Width-$width)/2)
    $y=$area.Top+[int](($area.Height-$height)/2)
    if (-not [DeskCapture]::SetWindowPos($hwnd,[IntPtr]::Zero,$x,$y,$width,$height,0x0040)) { throw 'Cannot fit window to monitor' }
    [void][DeskCapture]::SetForegroundWindow($hwnd)
    [void](Wait-For 'entire window inside monitor work area' {
        $frame=Frame-Bounds
        $frame.Width -gt 0 -and $frame.Height -gt 0 -and $area.Contains($frame)
    })
    Log "Fitted DWM frame $(Frame-Bounds) to work area $area"
}
function Window-Shot($name,$label) {
    if (-not (Work-Area).Contains((Frame-Bounds))) { Fit-Window }
    Start-Sleep -Milliseconds 800
    $frame=Frame-Bounds
    if (-not (Work-Area).Contains($frame)) { throw "Incomplete window bounds for $name" }
    Save-Shot $name $label $frame
}
# Sample native pixels in a quiet part of the custom title bar. Repaint only the
# window BEHIND the application, and verify the app owns the sampled pixel.
function Sample-TitleBar {
    $r=Frame-Bounds
    $pt=[Drawing.Point]::new($r.Left+[int]($r.Width/2),$r.Top+18)
    $owner=[DeskCapture]::GetAncestor([DeskCapture]::WindowFromPoint($pt),2)
    if ($owner -ne $hwnd -or [DeskCapture]::GetForegroundWindow() -ne $hwnd) { throw 'Application title bar is occluded or inactive' }
    $bmp=[Drawing.Bitmap]::new(8,8)
    try {
        $g=[Drawing.Graphics]::FromImage($bmp)
        try { $g.CopyFromScreen($pt,[Drawing.Point]::Empty,$bmp.Size) } finally { $g.Dispose() }
        $sum=@(0,0,0)
        for ($x=0; $x -lt 8; $x++) {
            for ($y=0; $y -lt 8; $y++) {
                $c=$bmp.GetPixel($x,$y)
                $sum[0]+=$c.R; $sum[1]+=$c.G; $sum[2]+=$c.B
            }
        }
        return ($sum | ForEach-Object { [int]($_/64) })
    } finally { $bmp.Dispose() }
}
function Measure-Acrylic {
    $samples=@{}
    try {
        [void][DeskCapture]::SetForegroundWindow($hwnd)
        foreach ($phase in 'cool','warm','coolAgain') {
            $backdrop.Tag=$phase
            $backdrop.Refresh()
            [Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 700
            $samples[$phase]=@(Sample-TitleBar)
        }
        $delta=0
        $drift=0
        for ($i=0; $i -lt 3; $i++) {
            $delta=[Math]::Max($delta,[Math]::Abs($samples.cool[$i]-$samples.warm[$i]))
            $drift=[Math]::Max($drift,[Math]::Abs($samples.cool[$i]-$samples.coolAgain[$i]))
        }
        $observed=$delta -ge 5 -and $delta -gt (2*$drift)
        return @{observed=$observed;maxChannelChange=$delta;repeatDrift=$drift;titleBarRGB=$samples}
    } catch {
        return @{observed=$false;reason=$_.Exception.Message}
    } finally {
        $backdrop.Tag=$null
        $backdrop.Refresh()
        [Windows.Forms.Application]::DoEvents()
    }
}
function Shell-Window($class) {
    $h=[DeskCapture]::FindWindow($class,$null)
    if ($h -ne [IntPtr]::Zero) { return [Windows.Automation.AutomationElement]::FromHandle($h) }
}
function Find-Icon($parent,[bool]$overflow=$false) {
    if (-not $parent) { return }
    foreach ($el in $parent.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        # NotifyIcon.Text includes a middle dot and status. The taskbar app button has only the title.
        if ($el.Current.IsOffscreen) { continue }
        if ($el.Current.Name -like 'USB Bridge Desk · *') { return $el }
        if ($el.Current.Name -eq 'USB Bridge Desk' -and ($overflow -or $el.Current.ClassName -match 'NotifyIcon')) { return $el }
    }
}
function Overflow-Icon {
    foreach ($class in 'TopLevelWindowForOverflowXamlIsland','NotifyIconOverflowWindow') {
        $icon=Find-Icon (Shell-Window $class) $true
        if ($icon) { return $icon }
    }
}
function Tray-Icon {
    $bar=Wait-For 'Explorer taskbar' { Shell-Window 'Shell_TrayWnd' }
    $icon=Find-Icon $bar
    if ($icon) { return $icon }
    $icon=Overflow-Icon
    if ($icon) { return $icon }
    $chevron=$null
    foreach ($el in $bar.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        if (-not $el.Current.IsOffscreen -and ($el.Current.AutomationId -in 'SystemTrayIcon','SystemTray.Chevron' -or
             $el.Current.Name -match 'show hidden icons|显示隐藏的图标|显示隐藏图标')) {
            if ($el.Current.Name -match 'hidden|overflow|隐藏' -or $el.Current.AutomationId -eq 'SystemTray.Chevron') {
                $chevron=$el
                break
            }
        }
    }
    if (-not $chevron) { throw 'Cannot locate the notification overflow button' }
    Click-Element $chevron
    try { return Wait-For 'USB Bridge Desk notification icon' { Overflow-Icon } 3 }
    catch {
        Click-Element $chevron $false $false
        return Wait-For 'notification icon after pointer click' { Overflow-Icon }
    }
}
function Find-ExitItem {
    $condition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,'退出'),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::MenuItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
    $owned=[Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id)
    foreach ($popup in $root.FindAll([Windows.Automation.TreeScope]::Children,$owned)) {
        foreach ($item in $popup.FindAll($scope,$condition)) {
            if (-not $item.Current.IsOffscreen -and $item.Current.BoundingRectangle.Width -gt 0) { return $item }
        }
    }
}
function Tray-ExitRecorded {
    $path=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (Test-Path -LiteralPath $path) {
        return [bool](Select-String -LiteralPath $path -Pattern "Tray exit command pid=$($proc.Id)$" -Quiet)
    }
    return $false
}
function Open-TrayMenu {
    $icon=Tray-Icon
    try {
        Click-Element $icon $true
        return Wait-For 'visible tray exit command' { Find-ExitItem } 3
    } catch {
        Log "Retrying tray context menu using keyboard: $($_.Exception.Message)"
        $item=Find-ExitItem
        if ($item) { return $item }
        $icon=Tray-Icon
        $icon.SetFocus()
        [Windows.Forms.SendKeys]::SendWait('+{F10}')
        return Wait-For 'tray exit command after Shift+F10' { Find-ExitItem }
    }
}
$started=Get-Date
try {
    $resolved=(Resolve-Path -LiteralPath $AppPath).Path
    $exeHash=(Get-FileHash $resolved).Hash
    $installDir=Split-Path $resolved
    $dllHash=(Get-FileHash (Join-Path $installDir 'UsbBridgeDesk.dll')).Hash
    $priHash=(Get-FileHash (Join-Path $installDir 'resources.pri')).Hash
    $manifest=Get-Content -Raw -LiteralPath (Join-Path $installDir 'notices/build-manifest.json') | ConvertFrom-Json
    if ($priHash -ne $manifest.files.'resources.pri') { throw 'Installed WinUI resource index differs from the build manifest' }
    Log "Installed WinUI resources.pri SHA256=$priHash"
    if ($env:GITHUB_ACTIONS -eq 'true' -and -not [Windows.Forms.SystemInformation]::HighContrast -and (Test-Path $transparencyKey)) {
        try {
            $previousTransparency=(Get-Item -LiteralPath $transparencyKey).GetValue('EnableTransparency',$null)
            if ($null -eq $previousTransparency -or $previousTransparency -eq 0) {
                New-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency -Value 1 -PropertyType DWord -Force | Out-Null
                $transparencyChanged=$true
                Notify-Transparency
                Log 'Enabled transparency for the runner capture session'
            }
        } catch { Log "Runner transparency preference: $($_.Exception.Message)" }
    }
    $backdrop=[Windows.Forms.Form]::new()
    $backdrop.FormBorderStyle='None'
    $backdrop.WindowState='Maximized'
    $backdrop.ShowInTaskbar=$false
    $backdrop.Add_Paint({
        param($form,$e)
        $left=[Drawing.Color]::Teal
        $right=[Drawing.Color]::DarkOrange
        if ($form.Tag -in 'cool','coolAgain') { $left=$right=[Drawing.Color]::RoyalBlue }
        if ($form.Tag -eq 'warm') { $left=$right=[Drawing.Color]::OrangeRed }
        $brush=[Drawing.Drawing2D.LinearGradientBrush]::new($form.ClientRectangle,$left,$right,30.0)
        try { $e.Graphics.FillRectangle($brush,$form.ClientRectangle) } finally { $brush.Dispose() }
    })
    $backdrop.Show()
    [Windows.Forms.Application]::DoEvents()
    $started=Get-Date
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $launch=[Diagnostics.ProcessStartInfo]::new()
    $launch.FileName=$resolved
    $launch.WorkingDirectory=$installDir
    $launch.UseShellExecute=$false
    $launch.EnvironmentVariables['USB_BRIDGE_CAPTURE']='1'
    $proc=[Diagnostics.Process]::Start($launch)
    Log "Started installed application PID=$($proc.Id)"
    $hwnd=Wait-For 'native main window' {
        $proc.Refresh()
        if ($proc.MainWindowHandle -ne [IntPtr]::Zero) { $proc.MainWindowHandle }
    } 60
    $win=[Windows.Automation.AutomationElement]::FromHandle($hwnd)
    Fit-Window
    Navigate 'home' '连接概览'
    Window-Shot '01-overview' 'overview'
    while ($timer.Elapsed.TotalSeconds -lt 30 -and -not $proc.HasExited) {
        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
    }
    $alive=-not $proc.HasExited
    if (-not $alive) { throw 'App exited before 30 seconds' }
    Log 'ALIVE30 true'
    Navigate 'host' '共享本机 USB'; Window-Shot '02-local' 'host'
    Navigate 'client' '连接远端 USB'; Window-Shot '03-remote' 'client'
    Navigate 'maps' '映射列表'; Window-Shot '04-mappings' 'mappings'
    Navigate 'settings' '设置'
    Select-Setting 'theme' '黑夜'; Select-Setting 'material' '亚克力'
    $acrylicEvidence=Measure-Acrylic
    $materialLabel=if ($acrylicEvidence.observed) { 'desktop blend observed' } else { 'desktop blend unverified' }
    Log "Acrylic $materialLabel / $($acrylicEvidence | ConvertTo-Json -Compress -Depth 4)"
    Window-Shot '05-dark-acrylic' "settings dark / acrylic / $materialLabel"
    Navigate 'home' '连接概览'; Window-Shot '06-dark-overview' "overview dark / acrylic / $materialLabel"
    $exitItem=Open-TrayMenu
    Start-Sleep -Milliseconds 350
    $menuBounds=$exitItem.Current.BoundingRectangle
    $menuPoint=[Drawing.Point]::new([int]($menuBounds.Left+$menuBounds.Width/2),[int]($menuBounds.Top+$menuBounds.Height/2))
    Save-Shot '07-tray' 'visible application tray menu' ([Windows.Forms.Screen]::FromPoint($menuPoint).Bounds)
    try { Click-Element $exitItem } catch { if (-not $proc.HasExited) { Log "Exit command: $($_.Exception.Message)" } }
    if (-not $proc.WaitForExit(1800)) {
        if (-not (Tray-ExitRecorded)) {
            $stillOpen=Find-ExitItem
            if (-not $stillOpen) { $stillOpen=Open-TrayMenu }
            Click-Element $stillOpen $false $false
        }
    }
    $clean=$proc.WaitForExit(60000) -and $proc.ExitCode -eq 0 -and (Tray-ExitRecorded)
    Log "Tray exit clean=$clean"
    if (-not $clean) { throw 'Tray exit did not finish successfully' }
} catch {
    $failures.Add($_.Exception.Message)
    Log "FAIL $($_.Exception.Message)"
    if ($proc) {
        # Windows may record a native fail-fast before a managed handler can log it.
        try {
            $filter=@{LogName='Application'; Id=1000,1001,1026; StartTime=$started}
            for ($i=0; $i -lt 5; $i++) {
                $events=@(Get-WinEvent -FilterHashtable $filter -ErrorAction SilentlyContinue |
                    Where-Object { $_.Message -match '(?i)UsbBridgeDesk\.exe' })
                if ($events.Count -gt 0) {
                    $events | Format-List TimeCreated,ProviderName,Id,Message |
                        Out-File -Encoding UTF8 (Join-Path $OutDir 'application-events.txt') -Width 400
                    break
                }
                Start-Sleep -Seconds 1
            }
        } catch { Log "Reading Application events: $($_.Exception.Message)" }
    }
} finally {
    if ($proc -and -not $proc.HasExited) { $proc.Kill(); $proc.WaitForExit(); $forced=$true }
    if ($proc -and $proc.HasExited) { $exitCode=$proc.ExitCode }
    if ($backdrop) { $backdrop.Dispose() }
    if ($transparencyChanged) {
        try {
            if ($null -eq $previousTransparency) { Remove-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency }
            else { Set-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency -Value $previousTransparency }
            Notify-Transparency
        } catch { Log "Restoring runner transparency setting: $($_.Exception.Message)" }
    }
    $logSrc=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (Test-Path $logSrc) { Copy-Item $logSrc $OutDir -Force }
    @{os=[Environment]::OSVersion.Version.ToString();appPath=$AppPath;appSha256=$exeHash;
      acrylicEvidence=$acrylicEvidence;terminalServerSession=[Windows.Forms.SystemInformation]::TerminalServerSession;
      managedAppSha256=$dllHash;resourceIndexSha256=$priHash;launched=$started.ToString('o');alive30s=$alive;exitClean=$clean;
      forcedExit=$forced;exitCode=$exitCode;screenshots=$shots.ToArray();failures=$failures.ToArray()} |
      ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $OutDir 'capture.json')
}
if ($failures.Count -or $shots.Count -ne 7 -or -not $alive -or -not $clean) { exit 1 }
exit 0
