﻿# SPDX-License-Identifier: GPL-3.0-only
# Run in the interactive Windows runner session after installing the product.
param([Parameter(Mandatory=$true)][string]$AppPath, [string]$OutDir=(Join-Path $PWD 'screenshots'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing,UIAutomationClient,UIAutomationTypes
Add-Type -ReferencedAssemblies 'System.Drawing.dll','System.Windows.Forms.dll' @'
using System;
using System.Runtime.InteropServices;
public sealed class ProbeBackdrop : System.Windows.Forms.Form {
    protected override void OnPaint(System.Windows.Forms.PaintEventArgs e) {
        var r = ClientRectangle;
        if (r.Width <= 0 || r.Height <= 0) return;
        var phase = Tag as string;
        if (phase != null) {
            e.Graphics.Clear(phase == "warm" ? System.Drawing.Color.OrangeRed : System.Drawing.Color.RoyalBlue);
        } else {
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(r, System.Drawing.Color.Teal, System.Drawing.Color.DarkOrange, 30f))
                e.Graphics.FillRectangle(brush, r);
        }
        base.OnPaint(e);
    }
}
public static class DeskCapture {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct MonitorInfo { public int Size; public Rect Monitor, Work; public uint Flags; }
    [StructLayout(LayoutKind.Sequential)]
    private struct IconId { public uint Size; public IntPtr Window; public uint Id; public Guid Guid; }
    private delegate bool EnumWindow(IntPtr window, IntPtr data);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindow callback, IntPtr data);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] private static extern int GetClassName(IntPtr h, System.Text.StringBuilder name, int size);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
    [DllImport("shell32.dll")] private static extern int Shell_NotifyIconGetRect(ref IconId icon, out Rect rect);

    public static System.Drawing.Rectangle TrayRect(uint appPid, uint explorerPid) {
        var result = System.Drawing.Rectangle.Empty;
        // The app creates exactly one WinForms NotifyIcon. WinForms numbers these
        // from 1 and registers the callback on a hidden, top-level native window.
        EnumWindows(delegate(IntPtr w, IntPtr unused) {
            uint pid;
            GetWindowThreadProcessId(w, out pid);
            if (pid != appPid) return true;
            var id = new IconId { Size = (uint)Marshal.SizeOf(typeof(IconId)), Window = w, Id = 1 };
            Rect r;
            if (Shell_NotifyIconGetRect(ref id, out r) != 0 || r.Right <= r.Left || r.Bottom <= r.Top) return true;
            var center = new System.Drawing.Point(r.Left + (r.Right-r.Left)/2, r.Top + (r.Bottom-r.Top)/2);
            IntPtr surface = GetAncestor(WindowFromPoint(center), 2);
            GetWindowThreadProcessId(surface, out pid);
            if (pid != explorerPid) {
                var cls = new System.Text.StringBuilder(128);
                GetClassName(surface, cls, cls.Capacity);
                if (cls.ToString() != "TopLevelWindowForOverflowXamlIsland" && cls.ToString() != "NotifyIconOverflowWindow") return true;
            }
            result = System.Drawing.Rectangle.FromLTRB(r.Left,r.Top,r.Right,r.Bottom);
            return false;
        }, IntPtr.Zero);
        return result;
    }
    [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int cmd);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hwnd,IntPtr after,int x,int y,int w,int h,uint flags);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(System.Drawing.Point point);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessageTimeout(IntPtr hwnd,uint message,UIntPtr wParam,string section,uint flags,uint timeout,out UIntPtr result);
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hwnd, int key, out Rect rect, int size);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr info);
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls,string title);
}
'@
[void][DeskCapture]::SetThreadDpiAwarenessContext([IntPtr](-4))
New-Item -ItemType Directory -Force $OutDir | Out-Null
$logFile = Join-Path $OutDir 'driver.log'
$shots = [Collections.Generic.List[object]]::new()
$failures = [Collections.Generic.List[string]]::new()
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$prop = [Windows.Automation.AutomationElement]
$inv = [Windows.Automation.InvokePattern]::Pattern
$sel = [Windows.Automation.SelectionItemPattern]::Pattern
$selList = [Windows.Automation.SelectionPattern]::Pattern
$expand = [Windows.Automation.ExpandCollapsePattern]::Pattern
$proc = $null
$backdrop = $null
$transparencyChanged=$false
$transparencyKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$previousTransparency=$null
function Notify-Transparency {
    $result=[UIntPtr]::Zero
    [void][DeskCapture]::SendMessageTimeout([IntPtr]0xffff,0x1a,[UIntPtr]::Zero,'ImmersiveColorSet',2,200,[ref]$result)
}
$acrylicEvidence = $null
$alive = $false
$clean = $false
$forced = $false
$exitCode = $null
$trayShot = @{status='not_attempted';reason=$null}
$exitMethod = 'none'
function Log([string]$text) {
    $line = "$(Get-Date -Format HH:mm:ss) $text"
    Write-Host $line
    Add-Content -LiteralPath $logFile -Encoding UTF8 -Value $line
}
function Wait-For([string]$description, [scriptblock]$probe, [int]$seconds=10, [switch]$Optional) {
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $lastError=$null
    do {
        if ($proc -and $proc.HasExited) { throw "App exited ($($proc.ExitCode)) while waiting for $description" }
        [Windows.Forms.Application]::DoEvents()
        try { $probeResult = & $probe; if ($probeResult) { return $probeResult } }
        catch {
            $cause=$_.Exception.GetBaseException()
            if ($cause -isnot [Windows.Automation.ElementNotAvailableException] -and
                $cause -isnot [InvalidOperationException] -and
                $cause -isnot [Runtime.InteropServices.COMException]) { throw }
            $lastError=$cause.Message
        }
        Start-Sleep -Milliseconds 150
    } while ($timer.Elapsed.TotalSeconds -lt $seconds)
    if ($Optional) { return $null }
    throw "Timed out waiting for $description. $lastError"
}
function By-Property($element,$property,$value) {
    if ($null -eq $element) { return }
    $condition = [Windows.Automation.PropertyCondition]::new($property,$value)
    return $element.FindFirst($scope,$condition)
}
function By-ID($id) { return By-Property $win $prop::AutomationIdProperty $id }
function Click-Element($item,[bool]$right=$false,[bool]$usePatterns=$true) {
    if ($null -eq $item) { throw [Windows.Automation.ElementNotAvailableException]::new() }
    $pattern=$null
    if ($usePatterns -and -not $right) {
        foreach ($action in @($inv,$sel)) {
            try {
                if ($item.TryGetCurrentPattern($action,[ref]$pattern) -and $null -ne $pattern) {
                    if ($action -eq $inv) { $pattern.Invoke() } else { $pattern.Select() }
                    return
                }
            } catch { Log "UIA pattern unavailable: $($_.Exception.Message)" }
        }
    }
    if ($item.Current.IsOffscreen -and $item.TryGetCurrentPattern([Windows.Automation.ScrollItemPattern]::Pattern,[ref]$pattern)) {
        $pattern.ScrollIntoView()
        Start-Sleep -Milliseconds 150
    }
    try { $point=$item.GetClickablePoint() } catch {
        $bounds=$item.Current.BoundingRectangle
        if ($bounds.IsEmpty -or $bounds.Width -le 0 -or $bounds.Height -le 0) {
            $item.SetFocus()
            if ($right) { [Windows.Forms.SendKeys]::SendWait('+{F10}') } else { [Windows.Forms.SendKeys]::SendWait('{ENTER}') }
            return
        }
        $point=[Drawing.Point]::new([int]($bounds.Left+$bounds.Width/2),[int]($bounds.Top+$bounds.Height/2))
        Log "Using bounds center for $($item.Current.Name)"
    }
    if (-not [DeskCapture]::SetCursorPos([int]$point.X,[int]$point.Y)) { throw 'Cannot position pointer on interactive desktop' }
    if ($right) { $down=8; $up=16 } else { $down=2; $up=4 }
    [DeskCapture]::mouse_event($down,0,0,0,[UIntPtr]::Zero)
    [DeskCapture]::mouse_event($up,0,0,0,[UIntPtr]::Zero)
}
function Navigate($id,$heading) {
    $item = Wait-For "navigation $id" { By-ID "Nav.$id" }
    Click-Element $item
    [void](Wait-For "page $heading" { $h = By-ID 'PageHeading'; $h -and $h.Current.Name -eq $heading })
}
function Get-Pattern($element,$kind) {
    $pattern=$null
    if ($null -ne $element -and $element.TryGetCurrentPattern($kind,[ref]$pattern)) { return $pattern }
}
function Test-ComboValue($combo,$value) {
    if ($null -eq $combo) { return $false }
    if ($combo.Current.ItemStatus -eq $value) { return $true }
    $selection=Get-Pattern $combo $selList
    if ($null -eq $selection -or $null -eq $selection.Current) { return $false }
    foreach ($item in $selection.Current.GetSelection()) {
        if ($null -ne $item -and $item.Current.Name -eq $value) { return $true }
    }
    return $false
}
function Select-Setting($id,$value) {
    Log "Selecting Settings.$id = $value"
    $condition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,$value),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::ListItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id),
        [Windows.Automation.PropertyCondition]::new($prop::IsOffscreenProperty,$false))
    # Every poll reacquires the live peer. SelectionChanged can destroy both
    # the ComboBox and its popup even while a UIA call is returning.
    [void](Wait-For "selected and closed Settings.$id = $value" {
        $combo=By-ID "Settings.$id"
        if ($null -eq $combo) { return $false }
        $popup=Get-Pattern $combo $expand
        if (Test-ComboValue $combo $value) {
            if ($null -ne $popup -and $popup.Current.ExpandCollapseState -eq 'Expanded') {
                $popup.Collapse()
                return $false
            }
            return $true
        }
        $option=$root.FindFirst($scope,$condition)
        if ($null -ne $option) {
            $pick=Get-Pattern $option $sel
            if ($null -ne $pick) { $pick.Select() } else { Click-Element $option }
        } elseif ($null -eq $popup) {
            Click-Element $combo $false $false
        } elseif ($popup.Current.ExpandCollapseState -ne 'Expanded') {
            $popup.Expand()
        }
        return $false
    } 16)
    Log "Confirmed Settings.$id = $value"
}
function Save-Shot($name,$label,[Drawing.Rectangle]$bounds) {
    if ($bounds.Width -le 0 -or $bounds.Height -le 0) { throw "Empty capture bounds: $name" }
    $image=[Drawing.Bitmap]::new($bounds.Width,$bounds.Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb)
    try {
        $g=[Drawing.Graphics]::FromImage($image)
        try { $g.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size) } finally { $g.Dispose() }
        $file=Join-Path $OutDir "$name.png"
        $image.Save($file,[Drawing.Imaging.ImageFormat]::Png)
    } finally { $image.Dispose() }
    $hash=(Get-FileHash -LiteralPath $file).Hash
    $shots.Add(@{file="$name.png";label=$label;width=$bounds.Width;height=$bounds.Height;left=$bounds.Left;top=$bounds.Top;sha256=$hash;captured=(Get-Date -Format o)})
    Log "SHOT $name $hash"
}
function Work-Area {
    $m=[DeskCapture+MonitorInfo]::new()
    $m.Size=[Runtime.InteropServices.Marshal]::SizeOf($m)
    if (-not [DeskCapture]::GetMonitorInfo([DeskCapture]::MonitorFromWindow($hwnd,2),[ref]$m)) { throw 'Cannot determine monitor work area' }
    return [Drawing.Rectangle]::FromLTRB($m.Work.Left,$m.Work.Top,$m.Work.Right,$m.Work.Bottom)
}
function Frame-Bounds {
    $r=[DeskCapture+Rect]::new()
    if ([DeskCapture]::DwmGetWindowAttribute($hwnd,9,[ref]$r,16) -ne 0) { throw 'Cannot read DWM bounds' }
    return [Drawing.Rectangle]::FromLTRB($r.Left,$r.Top,$r.Right,$r.Bottom)
}
function Fit-Window {
    [void][DeskCapture]::ShowWindow($hwnd,9)
    $area=Work-Area
    $frame=Frame-Bounds
    $width=[Math]::Min($area.Width-24,$frame.Width)
    $height=[Math]::Min($area.Height-24,$frame.Height)
    $x=$area.Left+[int](($area.Width-$width)/2)
    $y=$area.Top+[int](($area.Height-$height)/2)
    if (-not [DeskCapture]::SetWindowPos($hwnd,[IntPtr]::Zero,$x,$y,$width,$height,0x0040)) { throw 'Cannot fit window to monitor' }
    [void][DeskCapture]::SetForegroundWindow($hwnd)
    [void](Wait-For 'entire window inside monitor work area' {
        $frame=Frame-Bounds
        $frame.Width -gt 0 -and $frame.Height -gt 0 -and $area.Contains($frame)
    })
    Log "Fitted DWM frame $(Frame-Bounds) to work area $area"
}
function Window-Shot($name,$label) {
    if (-not (Work-Area).Contains((Frame-Bounds))) { Fit-Window }
    $area=Work-Area
    [void][DeskCapture]::SetCursorPos($area.Left+2,$area.Top+2)
    Start-Sleep -Milliseconds 800
    $frame=Frame-Bounds
    if (-not (Work-Area).Contains($frame)) { throw "Incomplete window bounds for $name" }
    Save-Shot $name $label $frame
}
# Sample native pixels in a quiet part of the custom title bar. Repaint only the
# window BEHIND the application, and verify the app owns the sampled pixel.
function Sample-TitleBar {
    $r=Frame-Bounds
    $pt=[Drawing.Point]::new($r.Left+[int]($r.Width/2),$r.Top+18)
    $owner=[DeskCapture]::GetAncestor([DeskCapture]::WindowFromPoint($pt),2)
    if ($owner -ne $hwnd -or [DeskCapture]::GetForegroundWindow() -ne $hwnd) { throw 'Application title bar is occluded or inactive' }
    $bmp=[Drawing.Bitmap]::new(8,8)
    try {
        $g=[Drawing.Graphics]::FromImage($bmp)
        try { $g.CopyFromScreen($pt,[Drawing.Point]::Empty,$bmp.Size) } finally { $g.Dispose() }
        $sum=@(0,0,0)
        for ($x=0; $x -lt 8; $x++) {
            for ($y=0; $y -lt 8; $y++) {
                $c=$bmp.GetPixel($x,$y)
                $sum[0]+=$c.R; $sum[1]+=$c.G; $sum[2]+=$c.B
            }
        }
        return ($sum | ForEach-Object { [int]($_/64) })
    } finally { $bmp.Dispose() }
}
function Measure-Acrylic {
    if ($null -eq $backdrop -or $backdrop.IsDisposed) { return @{observed=$false;reason="Backdrop form unavailable"} }
    $samples=@{}
    try {
        [void][DeskCapture]::SetForegroundWindow($hwnd)
        foreach ($phase in 'cool','warm','coolAgain') {
            $backdrop.Tag=$phase
            $backdrop.Refresh()
            [Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 700
            $samples[$phase]=@(Sample-TitleBar)
        }
        $delta=0
        $drift=0
        for ($i=0; $i -lt 3; $i++) {
            $delta=[Math]::Max($delta,[Math]::Abs($samples.cool[$i]-$samples.warm[$i]))
            $drift=[Math]::Max($drift,[Math]::Abs($samples.cool[$i]-$samples.coolAgain[$i]))
        }
        $observed=$delta -ge 5 -and $delta -gt (2*$drift)
        return @{observed=$observed;maxChannelChange=$delta;repeatDrift=$drift;titleBarRGB=$samples}
    } catch {
        return @{observed=$false;reason=$_.Exception.Message}
    } finally {
        try {
            if ($null -ne $backdrop -and -not $backdrop.IsDisposed) {
                $backdrop.Tag=$null
                $backdrop.Refresh()
                [Windows.Forms.Application]::DoEvents()
            }
        } catch { Log "Backdrop restore: $($_.Exception.Message)" }
    }
}
function Shell-Window($class) {
    $h=[DeskCapture]::FindWindow($class,$null)
    if ($h -ne [IntPtr]::Zero) { return [Windows.Automation.AutomationElement]::FromHandle($h) }
}
function Find-Icon($parent,[bool]$overflow=$false) {
    if (-not $parent) { return }
    foreach ($el in $parent.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        if ($el.Current.IsOffscreen) { continue }
        if ($el.Current.Name -like 'USB Bridge Desk · *') { return $el }
        if (($overflow -or $el.Current.ClassName -match 'NotifyIcon') -and
            $el.Current.Name -match '(?i)USB\s*Bridge\s*Desk') { return $el }
    }
}
function Visible-Overflow {
    foreach ($class in 'TopLevelWindowForOverflowXamlIsland','NotifyIconOverflowWindow') {
        $h=[DeskCapture]::FindWindow($class,$null)
        if ($h -ne [IntPtr]::Zero -and [DeskCapture]::IsWindowVisible($h)) {
            return [Windows.Automation.AutomationElement]::FromHandle($h)
        }
    }
}
function Overflow-IsOpen($chevron) {
    if (Visible-Overflow) { return $true }
    if ($null -eq $chevron) { return $false }
    $p=Get-Pattern $chevron $expand
    return (($null -ne $p -and $p.Current.ExpandCollapseState -eq 'Expanded') -or
        $chevron.Current.Name -match '(?i)\bHide\b|收起')
}
function Find-TrayTarget($bar,$chevron) {
    $rect=[DeskCapture]::TrayRect($proc.Id,$bar.Current.ProcessId)
    if (-not $rect.IsEmpty) {
        $x=$rect.X+[int][Math]::Floor($rect.Width/2)
        $y=$rect.Y+[int][Math]::Floor($rect.Height/2)
        # Explorer can report the overflow button itself while the icon is hidden.
        if ($null -eq $chevron -or -not $chevron.Current.BoundingRectangle.Contains([double]$x,[double]$y)) {
            return @{point=[Drawing.Point]::new($x,$y);rect=$rect}
        }
    }
    $el=Find-Icon (Visible-Overflow) $true
    if (-not $el) { $el=Find-Icon $bar }
    if ($el) { return @{element=$el} }
}
function Find-Chevron($bar) {
    foreach ($el in $bar.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        if (-not $el.Current.IsOffscreen -and ($el.Current.AutomationId -in 'SystemTrayIcon','SystemTray.Chevron' -or
             $el.Current.Name -match 'show hidden icons|显示隐藏的图标|显示隐藏图标')) {
            if ($el.Current.Name -match 'hidden|overflow|隐藏' -or $el.Current.AutomationId -eq 'SystemTray.Chevron') {
                return $el
            }
        }
    }
}
function Tray-Target {
    # Reacquire Explorer elements on every poll; the overflow island is rebuilt when opened.
    $probe={
        $bar=Shell-Window 'Shell_TrayWnd'
        if ($bar) { Find-TrayTarget $bar (Find-Chevron $bar) }
    }
    $target=Wait-For 'pinned or visible notification icon' $probe 2 -Optional
    if ($target) { return $target }
    for ($pass=1; $pass -le 2; $pass++) {
        [void](Wait-For 'notification area overflow button' {
            $bar=Shell-Window 'Shell_TrayWnd'
            if (-not $bar) { return }
            $chevron=Find-Chevron $bar
            if (-not $chevron) { return }
            if (-not (Overflow-IsOpen $chevron)) {
                Click-Element $chevron $false ($pass -eq 1)
            }
            return $true
        } 2 -Optional)
        $target=Wait-For 'visible registered notification icon' $probe 5 -Optional
        if ($target) { return $target }
        Log "Notification icon unavailable after overflow probe $pass"
    }
}
function Find-ExitItem {
    $condition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new($prop::NameProperty,'退出'),
        [Windows.Automation.PropertyCondition]::new($prop::ControlTypeProperty,[Windows.Automation.ControlType]::MenuItem),
        [Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
    $owned=[Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id)
    foreach ($popup in $root.FindAll([Windows.Automation.TreeScope]::Children,$owned)) {
        foreach ($item in $popup.FindAll($scope,$condition)) {
            if (-not $item.Current.IsOffscreen -and $item.Current.BoundingRectangle.Width -gt 0) { return $item }
        }
    }
}
function Tray-ExitRecorded {
    $path=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (Test-Path -LiteralPath $path) {
        return [bool](Select-String -LiteralPath $path -Pattern "Tray exit command pid=$($proc.Id)$" -Quiet)
    }
    return $false
}
function Open-TrayMenu {
    $iconSeen=$false
    for ($attempt=1; $attempt -le 2; $attempt++) {
        $item=Wait-For 'existing application tray menu' { Find-ExitItem } 1 -Optional
        if ($item) { return $item }
        $target=Tray-Target
        if (-not $target) { continue }
        $iconSeen=$true
        try {
            if ($null -ne $target.point) {
                Log "Right-clicking registered tray icon $($target.rect)"
                if (-not [DeskCapture]::SetCursorPos($target.point.X,$target.point.Y)) { throw 'Cannot reach notification icon' }
                [DeskCapture]::mouse_event(8,0,0,0,[UIntPtr]::Zero)
                [DeskCapture]::mouse_event(16,0,0,0,[UIntPtr]::Zero)
            } elseif ($attempt -eq 1) { Click-Element $target.element $true }
            else {
                $target.element.SetFocus()
                [Windows.Forms.SendKeys]::SendWait('+{F10}')
            }
        } catch {
            $cause=$_.Exception.GetBaseException()
            if ($cause -isnot [Windows.Automation.ElementNotAvailableException] -and
                $cause -isnot [Runtime.InteropServices.COMException]) { throw }
            Log "Reacquiring stale tray target: $($cause.Message)"
            continue
        }
        $item=Wait-For 'application-owned visible tray exit command' { Find-ExitItem } 5 -Optional
        if ($item) { return $item }
        Log 'Reacquiring notification icon after menu timeout'
    }
    if ($iconSeen) { throw 'Notification icon was found but its exit menu did not open' }
    return $null
}

function Find-ResidencySwitch {
    $label=By-Property $win $prop::NameProperty '关闭窗口后驻留托盘'
    if (-not $label -or $label.Current.IsOffscreen) { return }
    $row=$label.Current.BoundingRectangle
    if ($row.IsEmpty) { return }
    $condition=[Windows.Automation.PropertyCondition]::new($prop::IsTogglePatternAvailableProperty,$true)
    foreach ($el in $win.FindAll($scope,$condition)) {
        $r=$el.Current.BoundingRectangle
        if ($el.Current.IsOffscreen -or $r.IsEmpty -or $r.Left -lt $row.Left) { continue }
        $center=$r.Top+$r.Height/2
        if ($center -ge $row.Top -and $center -le $row.Bottom) {
            return Get-Pattern $el ([Windows.Automation.TogglePattern]::Pattern)
        }
    }
}
function Close-WithoutTray {
    if ($proc.HasExited) { throw "App exited before fallback close (code $($proc.ExitCode))" }
    # On the disposable runner, use the installed app's preference so closing the
    # main window requests normal shutdown instead of hiding it back in the tray.
    if ($env:GITHUB_ACTIONS -eq 'true') {
        try {
            [void][DeskCapture]::SetForegroundWindow($hwnd)
            Navigate 'settings' '设置'
            $toggle=Wait-For 'close-to-tray preference' { Find-ResidencySwitch } 3 -Optional
            if ($toggle -and $toggle.Current.ToggleState -eq 'On') {
                $toggle.Toggle()
                [void](Wait-For 'close-to-tray disabled' {
                    $current=Find-ResidencySwitch
                    $current -and $current.Current.ToggleState -eq 'Off'
                } 3 -Optional)
            }
        } catch { Log "Fallback preference unavailable: $($_.Exception.Message)" }
    }
    $proc.Refresh()
    if ($proc.HasExited) { throw "App exited before fallback close (code $($proc.ExitCode))" }
    if ($proc.CloseMainWindow() -and $proc.WaitForExit(15000)) {
        $script:exitMethod='window'
        if ($proc.ExitCode -ne 0) { throw "Window close returned $($proc.ExitCode)" }
        $script:clean=$true
        Log 'Fallback window close confirmed with exit code 0'
    } else {
        $script:exitMethod='cleanup'
        Log 'Window close unconfirmed; driver will clean up the process'
    }
}
function Capture-TrayAndExit {
    $exitItem=Open-TrayMenu
    if (-not $exitItem) {
        $trayShot.status='skipped'
        $trayShot.reason='Explorer did not expose the application notification icon after bounded retries'
        Log "SKIP 07-tray: $($trayShot.reason)"
        $oldShot=Join-Path $OutDir '07-tray.png'
        if (Test-Path -LiteralPath $oldShot) { Remove-Item -LiteralPath $oldShot }
        Close-WithoutTray
        return
    }
    $script:exitMethod='tray'
    Start-Sleep -Milliseconds 350
    $menuBounds=$exitItem.Current.BoundingRectangle
    $menuPoint=[Drawing.Point]::new([int]($menuBounds.Left+$menuBounds.Width/2),[int]($menuBounds.Top+$menuBounds.Height/2))
    Save-Shot '07-tray' 'visible application tray menu' ([Windows.Forms.Screen]::FromPoint($menuPoint).Bounds)
    $trayShot.status='captured'
    try { Click-Element $exitItem } catch { if (-not $proc.HasExited) { Log "Exit command: $($_.Exception.Message)" } }
    if (-not $proc.WaitForExit(1800)) {
        if (-not (Tray-ExitRecorded)) {
            $stillOpen=Find-ExitItem
            if (-not $stillOpen) { $stillOpen=Open-TrayMenu }
            Click-Element $stillOpen $false $false
        }
    }
    $script:clean=$proc.WaitForExit(60000) -and $proc.ExitCode -eq 0 -and (Tray-ExitRecorded)
    Log "Tray exit clean=$clean"
    if (-not $clean) { throw 'Tray exit did not finish successfully' }
}
$trayAttempted=$false
$started=Get-Date
try {
    $resolved=(Resolve-Path -LiteralPath $AppPath).Path
    $exeHash=(Get-FileHash $resolved).Hash
    $installDir=Split-Path $resolved
    $dllHash=(Get-FileHash (Join-Path $installDir 'UsbBridgeDesk.dll')).Hash
    $priHash=(Get-FileHash (Join-Path $installDir 'resources.pri')).Hash
    $manifest=Get-Content -Raw -LiteralPath (Join-Path $installDir 'notices/build-manifest.json') | ConvertFrom-Json
    if ($priHash -ne $manifest.files.'resources.pri') { throw 'Installed WinUI resource index differs from the build manifest' }
    Log "Installed WinUI resources.pri SHA256=$priHash"
    if ($env:GITHUB_ACTIONS -eq 'true' -and -not [Windows.Forms.SystemInformation]::HighContrast -and (Test-Path $transparencyKey)) {
        try {
            $previousTransparency=(Get-Item -LiteralPath $transparencyKey).GetValue('EnableTransparency',$null)
            if ($null -eq $previousTransparency -or $previousTransparency -eq 0) {
                New-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency -Value 1 -PropertyType DWord -Force | Out-Null
                $transparencyChanged=$true
                Notify-Transparency
                Log 'Enabled transparency for the runner capture session'
            }
        } catch { Log "Runner transparency preference: $($_.Exception.Message)" }
    }
    $backdrop=[ProbeBackdrop]::new()
    $backdrop.FormBorderStyle='None'
    $backdrop.WindowState='Maximized'
    $backdrop.ShowInTaskbar=$false
    $backdrop.Show()
    [Windows.Forms.Application]::DoEvents()
    $started=Get-Date
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $launch=[Diagnostics.ProcessStartInfo]::new()
    $launch.FileName=$resolved
    $launch.WorkingDirectory=$installDir
    $launch.UseShellExecute=$false
    $launch.EnvironmentVariables['USB_BRIDGE_CAPTURE']='1'
    $proc=[Diagnostics.Process]::Start($launch)
    Log "Started installed application PID=$($proc.Id)"
    $hwnd=Wait-For 'native main window' {
        $proc.Refresh()
        if ($proc.MainWindowHandle -ne [IntPtr]::Zero) { $proc.MainWindowHandle }
    } 60
    $win=[Windows.Automation.AutomationElement]::FromHandle($hwnd)
    Fit-Window
    Navigate 'home' '连接概览'
    Window-Shot '01-overview' 'overview'
    while ($timer.Elapsed.TotalSeconds -lt 30 -and -not $proc.HasExited) {
        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
    }
    $alive=-not $proc.HasExited
    if (-not $alive) { throw 'App exited before 30 seconds' }
    Log 'ALIVE30 true'
    Navigate 'host' '共享本机 USB'; Window-Shot '02-local' 'host'
    Navigate 'client' '连接远端 USB'; Window-Shot '03-remote' 'client'
    Navigate 'maps' '映射列表'; Window-Shot '04-mappings' 'mappings'
    Navigate 'settings' '设置'
    Select-Setting 'theme' '黑夜'; Select-Setting 'material' '亚克力'
    Log 'Measuring dark acrylic'
    $acrylicEvidence=Measure-Acrylic
    $materialLabel=if ($acrylicEvidence.observed) { 'desktop blend observed' } else { 'desktop blend unverified' }
    Log "Acrylic $materialLabel / $($acrylicEvidence | ConvertTo-Json -Compress -Depth 4)"
    Window-Shot '05-dark-acrylic' "settings dark / acrylic / $materialLabel"
    Navigate 'home' '连接概览'; Window-Shot '06-dark-overview' "overview dark / acrylic / $materialLabel"
    $trayAttempted=$true
    Capture-TrayAndExit
} catch {
    $failures.Add($_.Exception.Message)
    Log "FAIL $($_.Exception.Message) at $($_.InvocationInfo.PositionMessage) $($_.ScriptStackTrace)"
    if ($alive -and -not $trayAttempted -and -not $proc.HasExited) {
        try { Capture-TrayAndExit } catch { $failures.Add("Tray recovery: $($_.Exception.Message)"); Log $_.ScriptStackTrace }
    }
    if ($proc) {
        # Windows may record a native fail-fast before a managed handler can log it.
        try {
            $filter=@{LogName='Application'; Id=1000,1001,1026; StartTime=$started}
            for ($i=0; $i -lt 5; $i++) {
                $events=@(Get-WinEvent -FilterHashtable $filter -ErrorAction SilentlyContinue |
                    Where-Object { $_.Message -match '(?i)UsbBridgeDesk\.exe' })
                if ($events.Count -gt 0) {
                    $events | Format-List TimeCreated,ProviderName,Id,Message |
                        Out-File -Encoding UTF8 (Join-Path $OutDir 'application-events.txt') -Width 400
                    break
                }
                Start-Sleep -Seconds 1
            }
        } catch { Log "Reading Application events: $($_.Exception.Message)" }
    }
} finally {
    if ($proc -and -not $proc.HasExited) { $proc.Kill(); $proc.WaitForExit(); $forced=$true }
    if ($proc -and $proc.HasExited) { $exitCode=$proc.ExitCode }
    if ($backdrop) { $backdrop.Dispose() }
    if ($transparencyChanged) {
        try {
            if ($null -eq $previousTransparency) { Remove-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency }
            else { Set-ItemProperty -LiteralPath $transparencyKey -Name EnableTransparency -Value $previousTransparency }
            Notify-Transparency
        } catch { Log "Restoring runner transparency setting: $($_.Exception.Message)" }
    }
    $logSrc=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (Test-Path $logSrc) { Copy-Item $logSrc $OutDir -Force }
    @{os=[Environment]::OSVersion.Version.ToString();appPath=$AppPath;appSha256=$exeHash;
      acrylicEvidence=$acrylicEvidence;terminalServerSession=[Windows.Forms.SystemInformation]::TerminalServerSession;
      managedAppSha256=$dllHash;resourceIndexSha256=$priHash;launched=$started.ToString('o');alive30s=$alive;exitClean=$clean;
      trayShot=$trayShot;exitMethod=$exitMethod;forcedExit=$forced;exitCode=$exitCode;screenshots=$shots.ToArray();failures=$failures.ToArray()} |
      ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $OutDir 'capture.json')
}
function Test-CaptureResult {
    if ($failures.Count -or -not $alive) { return $false }
    if ($trayShot.status -eq 'skipped') {
        # Cleanup is acceptable only when the optional icon could not be located.
        return ($shots.Count -eq 6 -and ($clean -or ($exitMethod -eq 'cleanup' -and $forced)))
    }
    return ($trayShot.status -eq 'captured' -and $shots.Count -eq 7 -and $clean)
}
if (-not (Test-CaptureResult)) { exit 1 }
exit 0
