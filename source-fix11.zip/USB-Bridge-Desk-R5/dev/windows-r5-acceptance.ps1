param(
    [Parameter(Mandatory=$true)][string]$AppPath,
    [Parameter(Mandatory=$true)][string]$UninstallerPath,
    [Parameter(Mandatory=$true)][string]$InstallerPath,
    [Parameter(Mandatory=$true)][string]$FixtureUrl,
    [string]$OutDir=(Join-Path $PWD 'screenshots')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Drawing,System.Windows.Forms
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$buttonType = [Windows.Automation.ControlType]::Button
$invoke = [Windows.Automation.InvokePattern]::Pattern
New-Item -ItemType Directory -Force $OutDir | Out-Null
$log = Join-Path $OutDir 'acceptance.log'
function Log([string]$text) { Add-Content -LiteralPath $log -Encoding UTF8 -Value "$(Get-Date -Format o) $text" }
function Find-Button([string[]]$names, [int]$processId=0) {
    foreach ($name in $names) {
        $parts = [Collections.Generic.List[Windows.Automation.Condition]]::new()
        $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$buttonType))
        $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,$name))
        if ($processId -gt 0) { $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)) }
        $item = $root.FindFirst($scope,[Windows.Automation.AndCondition]::new($parts.ToArray()))
        if ($item) {
            $script:lastButtonLookup = 'FindFirst'
            return $item
        }
        if ($processId -gt 0) {
            $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
            $items=$root.FindAll($scope,$pidCondition)
            foreach ($candidate in $items) {
                if ($candidate.Current.ControlType -eq $buttonType -and $candidate.Current.Name -eq $name) {
                    $script:lastButtonLookup = 'FindAll(PID)+PowerShell ControlType/Name filter'
                    return $candidate
                }
            }
        }
    }
    $script:lastButtonLookup = 'miss'
    return $null
}
function Wait-Window([int]$processId,[int]$seconds=30) {
    $windowType=[Windows.Automation.ControlType]::Window
    $condition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $until=(Get-Date).AddSeconds($seconds)
    do {
        $item=$root.FindFirst([Windows.Automation.TreeScope]::Children,$condition)
        if ($item) { return $item }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    throw "Timed out waiting for application main window (PID $processId)."
}
function Write-StartupPromptProbe([int]$processId) {
    $buttonName='下载并安装'
    $parts = [Collections.Generic.List[Windows.Automation.Condition]]::new()
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$buttonType))
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,$buttonName))
    $parts.Add([Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $findFirstHit=$null -ne ($root.FindFirst($scope,[Windows.Automation.AndCondition]::new($parts.ToArray())))
    $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    $elements=$root.FindAll($scope,$pidCondition)
    $findAllHit=$false
    foreach ($candidate in $elements) {
        if ($candidate.Current.ControlType -eq $buttonType -and $candidate.Current.Name -eq $buttonName) { $findAllHit=$true; break }
    }
    $windowType=[Windows.Automation.ControlType]::Window
    $windowCondition=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$windowType),
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,'USB Bridge Desk 更新'),
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId))
    $topLevelWindowHit=$null -ne ($root.FindFirst([Windows.Automation.TreeScope]::Children,$windowCondition))
    Log "startup prompt probe FindFirst=$findFirstHit FindAllPidButton=$findAllHit TopLevelDialogWindow=$topLevelWindowHit"
}
function Wait-Button([string]$label,[string[]]$names,[int]$processId=0,[int]$seconds=20) {
    $until=(Get-Date).AddSeconds($seconds)
    $nextProbe=Get-Date
    do {
        if ($label -eq 'startup update prompt' -and (Get-Date) -ge $nextProbe) {
            Write-StartupPromptProbe $processId
            $nextProbe=(Get-Date).AddSeconds(5)
        }
        $item=Find-Button $names $processId
        if ($item) {
            if ($label -eq 'startup update prompt') {
                Log "startup update prompt button found via=$script:lastButtonLookup"
                if ($script:lastButtonLookup -ne 'FindFirst') { Write-StartupPromptProbe $processId }
            }
            return $item
        }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    $pidCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$processId)
    if ($processId -gt 0) {
        $elements=$root.FindAll($scope,$pidCondition)
        $namesDump=@($elements | ForEach-Object {
            $elementName=$_.Current.Name
            $controlType=$_.Current.ControlType.ProgrammaticName
            if ($controlType -eq 'ControlType.Window') { "WINDOW title='$elementName'" }
            if ($controlType -eq 'ControlType.Button') { "BUTTON name='$elementName'" }
            if ($elementName) { "ELEMENT type=$controlType name='$elementName'" }
        } | Where-Object { $_ })
        Log "UIA timeout dump for PID $processId ($label):`n$($namesDump -join "`n")"
    } else {
        Log "UIA timeout dump unavailable for ${label}: no process ID was supplied."
    }
    Shot 'update-prompt-timeout.png'
    throw "Timed out waiting for $label ($($names -join ', '))."
}
function Click([Windows.Automation.AutomationElement]$item) {
    $pattern=$null
    if ($item.TryGetCurrentPattern($invoke,[ref]$pattern)) { $pattern.Invoke(); return }
    $item.SetFocus()
    [Windows.Forms.SendKeys]::SendWait('{ENTER}')
}
function Shot([string]$name) {
    $bounds=[Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp=[Drawing.Bitmap]::new($bounds.Width,$bounds.Height)
    $g=[Drawing.Graphics]::FromImage($bmp)
    try { $g.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size); $bmp.Save((Join-Path $OutDir $name),[Drawing.Imaging.ImageFormat]::Png) }
    finally { $g.Dispose(); $bmp.Dispose() }
}
function Set-Manifest([string]$hash) {
    $json=@{latest_version='9.9.9';download_url=($FixtureUrl.TrimEnd('/')+'/USB-Bridge-Desk-R5-1.3.0-x64.exe');sha256=$hash;release_notes='Windows updater acceptance fixture'} | ConvertTo-Json
    [IO.File]::WriteAllText((Join-Path (Split-Path $log) 'version.json'),$json,[Text.UTF8Encoding]::new($false))
}
function Check-Update([int]$processId) {
    $settings=Wait-Button 'Settings navigation' @('设置') $processId
    Click $settings
    $check=Wait-Button 'settings update check' @('检查更新') $processId
    Click $check
    return Wait-Button 'new version dialog' @('下载并安装') $processId
}
try {
    $validHash=(Get-FileHash -LiteralPath $InstallerPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $fixtureRoot=Split-Path $log
    Copy-Item -LiteralPath $InstallerPath -Destination (Join-Path $fixtureRoot 'USB-Bridge-Desk-R5-1.3.0-x64.exe') -Force
    Set-Manifest $validHash
    $env:USB_BRIDGE_DESK_UPDATE_URL=$FixtureUrl.TrimEnd('/')+'/version.json'
    $app=Start-Process -FilePath $AppPath -PassThru
    $null=Wait-Window $app.Id
    $prompt=Wait-Button 'startup update prompt' @('下载并安装') $app.Id 60
    Shot 'update-available.png'
    Log 'New-version prompt visible at startup; download button has not been clicked.'
    Click (Wait-Button 'defer update' @('稍后') $app.Id)
    $prompt=Check-Update $app.Id
    $requests=Join-Path $fixtureRoot 'requests.log'
    if ((Test-Path $requests) -and (Get-Content $requests -Raw) -match 'USB-Bridge-Desk-R5-1.3.0-x64.exe') {
        throw 'Installer download began before the user chose 下载并安装.'
    }
    Log 'Settings check showed the update; server log confirms no installer download before explicit choice.'
    Click (Wait-Button 'defer settings update' @('稍后') $app.Id)
    Shot 'settings-update-result.png'

    Set-Manifest ('0' * 64)
    $prompt=Check-Update $app.Id
    Click $prompt
    $failure=Wait-Button 'hash mismatch error' @('确定','OK') $app.Id
    Shot 'update-hash-failure.png'
    $texts=$root.FindAll($scope,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$app.Id))
    $allText=(@($texts | ForEach-Object { $_.Current.Name }) -join ' ')
    if ($allText -notmatch 'SHA-256 校验失败') { throw 'Wrong-hash fixture did not report SHA-256 verification failure.' }
    Log 'Wrong SHA-256 manifest was rejected and the UI reported verification failure.'
    Click $failure

    Set-Manifest $validHash
    $prompt=Check-Update $app.Id
    Click $prompt
    if (-not $app.WaitForExit(30000)) { throw 'Application did not exit after handing the verified installer to Windows.' }
    $deadline=(Get-Date).AddSeconds(30)
    $installerProcess=$null
    do {
        $installerProcess=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'USB-Bridge-Desk-*.exe' -and $_.ExecutablePath -ne $AppPath } | Select-Object -First 1
        if ($installerProcess) { break }
        Start-Sleep -Milliseconds 250
    } while ((Get-Date) -lt $deadline)
    if (-not $installerProcess) { throw 'Verified update download did not launch the downloaded installer.' }
    Log "Correct SHA-256 download launched installer PID $($installerProcess.ProcessId)."
    Stop-Process -Id $installerProcess.ProcessId -Force
    $downloaded=Get-Content $requests -Raw
    if ($downloaded -notmatch 'USB-Bridge-Desk-R5-1.3.0-x64.exe') { throw 'Fixture server did not record the installer download.' }
    Log 'Verified installer was downloaded and launched; setup process was stopped before modifying the installation.'
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue

    $app=Start-Process -FilePath $AppPath -PassThru
    Start-Sleep -Seconds 3
    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $liveConfirm=Wait-Button 'running-app uninstall confirmation' @('是','Yes') $un.Id 30
    Click $liveConfirm
    $ok=Wait-Button 'live-app uninstall guard dialog' @('确定','OK') $un.Id 30
    Shot 'uninstall-running-app-guard.png'
    $guardItems=$root.FindAll($scope,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$un.Id))
    $guardText=(@($guardItems | ForEach-Object { $_.Current.Name }) -join ' ')
    if ($guardText -notmatch '请先关闭 USB Bridge Desk') { throw 'Running-app guard dialog did not show its expected Chinese message.' }
    Log 'Running-app uninstall guard dialog captured and asserted in Simplified Chinese.'
    Click $ok
    if (-not $un.WaitForExit(10000)) { Stop-Process -Id $un.Id -Force }
    Stop-Process -Id $app.Id -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2

    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $yes=Wait-Button 'uninstall confirmation' @('是','Yes') $un.Id 30
    Shot 'uninstall-confirmation.png'
    Log 'Uninstall confirmation dialog captured in Simplified Chinese.'
    Click $yes
    if (-not $un.WaitForExit(300000)) { throw 'Uninstaller did not finish within five minutes.' }
    $installDir=Split-Path $AppPath
    if (Test-Path -LiteralPath $installDir) { throw "Application installation directory remains after uninstall: $installDir" }
    Log 'Uninstall completed and application installation directory is absent.'
} finally {
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue
}
