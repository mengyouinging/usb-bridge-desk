#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Serve disposable updater fixtures on loopback and record every request."""
import argparse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        with (Path(self.directory) / "requests.log").open("a", encoding="utf-8") as log:
            log.write("%s %s\n" % (self.command, self.path))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("port_file", type=Path)
    args = parser.parse_args()
    handler = lambda *a, **kw: Handler(*a, directory=str(args.root), **kw)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    args.port_file.write_text(json.dumps({"port": server.server_port}), encoding="utf-8")
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
