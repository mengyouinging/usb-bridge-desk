// SPDX-License-Identifier: GPL-3.0-only
using System.Buffers.Binary;
using System.Net;
using System.Net.Sockets;

namespace UsbBridge;

public enum Verdict
{
    Ready,
    Discouraged,
    Unavailable,
    Pending,
}

public sealed record LocalAddress(
    string Adapter,
    string Id,
    IPAddress IP,
    bool Up,
    bool Valid,
    bool Temporary,
    bool Virtual,
    string Description
)
{
    public string Endpoint => new IPEndPoint(IP, 3240).ToString();
}

public sealed record AddressResult(LocalAddress Address, Verdict Status, string Reason, int Rank)
{
    public string Label =>
        Status switch
        {
            Verdict.Ready => "本机可用",
            Verdict.Discouraged => "不推荐",
            Verdict.Unavailable => "不可用",
            _ => "检测中…",
        };
    public string Summary => $"{Label} · {AddressProbe.Reachability(Address)} · {Address.Adapter} · {Address.Endpoint}";
}

public static class PublicAddressLookup
{
    private static readonly Uri[] Endpoints =
    [
        new("https://api64.ipify.org"),
        new("https://ifconfig.me/ip"),
        new("https://ip.sb"),
        new("https://checkip.amazonaws.com"),
    ];
    private static readonly HttpClient Client = new() { Timeout = TimeSpan.FromSeconds(3) };
    private static readonly Lazy<Task<IPAddress?>> Lookup = new(() => Query(CancellationToken.None));

    public static async Task<IPAddress?> Get(CancellationToken token) =>
        await Lookup.Value.WaitAsync(token).ConfigureAwait(false);

    private static async Task<IPAddress?> Query(CancellationToken token)
    {
        foreach (var endpoint in Endpoints)
        {
            try
            {
                var text = await Client.GetStringAsync(endpoint, token).ConfigureAwait(false);
                if (IPAddress.TryParse(text.Trim(), out var address)
                    && address.AddressFamily == AddressFamily.InterNetworkV6
                    && IsGlobal(address))
                    return address;
            }
            catch (Exception e) when (e is HttpRequestException or TaskCanceledException or IOException) { }
        }
        return null;
    }

    public static bool IsGlobal(IPAddress address)
    {
        var b = address.GetAddressBytes();
        return b.Length == 16 && (b[0] & 0xe0) == 0x20
            && !address.IsIPv6LinkLocal && !address.IsIPv6Multicast;
    }

    public static string? Match(IEnumerable<LocalAddress> rows, IPAddress? publicAddress) =>
        publicAddress == null ? null : rows.FirstOrDefault(r => r.IP.Equals(publicAddress))?.Id;
}

public static class AddressProbe
{
    // A reachability *hint*, never a promise of inbound TCP reachability.
    // VPN/WARP/host-only interfaces are deliberately not advertised as public.
    public static string Reachability(LocalAddress address)
    {
        var ip = address.IP;
        var bytes = ip.GetAddressBytes();
        var adapter = address.Adapter + " " + address.Description;
        bool Named(string value) => adapter.Contains(value, StringComparison.OrdinalIgnoreCase);
        bool warp6 = bytes.Length == 16
            && bytes.AsSpan(0, 6).SequenceEqual(new byte[] { 0x26, 0x06, 0x47, 0, 0x0c, 0xf1 });
        if (warp6 || Named("warp") || Named("cloudflare") || Named("vmware")
            || Named("vmnet") || Named("virtual") || Named("wintun") || Named("vpn")
            || Named("hyper-v") || Named("tap-") || Named("wireguard"))
            return "仅局域网";
        if (bytes.Length == 16)
            return PublicAddressLookup.IsGlobal(ip) ? "公网可用" : "仅局域网";
        if (bytes.Length != 4) return "仅局域网";
        int a = bytes[0], b = bytes[1], c = bytes[2];
        // RFC1918, CGNAT, link-local, loopback, protocol/reserved, test and
        // benchmark networks are not globally reachable IPv4 destinations.
        bool nonPublic = a is 0 or 10 or 127 || a >= 224
            || a == 172 && b is >= 16 and <= 31
            || a == 192 && (b == 168 || b == 0 && c == 0 || b == 0 && c == 2)
            || a == 100 && b is >= 64 and <= 127
            || a == 169 && b == 254
            || a == 198 && (b is 18 or 19 || b == 51 && c == 100)
            || a == 203 && b == 0 && c == 113;
        return nonPublic ? "仅局域网" : "公网可用";
    }

    // A TCP endpoint is probed once even if two adapters advertise the same IP.
    // Prefer a current, recommended route over a stale or virtual alias.
    public static IEnumerable<LocalAddress> UniqueEndpoints(IEnumerable<LocalAddress> rows) =>
        rows.OrderBy(a => !a.Up || !a.Valid)
            .ThenBy(a => Classify(a, null, false).Status)
            .ThenBy(a => Classify(a, null, false).Rank)
            .ThenBy(a => a.Id, StringComparer.Ordinal)
            .DistinctBy(a => a.Endpoint);

    public static AddressResult Classify(LocalAddress a, string? failure, bool running)
    {
        var b = a.IP.GetAddressBytes();
        var v4 = b.Length == 4;
        var name = a.Adapter + " " + a.Description;
        bool Named(string s) => name.Contains(s, StringComparison.OrdinalIgnoreCase);
        bool easy = Named("easytier") || Named("easy tier");
        bool usbEthernet = Named("usb") && (Named("gbe") || Named("ethernet") || Named("gigabit"));
        bool global6 = !v4 && PublicAddressLookup.IsGlobal(a.IP);
        bool local =
            v4
            && (b[0] == 10 || b[0] == 192 && b[1] == 168 || b[0] == 172 && b[1] is >= 16 and <= 31);
        bool warp6 =
            !v4 && b.AsSpan(0, 6).SequenceEqual(new byte[] { 0x26, 0x06, 0x47, 0, 0x0c, 0xf1 });
        string? caution = null;
        if (Named("warp") || Named("cloudflare") || warp6)
            caution = "Cloudflare WARP 出口地址，普通对端无法直连。";
        else if (Named("vmnet1") || a.Adapter.EndsWith("VMnet1", StringComparison.OrdinalIgnoreCase))
            caution = "VMware host-only 网络，仅宿主和同一虚拟网络内的虚拟机可达。";
        else if (Named("vmware") || Named("vmnet"))
            caution = "VMware 虚拟网络，通常仅宿主与相应虚拟机可达。";
        else if (
            !easy
            && (
                a.Virtual && !global6 && !usbEthernet
                || Named("virtual")
                || Named("wintun")
                || Named("vpn")
                || Named("hyper-v")
                || Named("tap-")
                || Named("wireguard")
            )
        )
            caution = "虚拟网卡或隧道，仅同一虚拟网络内的对端可能可达。";
        else if (!easy && v4 && b[0] == 100 && b[1] is >= 64 and <= 127)
            caution = "运营商共享地址（CGNAT），普通对端无法直连。";
        else if (v4 && b[0] == 169 && b[1] == 254)
            caution = "链路本地地址，仅适用于同一链路。";
        var rank = a.Temporary ? 5
            : easy ? 1
            : local ? 0
            : global6 ? 2
            : 3;
        failure =
            !a.Up ? "网卡已断开。"
            : !a.Valid ? "地址已失效或尚未就绪。"
            : failure;
        var reason = failure
            ?? caution
            ?? (
                running
                    ? "此地址已完成 USB/IP 设备列表握手。"
                    : "此地址可在本机绑定并监听 TCP 3240。"
            );
        return new(
            a,
            failure != null ? Verdict.Unavailable
                : caution != null ? Verdict.Discouraged
                : Verdict.Ready,
            reason + (a.Temporary ? " 临时地址，可能变化。" : ""),
            rank
        );
    }

    public static async Task<AddressResult> Test(
        LocalAddress a,
        bool? running,
        Func<IPAddress, string?> listener,
        CancellationToken token,
        int port = 3240
    )
    {
        string? error = null;
        if (a.Up && a.Valid)
        {
            if (running == null)
                error = "共享服务状态未知，请刷新。";
            else if (!running.Value)
                error = await ProbeBind(a, port, token).ConfigureAwait(false);
            else
                error = await ProbeRunning(a, listener, port, token).ConfigureAwait(false);
        }
        return Classify(a, error, running == true);
    }

    public static async Task<string?> ProbeBind(LocalAddress a, int port, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        try
        {
            using var socket = new Socket(a.IP.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            socket.ExclusiveAddressUse = true;
            socket.Bind(new IPEndPoint(a.IP, port));
            socket.Listen(1);
            return null;
        }
        catch (SocketException ex)
        {
            return ex.SocketErrorCode switch
            {
                SocketError.AddressAlreadyInUse => "TCP 3240 已被占用。",
                SocketError.AccessDenied => "系统拒绝访问，请检查端口保留和防火墙策略。",
                _ => $"本机 TCP 检测失败（{ex.SocketErrorCode}）。",
            };
        }
    }

    private static async Task<string?> ProbeRunning(LocalAddress a, Func<IPAddress, string?> listener, int port, CancellationToken token)
    {
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(token);
        budget.CancelAfter(TimeSpan.FromMilliseconds(2500));
        try
        {
            var error = listener(a.IP);
            if (error != null) return error;
            using var client = new TcpClient(a.IP.AddressFamily);
            await client.ConnectAsync(a.IP, port, budget.Token).ConfigureAwait(false);
            await DevList(client.GetStream(), budget.Token).ConfigureAwait(false);
            return null;
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            return "本机握手超时，请检查服务和防火墙策略。";
        }
        catch (SocketException ex)
        {
            return ex.SocketErrorCode switch
            {
                SocketError.AddressAlreadyInUse => "TCP 3240 已被占用。",
                SocketError.AccessDenied => "系统拒绝访问，请检查端口保留和防火墙策略。",
                _ => $"本机 TCP 检测失败（{ex.SocketErrorCode}）。",
            };
        }
        catch (InvalidDataException)
        {
            return "响应与 USB/IP 设备列表协议不符。";
        }
        catch (IOException)
        {
            return "USB/IP 设备列表响应无效或连接中断。";
        }
    }

    public static async Task DevList(Stream stream, CancellationToken token)
    {
        // Same wire exchange as dev/test-backend.py. Consume complete records even for a nonempty reply.
        await stream.WriteAsync(new byte[] { 1, 17, 128, 5, 0, 0, 0, 0 }, token);
        var header = new byte[12];
        await stream.ReadExactlyAsync(header, token);
        if (!header.AsSpan(0, 8).SequenceEqual(new byte[] { 1, 17, 0, 5, 0, 0, 0, 0 }))
            throw new InvalidDataException("USB/IP header");
        var count = BinaryPrimitives.ReadUInt32BigEndian(header.AsSpan(8));
        if (count > 65535)
            throw new InvalidDataException("USB/IP count");
        var record = new byte[312];
        var interfaces = new byte[255 * 4];
        for (uint i = 0; i < count; i++)
        {
            await stream.ReadExactlyAsync(record, token);
            await stream.ReadExactlyAsync(interfaces.AsMemory(0, record[311] * 4), token);
        }
    }
}

public static class WindowLimits
{
    public const int Width = 880,
        Height = 640;

    public static int Pixels(int dip, uint dpi) => (int)Math.Ceiling(dip * dpi / 96d);
}
