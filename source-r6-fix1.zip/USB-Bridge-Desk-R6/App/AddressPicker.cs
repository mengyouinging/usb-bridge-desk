// SPDX-License-Identifier: GPL-3.0-only
using System.Net;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using UsbBridge;

namespace Desk;

internal sealed partial class Shell
{
    private CancellationTokenSource? probe;
    private readonly Dictionary<(string, IPAddress), LocalAddress> lastAddresses = new();
    private readonly List<AddressResult> addressRows = new();
    private Action? updatePicker;
    private string addressHint = "正在读取网卡…";
    private bool probing;
    private bool autoAddress = true;
    private IPAddress? publicIPv6;
    private string? publicIPv6Adapter;

    private static string Key(LocalAddress row) => row.Endpoint;

    // UI rendering is not a network probe. WinUI COM/reparenting faults must
    // never wipe a successful adapter inventory or abort remaining socket tests.
    private void PublishAddressResults(string step)
    {
        try { updatePicker?.Invoke(); }
        catch (Exception ex) { Program.Trace($"Address picker UI refresh ({step}): {ex}"); }
    }

    private async void RefreshAddresses()
    {
        probe?.Cancel();
        if (page != "host" || closed)
            return;
        using var current = new CancellationTokenSource();
        probe = current;
        probing = true;
        var token = current.Token;
        bool? running = server?.Running;
        string step = "网卡枚举";
        try
        {
            var previous = lastAddresses.Values.ToArray();
            var rows = await Task.Run(() => NetworkInspection.Enumerate(previous), token);
            token.ThrowIfCancellationRequested();
            step = "公网 IPv6 查询";
            publicIPv6 = await PublicAddressLookup.Get(token);
            publicIPv6Adapter = PublicAddressLookup.Match(rows, publicIPv6);
            step = "网卡快照与初始地址条目";
            var snapshot = rows.DistinctBy(a => (a.Id, a.IP)).ToDictionary(a => (a.Id, a.IP));
            lastAddresses.Clear();
            addressRows.Clear();
            foreach (var (key, row) in snapshot)
            {
                lastAddresses[key] = row;
            }
            var endpoints = AddressProbe.UniqueEndpoints(snapshot.Values).ToArray();
            foreach (var row in endpoints)
                addressRows.Add(new(row, Verdict.Pending, "正在检查接口、监听和服务。", 9));
            addressHint = "检测中…";
            PublishAddressResults("初始地址列表");
            step = "监听服务及逐地址 TCP 探测";
            var firewall = Task.Run(
                () =>
                {
                    try
                    {
                        return Firewall.ExplicitBlocks(rows, token);
                    }
                    catch (OperationCanceledException) when (token.IsCancellationRequested)
                    {
                        return new HashSet<IPAddress>();
                    }
                    catch (Exception ex)
                    {
                        Program.Trace("Firewall inventory: " + ex.Message);
                        return new HashSet<IPAddress>();
                    }
                },
                token
            );
            Func<IPAddress, string?> listener = _ => null;
            if (running == true)
            {
                try
                {
                    listener = await Task.Run(NetworkInspection.SnapshotListeners, token)
                        .WaitAsync(token);
                }
                catch (Exception e) when (!token.IsCancellationRequested)
                {
                    Program.Trace(e.Message);
                    listener = _ => "无法读取本机监听信息。";
                }
            }
            await Task.WhenAll(
                endpoints.Select(async row =>
                {
                    AddressResult result;
                    try
                    {
                        result = await Task.Run(
                                () => AddressProbe.Test(row, running, listener, token),
                                token
                            )
                            .WaitAsync(token);
                    }
                    catch (OperationCanceledException) when (!token.IsCancellationRequested)
                    {
                        result = AddressProbe.Classify(
                            row,
                            "本机检测超时，请刷新并检查服务或防火墙。",
                            running == true
                        );
                    }
                    catch (Exception ex) when (!token.IsCancellationRequested)
                    {
                        // A single endpoint's socket/Win32 failure cannot clear other rows.
                        Program.Trace($"Address TCP probe ({row.Endpoint}): {ex}");
                        result = AddressProbe.Classify(
                            row, "单个地址检测失败，请刷新并查看启动日志。", running == true);
                    }
                    token.ThrowIfCancellationRequested();
                    int index = addressRows.FindIndex(r =>
                        r.Address.Id == row.Id && r.Address.IP.Equals(row.IP)
                    );
                    if (index >= 0) addressRows[index] = result;
                    PublishAddressResults($"TCP {row.Endpoint}");
                })
            );
            // Socket probes update the dropdown immediately. Merge explicit firewall
            // blocks as soon as the shared policy inventory completes.
            step = "防火墙阻止规则合并";
            HashSet<IPAddress> blocks;
            try
            {
                blocks = await firewall.WaitAsync(token);
            }
            catch (OperationCanceledException) when (!token.IsCancellationRequested)
            {
                blocks = [];
            }

            token.ThrowIfCancellationRequested();
            for (int i = 0; i < addressRows.Count; i++)
            {
                var r = addressRows[i];
                if (r.Status != Verdict.Unavailable && blocks.Contains(r.Address.IP))
                    addressRows[i] = AddressProbe.Classify(
                        r.Address,
                        "Windows 防火墙有明确匹配的入站阻止规则。",
                        running == true
                    );
            }
            addressHint =
                snapshot.Count == 0
                    ? "未发现可检测的网卡地址。"
                    : publicIPv6 == null
                        ? "未能确认公网 IPv6；已优先检测稳定的本地全局 IPv6 地址。"
                        : publicIPv6Adapter == null
                            ? "已确认公网 IPv6，但本机地址列表中没有匹配项；以下使用稳定全局 IPv6 候选。"
                            : "公网 IPv6 出口对应此本机地址。";
            PublishAddressResults("检测完成");
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
        catch (Exception e)
        {
            if (!token.IsCancellationRequested)
            {
                Program.Trace($"Address detection step '{step}' failed: {e}");
                // Retain successful and pending rows on partial failures.
                addressHint = $"地址检测未完成（{step}），请刷新并查看日志。";
                PublishAddressResults($"异常：{step}");
            }
        }
        finally
        {
            if (ReferenceEquals(probe, current))
            {
                probe = null;
                probing = false;
                PublishAddressResults("检测状态结束");
            }
        }
    }

    private void AddAddressPicker(StackPanel link)
    {
        var combo = new ComboBox
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
        };
        AutomationProperties.SetAutomationId(combo, "Host.Addresses");
        var description = Muted("");
        var copy = Btn("复制地址", () => Done(() =>
            {
                if (combo.SelectedItem is ComboBoxItem { Tag: AddressResult r })
                    Copy(r.Address.Endpoint);
            }));
        // Stable containers; neither reinsert selected ComboBoxItems nor reuse a
        // TextBlock visual as Content (the WinUI selection presenter has its own tree).
        var itemsByEndpoint = new Dictionary<string, ComboBoxItem>(StringComparer.Ordinal);
        bool updating = false;
        void Update()
        {
            if (updating) return; // SizeChanged/SelectionChanged may be reentrant.
            updating = true;
            try
            {
                AutomationProperties.SetItemStatus(combo, probing ? "pending" : "complete");
                var sorted = addressRows
                    .OrderBy(r => r.Status)
                    .ThenBy(r => r.Rank)
                    .ThenBy(r => r.Address.Adapter, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(r => r.Address.Endpoint, StringComparer.Ordinal)
                    .ToList();
                var choice = autoAddress
                    ? null
                    : sorted.FirstOrDefault(r =>
                        Key(r.Address) == selectedAddress
                        && r.Status is Verdict.Ready or Verdict.Discouraged);
                choice ??= sorted.FirstOrDefault(r => r.Status == Verdict.Ready);
                var current = new HashSet<string>(StringComparer.Ordinal);
                foreach (var r in sorted)
                {
                    string key = Key(r.Address);
                    current.Add(key);
                    if (!itemsByEndpoint.TryGetValue(key, out var item))
                    {
                        item = new ComboBoxItem();
                        itemsByEndpoint.Add(key, item);
                        combo.Items.Add(item); // Add once; NEVER remove and reinsert to sort.
                    }
                    item.Tag = r;
                    var outbound = publicIPv6Adapter == r.Address.Id && publicIPv6 != null
                        && r.Address.IP.Equals(publicIPv6)
                        ? " · 当前公网 IPv6 出口" : "";
                    // A string is displayed by independent presenters; a shared
                    // TextBlock would throw 'Element is already the child...'.
                    item.Content = r.Summary + outbound + "\n" + r.Reason;
                    item.Opacity = r.Status == Verdict.Unavailable ? .62 : 1;
                    AutomationProperties.SetAutomationId(item, "Host.Address." + r.Address.Endpoint);
                    AutomationProperties.SetName(item, r.Summary + outbound + " " + r.Reason);
                }
                // Remove only endpoints which disappeared after a *new* enumeration.
                foreach (var key in itemsByEndpoint.Keys.Where(k => !current.Contains(k)).ToArray())
                {
                    combo.Items.Remove(itemsByEndpoint[key]);
                    itemsByEndpoint.Remove(key);
                }
                combo.PlaceholderText = sorted.Any(r => r.Status == Verdict.Pending)
                    ? "检测中…" : "请选择地址";
                var selected = choice == null ? null : itemsByEndpoint[Key(choice.Address)];
                if (!ReferenceEquals(combo.SelectedItem, selected))
                    combo.SelectedItem = selected;
                copy.IsEnabled = choice != null;
                description.Text = choice?.Reason ?? addressHint;
            }
            finally { updating = false; }
        }
        combo.SelectionChanged += async (_, _) =>
        {
            if (updating || combo.SelectedItem is not ComboBoxItem { Tag: AddressResult r })
                return;
            if (r.Status is Verdict.Pending or Verdict.Unavailable)
            {
                Update();
                if (
                    r.Status == Verdict.Unavailable
                    && await Confirm(
                        "此地址不可用",
                        r.Address.Endpoint + "\n" + r.Reason,
                        "复制地址"
                    )
                )
                    Copy(r.Address.Endpoint);
                return;
            }
            autoAddress = false;
            selectedAddress = Key(r.Address);
            description.Text = r.Reason;
            copy.IsEnabled = true;
        };
        updatePicker = Update;
        Update();
        Add(
            link,
            Split(combo, copy),
            description,
            Muted("仅验证本机绑定或服务握手。对方能否连接，需在对方电脑实测。")
        );
    }
}
