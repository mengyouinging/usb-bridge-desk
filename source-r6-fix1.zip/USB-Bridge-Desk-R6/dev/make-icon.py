#!/usr/bin/env python3
"""Rebuild an optically sized Windows ICO from the image-generated orbit master.

The 256px frame embedded in packaging/icon.ico is the canonical master; no extra
source file is needed. To introduce a new image-generated master, pass its PNG as
an optional argument. Windows ICO frames are independent DIB images (16..128)
and PNG (256), so small resolutions are not a single stretched bitmap.
"""
import base64
import io
from pathlib import Path
import struct
import sys
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ICO = ROOT / 'packaging/icon.ico'
SIZES = (16, 32, 48, 64, 128, 256)


def master():
    if len(sys.argv) > 1:
        return Image.open(sys.argv[1]).convert('RGBA')
    with Image.open(ICO) as icon:
        return icon.ico.getimage((256, 256)).convert('RGBA')


def pixel_icon16():
    # Hand-hinted silhouette of the generated slanted ring at notification size:
    # upper-right and lower-left USB heads each retain two dark contact wells.
    palette = {'m': '#FFF7C1', 'h': '#80CDA2', 'n': '#10654E',
               'g': '#20B16E', 'c': '#07584A', 'b': '#C99F20',
               'y': '#FFDB2B', 'l': '#FFF2A2'}
    pixels = [
        '.hhhhh..........', '.mnmnm..........', '.hmmmh.....bbbbb', '...nn..gg.bbb..b',
        '....gggggggb..by', '...bggccccgg.byy', '..bggccccccgyyy.', '.bbggcccccyyyl..',
        '.b.ggcccyyyl....', 'bb.gggyyylgg....', 'b..gyyylcgg.....', 'byyylgggggg.....',
        'yyy.......nn....', '.........hmmmh..', '.........mnmnm..', '.........hhhhh..'
    ]
    result = Image.new('RGBA', (16, 16))
    for y, row in enumerate(pixels):
        assert len(row) == 16
        for x, letter in enumerate(reversed(row)):
            if letter in palette:
                from PIL import ImageColor
                result.putpixel((x, y), ImageColor.getcolor(palette[letter], 'RGBA'))
    return result


def optical_frame(source, size):
    if size == 16:
        return pixel_icon16()
    if size <= 32:
        # Make connectors and the yellow ring more legible in notification UI.
        box = source.getchannel('A').point(lambda v: 255 if v >= 128 else 0).getbbox()
        if box:
            left, top, right, bottom = box
            pad = int(max(right - left, bottom - top) * (0.025 if size == 16 else 0.05))
            source = source.crop((max(0, left - pad), max(0, top - pad),
                                  min(source.width, right + pad), min(source.height, bottom + pad)))
            canvas = Image.new('RGBA', (max(source.size), max(source.size)))
            canvas.alpha_composite(source, ((canvas.width - source.width)//2,
                                            (canvas.height - source.height)//2))
            source = canvas
    return source.resize((size, size), Image.Resampling.LANCZOS)


def dib_frame(im):
    # ICO's 32bpp BMP uses doubled header height plus a 1bpp AND transparency mask.
    w, h = im.size
    bmp = im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    xor = bmp.tobytes('raw', 'BGRA')
    mask_stride = ((w + 31) // 32) * 4
    alpha = bmp.getchannel('A')
    mask = bytearray(mask_stride * h)
    for y in range(h):
        for x in range(w):
            if alpha.getpixel((x, y)) < 64:
                mask[y * mask_stride + x // 8] |= 128 >> (x % 8)
    header = struct.pack('<IiiHHIIiiII', 40, w, 2*h, 1, 32, 0, len(xor) + len(mask), 0, 0, 0, 0)
    return header + xor + bytes(mask)


def create_icon(source):
    frames = [optical_frame(source, size) for size in SIZES]
    images = []
    for size, frame in zip(SIZES, frames):
        if size == 256:
            data = io.BytesIO()
            frame.save(data, 'PNG', optimize=True)
            images.append(data.getvalue())
        else:
            images.append(dib_frame(frame))
    directory = bytearray(struct.pack('<HHH', 0, 1, len(images)))
    offset = 6 + 16 * len(images)
    for size, frame in zip(SIZES, images):
        directory.extend(struct.pack('<BBBBHHII', 0 if size == 256 else size,
                                     0 if size == 256 else size, 0, 0, 1, 32,
                                     len(frame), offset))
        offset += len(frame)
    ICO.write_bytes(bytes(directory) + b''.join(images))
    (ROOT / 'packaging/icon.ico.b64').write_bytes(base64.b64encode(ICO.read_bytes()) + b'\n')
    frames[1].save(ROOT / 'App/Assets/Orbit32.png', optimize=True)


if __name__ == '__main__':
    create_icon(master())
