// SPDX-License-Identifier: GPL-3.0-only
using System.Net;
using System.Net.Sockets;
using UsbBridge;

internal static partial class Program
{
    private static LocalAddress Nic(string name, string ip) =>
        new(name, name, IPAddress.Parse(ip), true, true, false, false, name);

    private static async Task R4Tests()
    {
        await Test("One probe per endpoint; prefer live physical aliases", () => Check(() =>
        {
            var lan = Nic("Ethernet 3","10.1.0.12");
            var nat = Nic("vEthernet (nat)","172.26.64.1") with { Virtual=true };
            var result = AddressProbe.UniqueEndpoints([nat, lan with {Id="gone",Valid=false}, nat,
                lan with {Id="virtual",Virtual=true},lan]).ToArray();
            Is(result.Length == 2 && result.Contains(lan) && result.Contains(nat));
        }));
        await Test("LAN, EasyTier, stable and temporary IPv6 ranking", () => Check(() =>
            {
                var rows = new[]
                {
                    Nic("Ethernet", "10.1.208.121"),
                    Nic("EasyTier", "10.0.0.1") with
                    {
                        Virtual = true,
                    },
                    Nic("Ethernet", "2001:db8::1"),
                    Nic("Ethernet", "2001:db8::2") with
                    {
                        Temporary = true,
                    },
                };
                var results = rows.Select(x => AddressProbe.Classify(x, null, false)).ToArray();
                Is(
                    results.All(x => x.Status == Verdict.Ready)
                        && results.Select(x => x.Rank).SequenceEqual(new[] { 0, 1, 2, 5 })
                );
                Is(results[3].Reason.Contains("临时地址"));
            }));
        await Test("WARP, shared CGNAT, VMnet1/8 and generic tunnels", () => Check(() =>
            {
                foreach (
                    var (row, reason) in new[]
                    {
                        (Nic("CloudflareWARP", "100.96.0.47"), "WARP"),
                        (Nic("adapter", "2606:4700:cf1:1000::2f"), "WARP"),
                        (Nic("CGN", "100.96.3.4"), "CGNAT"),
                        (Nic("VMware VMnet1", "192.168.250.1"), "host-only"),
                        (Nic("VMware VMnet8", "192.168.24.1"), "虚拟网络"),
                        (Nic("overlay", "10.0.0.1") with { Virtual = true }, "隧道"),
                    }
                )
                {
                    var result = AddressProbe.Classify(row, null, true);
                    Is(result.Status == Verdict.Discouraged && result.Reason.Contains(reason));
                }
            }));
        await Test("interface and address validity precede network hints", async () =>
        {
            foreach (
                var row in new[]
                {
                    Nic("WARP", "100.96.0.47") with
                    {
                        Up = false,
                    },
                    Nic("LAN", "10.0.0.1") with
                    {
                        Valid = false,
                    },
                }
            )
                Is(
                    (
                        await AddressProbe.Test(
                            row,
                            true,
                            _ => throw new Exception("should not probe"),
                            default
                        )
                    ).Status == Verdict.Unavailable
                );
        });
        await Test("real loopback exclusive bind and occupied test port", async () =>
        {
            var row = Nic("test", "127.0.0.1");
            Is(
                (await AddressProbe.Test(row, false, _ => null, default, 0)).Status == Verdict.Ready
            );
            using var other = new TcpListener(row.IP, 0);
            other.Server.ExclusiveAddressUse = true;
            other.Start();
            Is(
                (
                    await AddressProbe.Test(
                        row,
                        false,
                        _ => null,
                        default,
                        ((IPEndPoint)other.LocalEndpoint).Port
                    )
                ).Status == Verdict.Unavailable
            );
            Is(
                (await AddressProbe.Test(row, true, _ => "其它进程监听", default)).Reason.Contains(
                    "其它进程"
                )
            );
        });
        await Test(
            "USB/IP devlist on local TCP including nonempty, invalid and truncated replies",
            async () =>
            {
                var row = Nic("test", "127.0.0.1");
                foreach (string mode in new[] { "empty", "device", "bad", "short", "timeout" })
                {
                    using var listener = new TcpListener(row.IP, 0);
                    listener.Start();
                    using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                    var reply = Task.Run(async () =>
                    {
                        using var peer = await listener.AcceptTcpClientAsync(deadline.Token);
                        var stream = peer.GetStream();
                        var request = new byte[8];
                        await stream.ReadExactlyAsync(request, deadline.Token);
                        Is(request.SequenceEqual(new byte[] { 1, 17, 128, 5, 0, 0, 0, 0 }));
                        if (mode == "timeout")
                        {
                            await Task.Delay(2750, deadline.Token);
                            return;
                        }
                        var response = new byte[mode == "device" ? 328 : 12];
                        response[0] = 1;
                        response[1] = 17;
                        response[3] = (byte)(mode == "bad" ? 6 : 5);
                        if (mode is "short" or "device")
                            response[11] = 1;
                        if (mode == "device")
                            response[323] = 1;
                        await stream.WriteAsync(response, deadline.Token);
                    });
                    var result = await AddressProbe.Test(
                        row,
                        true,
                        _ => null,
                        deadline.Token,
                        ((IPEndPoint)listener.LocalEndpoint).Port
                    );
                    await reply;
                    Is((result.Status == Verdict.Ready) == (mode is "empty" or "device"));
                }
            }
        );
        await Test("PnP and USB descriptor evidence overrides display name", () => Check(() =>
            {
                var cases = new[]
                {
                    ("03&SubClass_01&Prot_02", "鼠标"),
                    ("03&SubClass_01&Prot_01", "键盘"),
                    ("08", "U盘/移动硬盘"),
                    ("07", "打印机"),
                    ("0E", "摄像头"),
                    ("01", "音频设备"),
                    ("02&SubClass_02", "串口设备"),
                    ("09", "集线器"),
                };
                foreach (var (id, label) in cases)
                {
                    var k = DeviceTypes.Classify("mouse", "", "", [("", [@"USB\Class_" + id])]);
                    Is(k.Title == label && !k.Inferred);
                }
                Is(
                    DeviceTypes
                        .Classify("mouse", "", "", [("{4D36E96B-E325-11CE-BFC1-08002BE10318}", [])])
                        .Label == "键盘"
                );
                Is(
                    DeviceTypes
                        .Classify("Generic", "", "", [("", ["GUID_DEVINTERFACE_COMPORT"])])
                        .Label == "串口设备"
                );
                Is(
                    DeviceTypes
                        .Classify("Generic", "", "", [("", [@"HID_DEVICE_UP:F1D0_U:0001"])])
                        .Label == "加密狗"
                );
                Is(
                    DeviceTypes.Classify("generic HID", "", "", [("", [@"USB\Class_03"])]).Label
                        == "USB 设备"
                );
            }));
        await Test("remote guesses including legacy mappings and unknown devices", () => Check(() =>
            {
                Is(DeviceTypes.Infer("Mouse", "0000", "0000").Label == "鼠标（推测）");
                Is(DeviceTypes.Infer("vendor", "0529", "0001").Label == "加密狗（推测）");
                Is(DeviceTypes.Infer("vendor", "0403", "6001").Label == "串口设备（推测）");
                Is(DeviceTypes.Infer("Wireless receiver", "0000", "0000").Label == "USB 设备");
                Is(
                    Parsers.Exports(" 1-2: product : Keyboard (0001:0002)").Single().Kind.Label
                        == "键盘（推测）"
                );
            }));
        await Test("fixed minimum in effective pixels across DPI scales", () => Check(() =>
            {
                Is(WindowLimits.Width == 960 && WindowLimits.Height == 640);
                foreach (
                    var (dpi, w, h) in new[]
                    {
                        (96u, 960, 640),
                        (120u, 1200, 800),
                        (144u, 1440, 960),
                        (192u, 1920, 1280),
                    }
                )
                    Is(
                        WindowLimits.Pixels(WindowLimits.Width, dpi) == w
                            && WindowLimits.Pixels(WindowLimits.Height, dpi) == h
                    );
            }));
    }
}
