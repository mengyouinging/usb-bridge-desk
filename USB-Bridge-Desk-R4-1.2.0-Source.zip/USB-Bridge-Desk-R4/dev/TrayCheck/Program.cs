// SPDX-License-Identifier: GPL-3.0-only
using System.Drawing;
using System.Drawing.Imaging;
using Desk;

Directory.CreateDirectory(args[1]);
foreach (int size in new[] { 16, 32 })
{
    using var original = new Icon(args[0], size, size);
    using var plain = original.ToBitmap();
    foreach (var (state, color) in TrayArtwork.Palette)
    {
        using var icon = TrayArtwork.Create(original, color);
        using var bmp = icon.ToBitmap();
        var badge = bmp.GetPixel(26 * size / 32, 26 * size / 32);
        if (
            bmp.Size != new Size(size, size)
            || badge.ToArgb() != color.ToArgb()
            || bmp.GetPixel(size / 2, size / 2) != plain.GetPixel(size / 2, size / 2)
        )
            throw new Exception($"Tray artwork check failed: {size} {state}");
        bmp.Save(Path.Combine(args[1], $"tray-{size}-{state}.png"), ImageFormat.Png);
        Console.WriteLine($"PASS tray {size}px {state}");
    }
}
