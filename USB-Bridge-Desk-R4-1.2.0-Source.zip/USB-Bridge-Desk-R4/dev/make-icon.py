#!/usr/bin/env python3
"""Rebuild the layered USB orbit master and optically sized Windows icon (Pillow)."""
import base64
import math
from pathlib import Path
from PIL import Image, ImageDraw

root=Path(__file__).resolve().parents[1]
sizes=(16,32,48,64,128,256)
def render(size):
    if size==16:
        # Hint contacts, aperture and front band on the physical pixel grid.
        palette={'m':'#9AEFC2','g':'#27B47C','c':'#086047','b':'#C7A82A','y':'#FFD339','l':'#FFF39A'}
        pixels=[
            '..mmm...........', '..mcm...........', '..mcmm.....bbbbb', '...ggg.gg.bbb..b',
            '....gggggggb..by', '...bggccccgg.byy', '..bggccccccgyyy.', '.bbggcccccyyyl..',
            '.b.ggcccyyyl....', 'bb.gggyyylgg....', 'b..gyyylcgg.....', 'byyylgggggg.....',
            'yyy.....gggg....', '.........mcm....', '.........mccm...', '..........mmm...']
        im=Image.new('RGBA',(16,16))
        d=ImageDraw.Draw(im)
        for y,row in enumerate(pixels):
            for x,c in enumerate(row):
                if c in palette:d.point((x,y),palette[c])
        return im
    scale=8
    im=Image.new('RGBA',(size*scale,size*scale))
    d=ImageDraw.Draw(im)
    def point(x,y):
        angle=math.radians(-29)
        return ((50+x*math.cos(angle)-y*math.sin(angle))*im.width/100,
                (50+x*math.sin(angle)+y*math.cos(angle))*im.width/100)
    def poly(coords,color):
        d.polygon([point(x,y) for x,y in coords],fill=color)
    def arc(rx,ry,start,end,steps=120):
        return [(rx*math.cos(math.radians(start+(end-start)*i/steps)),ry*math.sin(math.radians(start+(end-start)*i/steps))) for i in range(steps+1)]
    def oval(rx,ry,color):
        poly(arc(rx,ry,0,360),color)
    def disk(start,end,color):
        poly(arc(53,16,start,end)+arc(43,8,end,start),color)
    # Far half of the disk, rear connector, body, near connector, then near half.
    disk(180,360,'#D4AA22')
    for side in (-1,1):
        def plug(v,c): poly([(x,y*side) for x,y in v],c)
        plug([(-8,23),(8,23),(8,34),(-8,34)],'#19865D')
        plug([(-11,31),(11,31),(11,46),(-11,46)],'#96EBC1')
        plug([(-8,34),(8,34),(8,43),(-8,43)],'#197153')
        if size>=32:
            for x in (-5,2):
                plug([(x,36),(x+3,36),(x+3,39),(x,39)],'#E4FFCC')
        else:
            plug([(-5,35),(5,35),(5,38),(-5,38)],'#F1FFBE')
    oval(28,28,'#23AD75')
    oval(21,21,'#086047')
    if size>=32:
        poly(arc(26,26,183,308)+arc(22,22,308,183),'#89ECB1')
    disk(0,180,'#FFCF30')
    if size>=32:
        poly(arc(51,14,4,143)+arc(49,12,143,4),'#FFF195')
    return im.resize((size,size),Image.Resampling.LANCZOS)
if __name__=='__main__':
    folder=root/'packaging'
    images=[render(s) for s in sizes]
    path=folder/'icon.ico'
    images[-1].save(path,format='ICO',sizes=[i.size for i in images],append_images=images[:-1],bitmap_format='bmp')
    (folder/'icon.ico.b64').write_bytes(base64.b64encode(path.read_bytes())+b'\n')
    images[1].save(root/'App/Assets/Orbit32.png')
