﻿# SPDX-License-Identifier: GPL-3.0-only
# Dot-sourced by capture-auto.ps1 in the same interactive desktop as the application.
$r4=@{minimum=@{};addresses=@();localTypes=@();remoteTypes=@();localDevices=@();remoteSource='read-only loopback fixture';checks=@{}}
function Enter-MinimumWindow {
    $dpi=[DeskCapture]::GetDpiForWindow($hwnd)
    $w=[int][Math]::Ceiling(960*$dpi/96)
    $h=[int][Math]::Ceiling(640*$dpi/96)
    $area=Work-Area
    if ($area.Width -lt $w -or $area.Height -lt $h) { throw "Monitor work area cannot display 960 x 640 effective pixels at $dpi DPI" }
    [void][DeskCapture]::SetWindowPos($hwnd,[IntPtr]::Zero,$area.Left,$area.Top,($w-100),($h-100),0x40)
    [void](Wait-For '960 x 640 minimum after undersized resize request' {
        $raw=[DeskCapture+Rect]::new()
        [void][DeskCapture]::GetWindowRect($hwnd,[ref]$raw)
        ($raw.Right-$raw.Left -eq $w -and $raw.Bottom-$raw.Top -eq $h)
    })
    $r4.dpi=$dpi
}
function Check-MinimumPage($page) {
    $raw=[DeskCapture+Rect]::new()
    [void][DeskCapture]::GetWindowRect($hwnd,[ref]$raw)
    $dpi=[DeskCapture]::GetDpiForWindow($hwnd)
    $width=($raw.Right-$raw.Left)*96/$dpi
    $height=($raw.Bottom-$raw.Top)*96/$dpi
    $body=Wait-For 'page scroll viewer' { By-ID 'Page.Scroll' }
    $pat=Get-Pattern $body ([Windows.Automation.ScrollPattern]::Pattern)
    $over=@()
    foreach ($e in $body.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
        if ($e.Current.IsOffscreen) { continue }
        $b=$e.Current.BoundingRectangle
        if (!$b.IsEmpty -and $b.Width -gt 0 -and ($b.Left -lt $raw.Left-1 -or $b.Right -gt $raw.Right+1)) { $over+=$e.Current.Name }
    }
    $ok=($width -eq 960 -and $height -eq 640 -and !($pat -and $pat.Current.HorizontallyScrollable) -and !$over.Count)
    $r4.minimum[$page]=@{width=$width;height=$height;withinWindow=$ok;overflow=$over}
    if (!$ok) { throw "Minimum layout failed on $page" }
}
function Capture-Rect($file,$label,$rect) {
    $area=[Drawing.Rectangle]::FromLTRB([int][Math]::Floor($rect.Left),[int][Math]::Floor($rect.Top),
        [int][Math]::Ceiling($rect.Right),[int][Math]::Ceiling($rect.Bottom))
    if ($area.Width -le 0 -or $area.Height -le 0) { throw "Cannot capture $label" }
    Save-Shot $file $label $area
}
function Capture-TitleAndTaskbar {
    $title=Wait-For 'title icon' { By-ID 'Brand.Title' } 3 -Optional
    if ($title) { Capture-Rect 'r4-title' 'installed title-bar mark' $title.Current.BoundingRectangle }
    $task=Wait-For 'application taskbar button' {
        $bar=Shell-Window 'Shell_TrayWnd'
        if (!$bar) {return}
        foreach ($el in $bar.FindAll($scope,[Windows.Automation.Condition]::TrueCondition)) {
            if (!$el.Current.IsOffscreen -and $el.Current.Name -like '*USB Bridge Desk*' -and
                ($el.Current.ClassName -match 'TaskList|Taskbar.Task' -or $el.Current.AutomationId -match 'Appid:')) {return $el}
        }
    } 3 -Optional
    if ($task) { Capture-Rect 'r4-taskbar' 'Explorer taskbar application button' $task.Current.BoundingRectangle }
}
function Capture-IconSizes {
    $form=[Windows.Forms.Form]::new()
    $form.FormBorderStyle='None';$form.StartPosition='CenterScreen';$form.TopMost=$true
    $form.AutoScaleMode='None';$form.ClientSize=[Drawing.Size]::new(90,44)
    $form.ShowInTaskbar=$false
    $icons=@();$bitmaps=@()
    try {
        foreach ($n in 16,32) {
            $ic=[Drawing.Icon]::new((Join-Path (Split-Path $AppPath) 'icon.ico'),$n,$n);$icons+=$ic
            $pic=[Windows.Forms.PictureBox]::new(); $pic.SizeMode='Normal'
            $pic.Image=$ic.ToBitmap();$bitmaps+=$pic.Image
            $pic.Size=[Drawing.Size]::new($n,$n); $pic.Left=if($n -eq 16){8}else{48};$pic.Top=6
            $form.Controls.Add($pic)
        }
        $form.Show();$form.Refresh();[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 250
        foreach($pic in $form.Controls) {
            $bounds=$pic.RectangleToScreen($pic.ClientRectangle)
            Save-Shot "r4-icon-$($pic.Width)" "installed ICO rendered at $($pic.Width) physical pixels" $bounds
        }
    } finally {
        $form.Dispose()
        foreach($bmp in $bitmaps){$bmp.Dispose()};foreach($ic in $icons){$ic.Dispose()}
        [void][DeskCapture]::SetForegroundWindow($hwnd)
    }
}
function Capture-Addresses {
    $combo=Wait-For 'completed address probes' { $c=By-ID 'Host.Addresses';if($c -and $c.Current.ItemStatus -eq 'complete'){return $c} }
    $p=Get-Pattern $combo $expand
    if($p){$p.Expand()}else{Click-Element $combo}
    try {
        $items=Wait-For 'address verdicts' {
            $candidates=$root.FindAll($scope,[Windows.Automation.PropertyCondition]::new($prop::ProcessIdProperty,$proc.Id))
            $candidates | Where-Object { $_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and
                !$_.Current.IsOffscreen -and $_.Current.Name -match '^(本机可用|不推荐|不可用) ·' }
        } 5 -Optional
        if($items){
            $r4.addresses=@($items | ForEach-Object {$_.Current.Name})
            Save-Shot 'r4-addresses' 'open address list and local verdicts' ([Windows.Forms.Screen]::FromHandle($hwnd).Bounds)
        }
    } finally { if($p){$p.Collapse()}else{[Windows.Forms.SendKeys]::SendWait('{ESC}')} }
}
function Capture-DeviceTypes($kind) {
    $row=Wait-For "$kind device row" { By-ID 'Device.Row' } 5 -Optional
    if(!$row){Log "No $kind device evidence";return}
    $condition=[Windows.Automation.PropertyCondition]::new($prop::AutomationIdProperty,'Device.Row')
    $rows=@($win.FindAll($scope,$condition) | ForEach-Object {$_})
    $r4[$kind+'Types']=@($rows | ForEach-Object {$_.Current.ItemStatus})
    $r4[$kind+'Devices']=@($rows | ForEach-Object {$_.Current.Name})
    if($kind -eq 'local'){
        $confirmed=$rows | Where-Object {$_.Current.ItemStatus -and $_.Current.ItemStatus -notmatch '推测|^USB 设备$'} | Select-Object -First 1
        if($confirmed){$row=$confirmed}
    }
    $wanted=$row.Current.Name
    $scroll=Get-Pattern $row ([Windows.Automation.ScrollItemPattern]::Pattern)
    if($scroll){$scroll.ScrollIntoView()}else{$row.SetFocus()}
    $row=Wait-For "visible $kind device" { $x=By-Property $win $prop::NameProperty $wanted;if($x -and !$x.Current.IsOffscreen){$x} }
    if($kind -eq 'local' -and ($row.Current.ItemStatus -eq 'USB 设备' -or $row.Current.ItemStatus -match '推测')) {
        Log 'The captured local row does not establish a confirmed PnP type'
    }
    if($kind -eq 'remote' -and $row.Current.ItemStatus -notmatch '推测'){throw 'Fixture remote device lacks inference label'}
    Window-Shot "r4-$kind-type" "$kind device type: $($row.Current.ItemStatus)"
}
