// SPDX-License-Identifier: GPL-3.0-only
using System.Net;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using UsbBridge;

namespace Desk;

internal sealed partial class Shell
{
    private CancellationTokenSource? probe;
    private readonly Dictionary<(string, IPAddress), LocalAddress> lastAddresses = new();
    private readonly List<AddressResult> addressRows = new();
    private Action? updatePicker;
    private string addressHint = "正在读取网卡…";
    private bool probing;
    private bool autoAddress = true;

    private static string Key(LocalAddress row) => row.Id + "/" + row.IP;

    private async void RefreshAddresses()
    {
        probe?.Cancel();
        if (page != "host" || closed)
            return;
        using var current = new CancellationTokenSource();
        probe = current;
        probing = true;
        var token = current.Token;
        bool? running = server?.Running;
        try
        {
            var previous = lastAddresses.Values.ToArray();
            var rows = await Task.Run(() => NetworkInspection.Enumerate(previous), token);
            token.ThrowIfCancellationRequested();
            var snapshot = rows.DistinctBy(a => (a.Id, a.IP)).ToDictionary(a => (a.Id, a.IP));
            lastAddresses.Clear();
            addressRows.Clear();
            foreach (var (key, row) in snapshot)
            {
                lastAddresses[key] = row;
                addressRows.Add(new(row, Verdict.Pending, "正在检查接口、监听和服务。", 9));
            }
            addressHint = "检测中…";
            updatePicker?.Invoke();
            using var clock = CancellationTokenSource.CreateLinkedTokenSource(token);
            clock.CancelAfter(TimeSpan.FromMilliseconds(2500));
            var deadline = clock.Token;
            var firewall = Task.Run(
                () =>
                {
                    try
                    {
                        return Firewall.ExplicitBlocks(rows, deadline);
                    }
                    catch (OperationCanceledException) when (deadline.IsCancellationRequested)
                    {
                        return new HashSet<IPAddress>();
                    }
                    catch (Exception ex)
                    {
                        Program.Trace("Firewall inventory: " + ex.Message);
                        return new HashSet<IPAddress>();
                    }
                },
                token
            );
            Func<IPAddress, string?> listener = _ => null;
            if (running == true)
            {
                try
                {
                    listener = await Task.Run(NetworkInspection.SnapshotListeners, token)
                        .WaitAsync(deadline);
                }
                catch (Exception e) when (!token.IsCancellationRequested)
                {
                    Program.Trace(e.Message);
                    listener = _ => "无法读取本机监听信息。";
                }
            }
            await Task.WhenAll(
                snapshot.Values.Select(async row =>
                {
                    AddressResult result;
                    try
                    {
                        result = await Task.Run(
                                () => AddressProbe.Test(row, running, listener, deadline),
                                token
                            )
                            .WaitAsync(deadline);
                    }
                    catch (OperationCanceledException) when (!token.IsCancellationRequested)
                    {
                        result = AddressProbe.Classify(
                            row,
                            "本机检测超时，请刷新并检查服务或防火墙。",
                            running == true
                        );
                    }
                    token.ThrowIfCancellationRequested();
                    int index = addressRows.FindIndex(r =>
                        r.Address.Id == row.Id && r.Address.IP.Equals(row.IP)
                    );
                    addressRows[index] = result;
                    updatePicker?.Invoke();
                })
            );
            // Socket probes update the dropdown immediately. Merge explicit firewall
            // blocks as soon as the shared policy inventory completes.
            HashSet<IPAddress> blocks;
            try
            {
                blocks = await firewall.WaitAsync(deadline);
            }
            catch (OperationCanceledException) when (!token.IsCancellationRequested)
            {
                blocks = [];
            }

            token.ThrowIfCancellationRequested();
            for (int i = 0; i < addressRows.Count; i++)
            {
                var r = addressRows[i];
                if (r.Status != Verdict.Unavailable && blocks.Contains(r.Address.IP))
                    addressRows[i] = AddressProbe.Classify(
                        r.Address,
                        "Windows 防火墙有明确匹配的入站阻止规则。",
                        running == true
                    );
            }
            addressHint =
                snapshot.Count == 0
                    ? "未发现可检测的网卡地址。"
                    : "没有本机可用地址，请展开查看原因。";
            updatePicker?.Invoke();
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
        catch (Exception e)
        {
            if (!token.IsCancellationRequested)
            {
                addressRows.Clear();
                addressHint = "地址检测未完成：" + e.Message;
                updatePicker?.Invoke();
            }
        }
        finally
        {
            if (ReferenceEquals(probe, current))
            {
                probe = null;
                probing = false;
                updatePicker?.Invoke();
            }
        }
    }

    private void AddAddressPicker(StackPanel link)
    {
        var combo = new ComboBox
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
        };
        AutomationProperties.SetAutomationId(combo, "Host.Addresses");
        var description = Muted("");
        var copy = Btn("复制地址", () => Done(() =>
            {
                if (combo.SelectedItem is ComboBoxItem { Tag: AddressResult r })
                    Copy(r.Address.Endpoint);
            }));
        bool updating = false;
        void Update()
        {
            updating = true;
            try
            {
                AutomationProperties.SetItemStatus(combo, probing ? "pending" : "complete");
                var sorted = addressRows
                    .OrderBy(r => r.Status)
                    .ThenBy(r => r.Rank)
                    .ThenBy(r => r.Address.Adapter, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(r => r.Address.Endpoint, StringComparer.Ordinal)
                    .ToList();
                var choice = autoAddress
                    ? null
                    : sorted.FirstOrDefault(r =>
                        Key(r.Address) == selectedAddress
                        && r.Status is Verdict.Ready or Verdict.Discouraged
                    );
                choice ??= sorted.FirstOrDefault(r => r.Status == Verdict.Ready);
                // Reuse containers to preserve an open dropdown and keyboard focus as probes complete.
                for (int i = 0; i < sorted.Count; i++)
                {
                    var r = sorted[i];
                    var item = combo
                        .Items.OfType<ComboBoxItem>()
                        .FirstOrDefault(c =>
                            c.Tag is AddressResult old && Key(old.Address) == Key(r.Address)
                        );
                    if (item == null)
                    {
                        item = new();
                        combo.Items.Insert(i, item);
                    }
                    else if (combo.Items.IndexOf(item) != i)
                    {
                        combo.Items.Remove(item);
                        combo.Items.Insert(i, item);
                    }
                    if (!Equals(item.Tag, r))
                    {
                        item.Tag = r;
                        item.Content = Text(r.Summary + "\n" + r.Reason, 14);
                        item.Opacity = r.Status == Verdict.Unavailable ? .62 : 1;
                        AutomationProperties.SetName(item, r.Summary + " " + r.Reason);
                    }
                    if (item.Content is TextBlock text)
                        text.MaxWidth = Math.Max(
                            200,
                            combo.ActualWidth > 0 ? combo.ActualWidth - 64 : 470
                        );
                }
                while (combo.Items.Count > sorted.Count)
                    combo.Items.RemoveAt(combo.Items.Count - 1);
                combo.PlaceholderText = sorted.Any(r => r.Status == Verdict.Pending)
                    ? "检测中…"
                    : "请选择地址";
                combo.SelectedIndex = choice == null ? -1 : sorted.IndexOf(choice);
                copy.IsEnabled = choice != null;
                description.Text = choice?.Reason ?? addressHint;
            }
            finally
            {
                updating = false;
            }
        }
        combo.SelectionChanged += async (_, _) =>
        {
            if (updating || combo.SelectedItem is not ComboBoxItem { Tag: AddressResult r })
                return;
            if (r.Status is Verdict.Pending or Verdict.Unavailable)
            {
                Update();
                if (
                    r.Status == Verdict.Unavailable
                    && await Confirm(
                        "此地址不可用",
                        r.Address.Endpoint + "\n" + r.Reason,
                        "复制地址"
                    )
                )
                    Copy(r.Address.Endpoint);
                return;
            }
            autoAddress = false;
            selectedAddress = Key(r.Address);
            description.Text = r.Reason;
            copy.IsEnabled = true;
        };
        combo.SizeChanged += (_, _) => Update();
        updatePicker = Update;
        Update();
        Add(
            link,
            Split(combo, copy),
            description,
            Muted("仅验证本机绑定或服务握手。对方能否连接，需在对方电脑实测。")
        );
    }
}
