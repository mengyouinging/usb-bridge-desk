# SPDX-License-Identifier: GPL-3.0-only
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$framework='Microsoft.WindowsAppRuntime.1.8'
$minimum=[version]'8000.994.2142.0'
$stage=Join-Path $env:ProgramFiles ('USBBridgeRuntime-'+[guid]::NewGuid())
$log=Join-Path $env:TEMP ('usb-bridge-runtime-'+[guid]::NewGuid()+'.log')
function Has-DesktopRuntime {
    $root=Join-Path $env:ProgramFiles 'dotnet\shared\Microsoft.WindowsDesktop.App'
    return [bool](Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -match '^10\.0\.\d+$' -and [version]$_.Name -ge [version]'10.0.15'
    } | Select-Object -First 1)
}
function Has-AppRuntime {
    $fw=Get-AppxPackage -Name $framework | Where-Object { $_.Architecture -eq 'X64' -and [version]$_.Version -ge $minimum -and $_.Status -eq 'Ok' }
    $ddlm=Get-AppxPackage -Name 'Microsoft.WinAppRuntime.DDLM.*' | Where-Object { $_.Architecture -eq 'X64' -and [version]$_.Version -ge $minimum -and ([version]$_.Version).Major -eq 8000 -and $_.Status -eq 'Ok' }
    return [bool]($fw -and $ddlm)
}
function Install-MicrosoftRuntime($name,$url,$algorithm,$digest,$options) {
    $file=Join-Path $stage ($name+'.exe')
    Write-Output "Downloading $name from Microsoft"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $file -TimeoutSec 240
    if ((Get-FileHash -Algorithm $algorithm -LiteralPath $file).Hash -ne $digest) { throw "$name checksum mismatch" }
    $sig=Get-AuthenticodeSignature -LiteralPath $file
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation(,|$)') { throw "$name Microsoft signature validation failed" }
    $p=Start-Process -FilePath $file -ArgumentList $options -PassThru -Wait
    Write-Output "$name installer exit=$($p.ExitCode)"
    if ($p.ExitCode -in @(1641,3010)) { $script:reboot=$true }
    elseif ($p.ExitCode -ne 0) { throw "$name returned $($p.ExitCode)" }
}
$reboot=$false
try {
    Start-Transcript -Path $log | Out-Null
    New-Item -ItemType Directory -Path $stage | Out-Null
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    if (-not (Has-DesktopRuntime)) {
        Install-MicrosoftRuntime 'DesktopRuntime' 'https://builds.dotnet.microsoft.com/dotnet/WindowsDesktop/10.0.15/windowsdesktop-runtime-10.0.15-win-x64.exe' 'SHA512' 'f838960962172f1a769c49fa600e6f60f56f8d08a28e3cb878890ffc2e3a7a2e1b65697588e23efa767b8b8e8523ec01f55e875120507dde16d9a0869102dab3' '/install /quiet /norestart'
    }
    if (-not (Has-AppRuntime)) {
        Install-MicrosoftRuntime 'WindowsAppRuntime' 'https://aka.ms/windowsappsdk/1.8/1.8.260921001/windowsappruntimeinstall-x64.exe' 'SHA256' '7c092e85fc1e3e7cb2bd7d549aaab03caf924131f15d9b20b1855457a98205aa' '--quiet'
    }
    if ((-not (Has-DesktopRuntime)) -or (-not (Has-AppRuntime))) { throw 'Runtime registration incomplete. Check Windows app deployment policy and rerun setup.' }
    Get-AppxPackage -Name $framework | Where-Object { $_.Architecture -eq 'X64' } |
        ForEach-Object { Write-Output "Registered $($_.PackageFullName) status=$($_.Status)" }
    Write-Output "Validated x64 desktop runtime and Windows App Runtime for $([Environment]::UserName)"
    if($reboot){exit 3010}
    exit 0
} catch { Write-Output "$($_.Exception.Message) - $log"; exit 1 }
finally { if(Test-Path $stage){Remove-Item -LiteralPath $stage -Recurse -Force}; Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
