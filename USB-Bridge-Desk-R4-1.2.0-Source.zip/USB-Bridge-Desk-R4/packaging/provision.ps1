param(
    [Parameter(Mandatory=$true)][ValidateSet('check','install','uninstall')][string]$Mode
)
$ErrorActionPreference = 'Stop'
$base = Join-Path $env:ProgramFiles 'USB Bridge Desk Engines'
$stateKey = 'HKLM:\SOFTWARE\USBBridgeDesk\Engines'
$hostExe = Join-Path $base 'Host\usbipd.exe'
$integratedHost = Join-Path $env:ProgramFiles 'USB Bridge Desk\resources\host\usbipd.exe'
$firewallName = 'USBBridgeDesk-IntegratedHost'
$clientExe = Join-Path $base 'Client\usbip.exe'
$clientUninstall = Join-Path $base 'Client\unins000.exe'
$hostKey = 'HKLM:\SOFTWARE\usbipd-win'
$clientKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{199505b0-b93d-4521-a8c7-897818e0205a}_is1'
$msiexec = Join-Path $env:SystemRoot 'System32\msiexec.exe'
$restart = $false
$sc = Join-Path $env:SystemRoot 'System32\sc.exe'

function Test-SystemService([string]$Name) {
    & $sc query $Name | Out-Null
    return $LASTEXITCODE -eq 0
}

function Confirm-LocalEnvironment {
    if (Get-Process -Name UsbBridgeDesk -ErrorAction SilentlyContinue) {
        throw 'Close USB Bridge Desk before installing or removing it.'
    }
    $existing = Get-Service -Name usbipd -ErrorAction SilentlyContinue
    if ($existing -and $existing.Status -ne 'Stopped' -and (Test-Path $stateKey)) {
        throw 'Stop USB sharing and close USB Bridge Desk before continuing.'
    }
    if ($Mode -eq 'uninstall') { return }
    if (Test-Path (Join-Path $env:ProgramFiles 'USB Bridge Desk\resources\app.asar')) {
        throw 'Stop USB sharing, exit the legacy USB Bridge Desk and uninstall it before installing R4. Per-user profiles are kept.'
    }
    $hostExternal = (Get-ItemProperty -Path $hostKey -Name APPLICATIONFOLDER -ErrorAction SilentlyContinue).APPLICATIONFOLDER
    $clientExternal = (Get-ItemProperty -Path $clientKey -Name InstallLocation -ErrorAction SilentlyContinue).InstallLocation
    if (($hostExternal -and $hostExternal.TrimEnd('\') -ne (Split-Path $hostExe)) -or
        ($clientExternal -and $clientExternal.TrimEnd('\') -ne (Split-Path $clientExe)) -or
        ((Get-Service -Name usbipd -ErrorAction SilentlyContinue) -and -not $hostExternal) -or
        ((Test-SystemService 'usbip2_ude') -and -not $clientExternal -and -not (Test-Path -LiteralPath $clientExe)) -or
        ((Test-SystemService 'VBoxUSBMon') -and -not $hostExternal)) {
        throw 'A separate USB/IP installation is registered. Use a clean Windows test machine or remove it after backing up its settings.'
    }
}
function Invoke-Engine([string]$File, [string]$Arguments, [int[]]$Accepted) {
    $child = Start-Process -FilePath $File -ArgumentList $Arguments -Wait -PassThru -WindowStyle Hidden
    if ($child.ExitCode -notin $Accepted) {
        throw "$([IO.Path]::GetFileName($File)) returned $($child.ExitCode)."
    }
    if ($child.ExitCode -in @(1641,3010)) { $script:restart = $true }
}
function Assert-Asset([string]$File, [string]$Sha) {
    if ((Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash -ne $Sha) {
        throw "Bundled component checksum mismatch: $([IO.Path]::GetFileName($File))."
    }
}
function LogPath([string]$Type) {
    # A unique basename avoids colliding with any earlier installer run.
    return Join-Path $env:TEMP ("usb-bridge-" + $Type + "-" + [Guid]::NewGuid() + ".log")
}
try {
    Confirm-LocalEnvironment
    if ($Mode -eq 'check') { exit 0 }
    if ($Mode -eq 'install') {
        $hostMsi = Join-Path $PSScriptRoot 'usbipd-win_5.3.0_x64.msi'
        $clientSetup = Join-Path $PSScriptRoot 'USBip-0.9.8.1-x64.exe'
        Assert-Asset $hostMsi '1c984914aec944de19b64eff232421439629699f8138e3ddc29301175bc6d938'
        Assert-Asset $clientSetup '38cad6d4432b52d5bb9409d9ad03b72fdffc4ada4cd3a48fbeca1a2752a8518a'
        # Official usbipd-win 5.3.0 x64 MSI product code, verified against WinGet.
        $product = '{EA1D5623-E6A7-4E4A-9259-E39722050300}'
        New-Item -Path $stateKey -Force | Out-Null
        if (-not (Test-Path -LiteralPath $hostExe) -or -not (Get-Service -Name usbipd -ErrorAction SilentlyContinue)) {
            $log = LogPath 'host-install'
            $folder = Split-Path $hostExe
            Write-Output "usbipd-win setup log: $log"
            Invoke-Engine $msiexec ('/i "' + $hostMsi + '" APPLICATIONFOLDER="' + $folder + '" /qn /norestart /L*v "' + $log + '"') @(0,1641,3010)
            New-ItemProperty -Path $stateKey -Name HostProduct -Value $product -Force | Out-Null
            Set-Service -Name usbipd -StartupType Manual
            if ((Get-Service -Name usbipd).Status -ne 'Stopped') { Stop-Service -Name usbipd }
        }
        if (-not (Test-Path -LiteralPath $integratedHost)) { throw 'Bundled host runtime is missing.' }
        $image = '"' + $integratedHost + '" server'
        $service = Get-CimInstance Win32_Service -Filter "Name='usbipd'"
        if ($service.PathName -ne $image) {
            $changed = Invoke-CimMethod -InputObject $service -MethodName Change -Arguments @{PathName=$image}
            if ($changed.ReturnValue -ne 0) { throw "Could not configure host service ($($changed.ReturnValue))." }
        }
        if ((Get-CimInstance Win32_Service -Filter "Name='usbipd'").PathName -ne $image) {
            throw 'Integrated service image path was not saved.'
        }
        if (-not (Get-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -Name $firewallName -DisplayName 'USB Bridge Desk (TCP 3240)' -Program $integratedHost -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3240 -RemoteAddress LocalSubnet -Profile Any | Out-Null
        }
        if (-not (Test-Path -LiteralPath $clientExe) -or -not (Test-SystemService 'usbip2_ude')) {
            $log = LogPath 'client-install'
            $folder = Split-Path $clientExe
            Write-Output "USBip UDE setup log: $log"
            Invoke-Engine $clientSetup ('/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /RESTARTEXITCODE=3010 /COMPONENTS=main,client /TASKS=vcredist /DIR="' + $folder + '" /LOG="' + $log + '"') @(0,3010)
            New-ItemProperty -Path $stateKey -Name ClientOwned -Value 1 -PropertyType DWord -Force | Out-Null
        }
        if (-not (Test-Path -LiteralPath $hostExe) -or -not (Test-Path -LiteralPath $clientExe)) {
            throw 'Setup could not locate the installed USB/IP programs.'
        }
        if (-not (Test-SystemService 'usbip2_ude')) {
            throw 'The virtual USB controller was not registered. Inspect the client setup log.'
        }
    } else {
        $owned = Get-ItemProperty -Path $stateKey -ErrorAction SilentlyContinue
        if ($owned.ClientOwned -eq 1) {
            if (-not (Test-Path -LiteralPath $clientUninstall)) { throw 'The bundled client uninstaller is missing. Repair using the setup package before removal.' }
            $log = LogPath 'client-remove'
            if (Test-Path -LiteralPath $clientExe) {
                Invoke-Engine $clientExe 'detach --all' @(0)
            }
            Invoke-Engine $clientUninstall ('/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /LOG="' + $log + '"') @(0,3010)
            # Upstream marks removal as restart-required, even with /NORESTART.
            $restart = $true
            Remove-ItemProperty -Path $stateKey -Name ClientOwned
        }
        Get-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        if ($owned.HostProduct -match '^\{[0-9a-f-]{36}\}$') {
            $log = LogPath 'host-remove'
            Invoke-Engine $msiexec ('/x ' + $owned.HostProduct + ' /qn /norestart /L*v "' + $log + '"') @(0,1605,1641,3010)
            Remove-ItemProperty -Path $stateKey -Name HostProduct
        }
    }
    if ($restart) { exit 3010 }
    exit 0
} catch {
    Write-Output $_.Exception.Message
    exit 1
}
