// SPDX-License-Identifier: GPL-3.0-only
using System.Text.RegularExpressions;

namespace UsbBridge;

public sealed record DeviceType(string Title, string Glyph, bool Inferred = false)
{
    public string Label => Title + (Inferred ? "（推测）" : "");
}

public static class DeviceTypes
{
    private static readonly DeviceType Mouse = new("鼠标", "\uE962"),
        Keyboard = new("键盘", "\uE765"),
        Disk = new("U盘/移动硬盘", "\uEDA2"),
        Printer = new("打印机", "\uE749"),
        Camera = new("摄像头", "\uE722"),
        Audio = new("音频设备", "\uE767"),
        Serial = new("串口设备", "\uE968"),
        Key = new("加密狗", "\uE8D7"),
        Hub = new("集线器", "\uE968"),
        Unknown = new("USB 设备", "\uE88E");

    public static DeviceType Infer(string name, string vid, string pid)
    {
        var rules = new (string Pattern, DeviceType Kind)[]
        {
            (@"\b(mouse|trackball)\b|鼠标", Mouse),
            (@"\bkeyboard\b|键盘", Keyboard),
            (@"flash drive|mass storage|thumb drive|portable ssd|移动硬盘|存储|优盘|U盘", Disk),
            (@"printer|打印机", Printer),
            (@"camera|webcam|摄像头", Camera),
            (@"audio|microphone|headset|音频|麦克风", Audio),
            (@"serial|uart|串口", Serial),
            (@"sentinel (hasp|hl)|\bhasp\b|security key|加密狗", Key),
            (@"\bhub\b|集线器", Hub),
        };
        foreach (var (pattern, type) in rules)
            if (
                Regex.IsMatch(
                    name,
                    pattern,
                    RegexOptions.IgnoreCase | RegexOptions.CultureInvariant
                )
            )
                return type with { Inferred = true };
        var product = (vid + ":" + pid).ToLowerInvariant() switch
        {
            "0403:6001" or "10c4:ea60" or "1a86:7523" => Serial,
            "0529:0001" => Key,
            "046d:c077" => Mouse,
            _ => Unknown,
        };
        return product == Unknown ? Unknown : product with { Inferred = true };
    }

    public static DeviceType Classify(
        string name,
        string vid,
        string pid,
        IEnumerable<(string ClassGuid, string[] CompatibleIds)> nodes
    )
    {
        var kinds = new List<DeviceType>();
        foreach (var (guid, ids) in nodes)
        {
            DeviceType? type = guid.Trim('{', '}').ToLowerInvariant() switch
            {
                "4d36e96f-e325-11ce-bfc1-08002be10318" => Mouse,
                "4d36e96b-e325-11ce-bfc1-08002be10318" => Keyboard,
                "4d36e967-e325-11ce-bfc1-08002be10318" => Disk,
                "4d36e979-e325-11ce-bfc1-08002be10318" => Printer,
                "ca3e7ab9-b4c3-4ae6-8251-579ef933890f" => Camera,
                "c166523c-fe0c-4a94-a586-f1a80cfbbf3e" => Audio,
                _ => null,
            };
            if (type != null)
                kinds.Add(type);
            foreach (var id in ids)
            {
                var match = Regex.Match(
                    id,
                    @"^USB\\Class_([0-9a-f]{2})(?:&SubClass_([0-9a-f]{2}))?(?:&Prot_([0-9a-f]{2}))?$",
                    RegexOptions.IgnoreCase
                );
                if (!match.Success)
                    continue;
                type = (
                    match.Groups[1].Value.ToUpperInvariant(),
                    match.Groups[2].Value,
                    match.Groups[3].Value
                ) switch
                {
                    ("03", "01", "02") => Mouse,
                    ("03", "01", "01") => Keyboard,
                    ("08", _, _) => Disk,
                    ("07", _, _) => Printer,
                    ("0E", _, _) => Camera,
                    ("01", _, _) => Audio,
                    ("02", "02", _) => Serial,
                    ("09", _, _) => Hub,
                    _ => null,
                };
                if (type != null)
                    kinds.Add(type);
            }
            if (ids.Any(id => id.Contains("UP:F1D0_U:0001", StringComparison.OrdinalIgnoreCase)))
                kinds.Add(Key);
            // Ports also includes parallel ports. COMPORT distinguishes serial devices.
            if (
                ids.Any(id =>
                    id.Equals("PNP0501", StringComparison.OrdinalIgnoreCase)
                    || id.Equals("GUID_DEVINTERFACE_COMPORT", StringComparison.OrdinalIgnoreCase)
                )
            )
                kinds.Add(Serial);
        }
        var found = kinds.Distinct().ToArray();
        return found.Length switch
        {
            0 => Infer(name, vid, pid),
            1 => found[0],
            _ => new(string.Join(" / ", found.Select(t => t.Title)), found[0].Glyph),
        };
    }
}
