﻿param(
    [Parameter(Mandatory=$true)][string]$AppPath,
    [Parameter(Mandatory=$true)][string]$UninstallerPath,
    [Parameter(Mandatory=$true)][string]$InstallerPath,
    [Parameter(Mandatory=$true)][string]$FixtureUrl,
    [string]$OutDir=(Join-Path $PWD 'screenshots')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Drawing,System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class R5WindowProbe {
    public struct Rect { public int Left, Top, Right, Bottom; }
    public sealed class WindowInfo {
        public IntPtr Handle;
        public int ProcessId;
        public string Title;
        public bool Visible;
    }
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextLength(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hwnd, System.Text.StringBuilder text, int count);
    public static WindowInfo[] AllWindows() {
        var windows = new List<WindowInfo>();
        EnumWindows((hwnd, data) => {
            uint owner;
            GetWindowThreadProcessId(hwnd, out owner);
            var title = new System.Text.StringBuilder(GetWindowTextLength(hwnd) + 1);
            GetWindowText(hwnd, title, title.Capacity);
            windows.Add(new WindowInfo {
                Handle = hwnd, ProcessId = (int)owner,
                Title = title.ToString(), Visible = IsWindowVisible(hwnd)
            });
            return true;
        }, IntPtr.Zero);
        return windows.ToArray();
    }
    public sealed class ChildInfo {
        public IntPtr Handle;
        public int ProcessId;
        public string ClassName;
        public string Text;
        public bool Visible;
        public bool Enabled;
    }
    [DllImport("user32.dll", EntryPoint = "EnumChildWindows")]
    private static extern bool EnumChildWindows(IntPtr parent, EnumWindowsProc callback, IntPtr data);
    [DllImport("user32.dll", EntryPoint = "GetWindowTextW", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern int GetWindowTextW(IntPtr hwnd, System.Text.StringBuilder text, int count);
    [DllImport("user32.dll", EntryPoint = "GetClassNameW", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern int GetClassNameW(IntPtr hwnd, System.Text.StringBuilder text, int count);
    [DllImport("user32.dll")] private static extern bool IsWindowEnabled(IntPtr hwnd);
    [DllImport("user32.dll", EntryPoint = "SendMessageW", ExactSpelling = true)]
    private static extern IntPtr SendMessage(IntPtr hwnd, uint message, IntPtr wParam, IntPtr lParam);
    public static ChildInfo[] ChildWindows(IntPtr parent) {
        var children = new List<ChildInfo>();
        EnumChildWindows(parent, (hwnd, data) => {
            uint owner;
            GetWindowThreadProcessId(hwnd, out owner);
            var text = new System.Text.StringBuilder(GetWindowTextLength(hwnd) + 1);
            GetWindowTextW(hwnd, text, text.Capacity);
            var className = new System.Text.StringBuilder(256);
            GetClassNameW(hwnd, className, className.Capacity);
            children.Add(new ChildInfo {
                Handle = hwnd, ProcessId = (int)owner, ClassName = className.ToString(),
                Text = text.ToString(), Visible = IsWindowVisible(hwnd), Enabled = IsWindowEnabled(hwnd)
            });
            return true;
        }, IntPtr.Zero);
        return children.ToArray();
    }
    public static System.Threading.Tasks.Task<IntPtr> BeginButtonClick(IntPtr hwnd) {
        const uint BM_CLICK = 0x00F5;
        // A synchronous BM_CLICK can open a modal guard and block until OK is clicked.
        // SendMessage runs on a worker so the acceptance thread can inspect/close that guard.
        return System.Threading.Tasks.Task.Run(() => SendMessage(hwnd, BM_CLICK, IntPtr.Zero, IntPtr.Zero));
    }
    private delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr data);
    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr data);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(
        IntPtr hwnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    public static IntPtr[] ForProcess(int processId) {
        var windows = new List<IntPtr>();
        EnumWindows((hwnd, data) => {
            uint owner;
            GetWindowThreadProcessId(hwnd, out owner);
            if (owner == processId) windows.Add(hwnd);
            return true;
        }, IntPtr.Zero);
        return windows.ToArray();
    }
}
'@
$root = [Windows.Automation.AutomationElement]::RootElement
$scope = [Windows.Automation.TreeScope]::Descendants
$childrenScope = [Windows.Automation.TreeScope]::Children
$buttonType = [Windows.Automation.ControlType]::Button
$invoke = [Windows.Automation.InvokePattern]::Pattern
$automationIdProperty = [Windows.Automation.AutomationElement]::AutomationIdProperty
$processIdProperty = [Windows.Automation.AutomationElement]::ProcessIdProperty
$controlTypeProperty = [Windows.Automation.AutomationElement]::ControlTypeProperty
$nameProperty = [Windows.Automation.AutomationElement]::NameProperty
$newLine = [Environment]::NewLine
$trueCondition = [Windows.Automation.Condition]::TrueCondition
New-Item -ItemType Directory -Force $OutDir | Out-Null
$log = Join-Path $OutDir 'acceptance.log'
function Log([string]$text) {
    $timestamp = Get-Date -Format o
    Add-Content -LiteralPath $log -Encoding UTF8 -Value ("{0} {1}" -f $timestamp, $text)
}
function New-PropertyCondition($property, $value) {
    New-Object -TypeName Windows.Automation.PropertyCondition -ArgumentList $property, $value
}
function New-AndCondition([Windows.Automation.Condition[]]$conditions) {
    New-Object -TypeName Windows.Automation.AndCondition -ArgumentList (,$conditions)
}
function New-AutomationElementList {
    New-Object -TypeName 'System.Collections.Generic.List[Windows.Automation.AutomationElement]'
}
function New-ConditionList {
    New-Object -TypeName 'System.Collections.Generic.List[Windows.Automation.Condition]'
}
function Get-StartupPromptOpenedAt {
    $startupLog=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    if (-not (Test-Path -LiteralPath $startupLog)) { return $null }
    $line = Get-Content -LiteralPath $startupLog -Encoding UTF8 |
        Where-Object { $_ -match 'Update dialog Opened \(' } |
        Select-Object -Last 1
    if ($line -match '^(\S+) Update dialog Opened \(') {
        try { return [DateTimeOffset]::Parse($Matches[1]).LocalDateTime }
        catch { return $null }
    }
    return $null
}
function Get-ButtonAutomationId([string[]]$names,[string]$label) {
    foreach ($name in $names) {
        if ($name -eq '下载并安装') { return 'UpdatePrompt.Install' }
        if ($name -eq '稍后') { return 'UpdatePrompt.Defer' }
    }
    switch ($label) {
        'Settings navigation' { return 'Nav.settings' }
        'settings update check' { return 'Settings.UpdateCheck' }
    }
    return $null
}
function Normalize-ButtonName([string]$name) {
    return ([regex]::Replace($name.Trim(), '\s*\(&?[^()\s]\)$', '')).Trim()
}
function Test-ButtonName([string]$candidateName,[string[]]$names) {
    $normalizedCandidate=Normalize-ButtonName $candidateName
    foreach ($name in $names) {
        $normalizedName=Normalize-ButtonName $name
        if ([string]::Equals($normalizedCandidate, $normalizedName,
            [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}
function Find-Button([string[]]$names, [int]$processId=0, [string]$label='') {
    $automationId=Get-ButtonAutomationId $names $label
    if ($automationId) {
        $automationIdCondition = New-PropertyCondition $automationIdProperty $automationId
        $processCondition = New-PropertyCondition $processIdProperty $processId
        $conditions = @($processCondition, $automationIdCondition)
        $pidAndAutomationId = New-AndCondition $conditions
        $startupIds = @(
            'UpdatePrompt.Install', 'UpdatePrompt.Defer',
            'Nav.settings', 'Settings.UpdateCheck'
        )
        if ($automationId -in $startupIds) {
            if (-not $script:startupPromptLookupMode) { return $null }
            if ($script:startupPromptLookupMode -eq 'main-window-automation-id') {
                $searchRoot=$script:startupPromptMainWindow
            } else {
                $searchRoot=$root
            }
            $item=$searchRoot.FindFirst($scope,$pidAndAutomationId)
        } else {
            $item=$root.FindFirst($scope,$pidAndAutomationId)
        }
        if ($item -and ($processId -le 0 -or $item.Current.ProcessId -eq $processId)) {
            $script:lastButtonLookup = (
                "AutomationId='{0}' via={1}" -f $automationId,
                $script:startupPromptLookupMode
            )
            return $item
        }
        $script:lastButtonLookup = "AutomationId='{0}' miss" -f $automationId
        return $null
    }
    $pidCondition=$null
    if ($processId -gt 0) {
        $pidCondition = New-PropertyCondition $processIdProperty $processId
    } else {
        $pidCondition = $trueCondition
    }
    $items=$root.FindAll($scope,$pidCondition)
    foreach ($name in $names) {
        foreach ($candidate in $items) {
            $candidateName=$candidate.Current.Name
            $candidateType=$candidate.Current.ControlType.ProgrammaticName
            if ($candidateType -eq 'ControlType.Button' -and (Test-ButtonName $candidateName @($name))) {
                if ($processId -gt 0) {
                    $candidateProcessId=$candidate.Current.ProcessId
                    if ($candidateProcessId -ne $processId) {
                        $message = "Find-Button PID verification failed name='{0}' " +
                            'expected={1} actual={2}'
                        Log ($message -f $candidateName, $processId, $candidateProcessId)
                        continue
                    }
                }
                $script:lastButtonLookup = 'FindAll(PID)+dump-style Current ' +
                    'Name/ProgrammaticName string filter'
                return $candidate
            }
        }
    }
    $script:lastButtonLookup = 'miss'
    return $null
}
function Wait-Window([int]$processId,[int]$seconds=30) {
    $windowType=[Windows.Automation.ControlType]::Window
    $typeCondition = New-PropertyCondition $controlTypeProperty $windowType
    $pidCondition = New-PropertyCondition $processIdProperty $processId
    $conditions = @($typeCondition, $pidCondition)
    $condition = New-AndCondition $conditions
    $until=(Get-Date).AddSeconds($seconds)
    $keepWaiting = $true
    while ($keepWaiting) {
        $item=$root.FindFirst($childrenScope,$condition)
        if ($item) { return $item }
        Start-Sleep -Milliseconds 200
        $keepWaiting = (Get-Date) -lt $until
    }
    throw "Timed out waiting for application main window (PID $processId)."
}
function Write-StartupPromptProbe([int]$processId) {
    if (-not $script:startupPromptProbeStart) { $script:startupPromptProbeStart=Get-Date }
    $elapsed=[math]::Round(((Get-Date)-$script:startupPromptProbeStart).TotalSeconds,1)
    $buttonName='下载并安装'
    $pidCondition = New-PropertyCondition $processIdProperty $processId
    $elements=$root.FindAll($scope,$pidCondition)
    $dumpRows = New-Object -TypeName 'System.Collections.Generic.List[string]'
    $firstPassButton=$null
    foreach ($candidate in $elements) {
        try {
            $candidateName=$candidate.Current.Name
            $candidateType=$candidate.Current.ControlType.ProgrammaticName
            $dumpRows.Add("$candidateType|$candidateName")
        } catch {
            $errorType = $_.Exception.GetType().Name
            $dumpRows.Add(('<property-error:{0}>' -f $errorType))
        }
    }
    $dumpButtons=@($dumpRows | Where-Object { $_ -match '^ControlType\.Button\|' })
    $dumpButtonsText=$dumpButtons -join '; '
    $dumpRowsText=$dumpRows -join ' || '
    $elementCount=$elements.Count
    $message = 'startup prompt probe elapsed_since_first_probe={0}s pass1-dump ' +
        'count={1} buttons={2} tree={3}'
    Log ($message -f $elapsed, $elementCount, $dumpButtonsText, $dumpRowsText)

    $exactMatches = New-AutomationElementList
    foreach ($candidate in $elements) {
        try {
            if ($candidate.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and
                $candidate.Current.Name -eq $buttonName) {
                $exactMatches.Add($candidate)
                if (-not $firstPassButton) { $firstPassButton=$candidate }
            }
        } catch {
            $errorType = $_.Exception.GetType().Name
            Log ('startup prompt probe pass2-property-error type={0}' -f $errorType)
        }
    }
    $collectionCount = $elements.Count
    $targetButton = $exactMatches.Count -gt 0
    $matchCount = $exactMatches.Count
    $message = 'startup prompt probe elapsed_since_first_probe={0}s ' +
        'pass2-string-match collectionCount={1} targetButton={2} matches={3}'
    Log ($message -f $elapsed, $collectionCount, $targetButton, $matchCount)

    $broadMatches = New-AutomationElementList
    foreach ($candidate in $elements) {
        try {
            $firstCurrent=$candidate.Current
            $candidateName=$firstCurrent.Name
            $candidateType=$firstCurrent.ControlType
            if ($candidateName.Contains('下载')) {
                $controlTypeEquals=$candidateType -eq $buttonType
                $nameEquals=$candidateName -eq $buttonName
                $processIdEquals=$firstCurrent.ProcessId -eq $processId
                $programmaticName = $firstCurrent.ControlType.ProgrammaticName
                $programmaticNameEquals = $programmaticName -eq 'ControlType.Button'
                $secondCurrent=$candidate.Current
                $sameCurrentObject=[Object]::ReferenceEquals($firstCurrent,$secondCurrent)
                $codepointList = New-Object -TypeName 'System.Collections.Generic.List[string]'
                for ($i=0; $i -lt $candidateName.Length; $i++) {
                    $codepoint=[int][char]$candidateName[$i]
                    $hasNextChar = $i + 1 -lt $candidateName.Length
                    $isHighSurrogate = [char]::IsHighSurrogate($candidateName[$i])
                    $isLowSurrogate = $false
                    if ($hasNextChar) {
                        $isLowSurrogate = [char]::IsLowSurrogate($candidateName[$i + 1])
                    }
                    if ($isHighSurrogate -and $hasNextChar -and $isLowSurrogate) {
                        $codepoint=[char]::ConvertToUtf32($candidateName,$i)
                        $i++
                    }
                    $codepointList.Add(('U+{0:X4}' -f $codepoint))
                }
                $codepoints=$codepointList -join ','
                $automationId=$firstCurrent.AutomationId
                $candidateLength = $candidateName.Length
                $candidateControl = $candidateType.ProgrammaticName
                $candidatePid = $firstCurrent.ProcessId
                $candidateCurrentType = $firstCurrent.GetType().FullName
                $message = 'startup prompt probe elapsed_since_first_probe={0}s ' +
                    'pass3-candidate Name=''{1}'' NameLength={2} Codepoints={3} ' +
                    'ControlType={4} ProcessId={5} AutomationId=''{6}'' ' +
                    'ControlTypeEquals={7} NameEquals={8} ProcessIdEquals={9} ' +
                    'ProgrammaticNameEquals={10} CurrentReferenceEquals={11} ' +
                    'CurrentType={12}'
                Log ($message -f $elapsed, $candidateName, $candidateLength,
                    $codepoints, $candidateControl, $candidatePid, $automationId,
                    $controlTypeEquals, $nameEquals, $processIdEquals,
                    $programmaticNameEquals, $sameCurrentObject,
                    $candidateCurrentType)
                $matchesButton = $controlTypeEquals -and $nameEquals -and
                    $processIdEquals -and $programmaticNameEquals
                if ($matchesButton) {
                    $broadMatches.Add($candidate)
                }
            }
        } catch {
            $errorType = $_.Exception.GetType().Name
            $message = 'startup prompt probe elapsed_since_first_probe={0}s ' +
                'pass3-property-error type={1}'
            Log ($message -f $elapsed, $errorType)
        }
    }

    $secondElements=$root.FindAll($scope,$pidCondition)
    $secondFindAllButton=$false
    foreach ($candidate in $secondElements) {
        try {
            if ($candidate.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and
                $candidate.Current.Name -eq $buttonName) { $secondFindAllButton=$true; break }
        } catch { }
    }
    $firstCount = $elements.Count
    $secondCount = $secondElements.Count
    $sameCount = $firstCount -eq $secondCount
    $message = 'startup prompt probe elapsed_since_first_probe={0}s ' +
        'FindAll-count-comparison first={1} second={2} sameCount={3} ' +
        'secondContainsButton={4}'
    Log ($message -f $elapsed, $firstCount, $secondCount, $sameCount,
        $secondFindAllButton)

    $windowType=[Windows.Automation.ControlType]::Window
    $mainWindowTypeCondition = New-PropertyCondition $controlTypeProperty $windowType
    $mainWindowPidCondition = New-PropertyCondition $processIdProperty $processId
    $mainWindowConditions = @($mainWindowTypeCondition, $mainWindowPidCondition)
    $mainWindowCondition = New-AndCondition $mainWindowConditions
    $mainWindow = $root.FindFirst($childrenScope, $mainWindowCondition)
    $script:startupPromptMainWindow=$mainWindow
    $mainWindowName='<not found>'
    if ($mainWindow) { $mainWindowName=$mainWindow.Current.Name }
    $mainElements=$null
    $mainWindowButton=$null
    if ($mainWindow) {
        $mainElements=$mainWindow.FindAll($scope,$trueCondition)
        foreach ($candidate in $mainElements) {
            try {
                $candidateIsButton = $candidate.Current.ControlType.ProgrammaticName -eq
                    'ControlType.Button'
                $candidateHasName = $candidate.Current.Name -eq $buttonName
                $candidateHasPid = $candidate.Current.ProcessId -eq $processId
                if ($candidateIsButton -and $candidateHasName -and $candidateHasPid) {
                    $mainWindowButton=$candidate
                    break
                }
            } catch { }
        }
    }
    $installIdCondition = New-PropertyCondition $automationIdProperty 'UpdatePrompt.Install'
    $installConditions = @($installIdCondition, $pidCondition)
    $installIdAndPid = New-AndCondition $installConditions
    $updateTypeCondition = New-PropertyCondition $controlTypeProperty $windowType
    $updateNameCondition = New-PropertyCondition $nameProperty 'USB Bridge Desk 更新'
    $updatePidCondition = New-PropertyCondition $processIdProperty $processId
    $updateWindowConditions = @(
        $updateTypeCondition, $updateNameCondition, $updatePidCondition
    )
    $updateWindowCondition = New-AndCondition $updateWindowConditions
    $topLevelWindowHit = $null -ne $root.FindFirst(
        $childrenScope, $updateWindowCondition
    )
    $rootAutomationIdButton=$root.FindFirst($scope,$installIdAndPid)
    $mainAutomationIdButton=$null
    if ($mainWindow) {
        $mainAutomationIdButton = $mainWindow.FindFirst($scope, $installIdAndPid)
    }
    $deferIdCondition = New-PropertyCondition $automationIdProperty 'UpdatePrompt.Defer'
    $deferConditions = @($deferIdCondition, $pidCondition)
    $deferIdAndPid = New-AndCondition $deferConditions
    $rootDeferButton=$root.FindFirst($scope,$deferIdAndPid)
    $mainDeferButton=$null
    if ($mainWindow) {
        $mainDeferButton = $mainWindow.FindFirst($scope, $deferIdAndPid)
    }
    if (-not $script:startupPromptLookupMode) {
        if ($mainAutomationIdButton) {
            $script:startupPromptLookupMode = 'main-window-automation-id'
        } elseif ($rootAutomationIdButton) {
            $script:startupPromptLookupMode = 'root-automation-id'
        }
    }
    $mainElementCount = 0
    if ($mainElements) { $mainElementCount = $mainElements.Count }
    $hasRootInstall = $null -ne $rootAutomationIdButton
    $hasMainInstall = $null -ne $mainAutomationIdButton
    $hasRootDefer = $null -ne $rootDeferButton
    $hasMainDefer = $null -ne $mainDeferButton
    $probeSummary = 'startup prompt probe elapsed_since_first_probe={0}s ' +
        'main-window-root count={1} installAutomationIdRoot={2} ' +
        'installAutomationIdMainWindow={3} deferAutomationIdRoot={4} ' +
        'deferAutomationIdMainWindow={5} selectedLookup={6}'
    Log ($probeSummary -f $elapsed, $mainElementCount, $hasRootInstall,
        $hasMainInstall, $hasRootDefer, $hasMainDefer,
        $script:startupPromptLookupMode)
    $pidConditionForWindows = New-PropertyCondition $processIdProperty $processId
    $windowTypeCondition = New-PropertyCondition $controlTypeProperty $windowType
    $windowTypeConditions = @($windowTypeCondition, $pidConditionForWindows)
    $windowTypeAndPidCondition = New-AndCondition $windowTypeConditions
    $windowByTypePid = $root.FindFirst($childrenScope, $windowTypeAndPidCondition)
    $windowNameCondition = New-PropertyCondition $nameProperty 'USB Bridge Desk 更新'
    $windowNameConditions = @(
        $windowTypeCondition, $windowNameCondition, $pidConditionForWindows
    )
    $windowNameAndPidCondition = New-AndCondition $windowNameConditions
    $windowByNamePid = $root.FindFirst($childrenScope, $windowNameAndPidCondition)
    $windowByNameOnly = $root.FindFirst($childrenScope, $windowNameCondition)
    if ($windowByTypePid) {
        $currentProperties='unavailable'
        $cachedProperties='unavailable'
        try {
            $current=$windowByTypePid.Current
            $currentProperties = 'type={0} name=''{1}'' pid={2} automationId=''{3}'' ' +
                'class=''{4}'' hwnd={5} control={6} content={7} rect={8}'
            $currentProperties = ($currentProperties -f
                $current.ControlType.ProgrammaticName, $current.Name,
                $current.ProcessId, $current.AutomationId, $current.ClassName,
                $current.NativeWindowHandle, $current.IsControlElement,
                $current.IsContentElement, $current.BoundingRectangle)
        } catch {
            $errorType = $_.Exception.GetType().Name
            $errorMessage = $_.Exception.Message
            $currentProperties = 'propertyReadError={0}:{1}' -f $errorType, $errorMessage
        }
        try {
            $cached=$windowByTypePid.Cached
            $cachedProperties = 'type={0} name=''{1}'' pid={2} automationId=''{3}'' ' +
                'class=''{4}'' hwnd={5} control={6} content={7} rect={8}'
            $cachedProperties = ($cachedProperties -f
                $cached.ControlType.ProgrammaticName, $cached.Name,
                $cached.ProcessId, $cached.AutomationId, $cached.ClassName,
                $cached.NativeWindowHandle, $cached.IsControlElement,
                $cached.IsContentElement, $cached.BoundingRectangle)
        } catch {
            $errorType = $_.Exception.GetType().Name
            $errorMessage = $_.Exception.Message
            $cachedProperties = 'unavailable={0}:{1}' -f $errorType, $errorMessage
        }
        $windowProperties="current[$currentProperties] cached[$cachedProperties]"
    } else { $windowProperties='<not found>' }
    $hasWindowTypePid = $null -ne $windowByTypePid
    $hasWindowNamePid = $null -ne $windowByNamePid
    $hasWindowName = $null -ne $windowByNameOnly
    $message = 'startup prompt probe elapsed_since_first_probe={0}s ' +
        'UpdateWindow={1} MainWindow=''{2}'' WindowTypePid={3} ' +
        'WindowNamePid={4} WindowNameOnly={5} typePidCurrent=[{6}]'
    Log ($message -f $elapsed, $topLevelWindowHit, $mainWindowName,
        $hasWindowTypePid, $hasWindowNamePid, $hasWindowName, $windowProperties)
    $parts = New-ConditionList
    $parts.Add((New-PropertyCondition $controlTypeProperty $buttonType))
    $parts.Add((New-PropertyCondition $nameProperty $buttonName))
    $parts.Add((New-PropertyCondition $processIdProperty $processId))
    $hwndHits=@()
    foreach ($hwnd in [R5WindowProbe]::ForProcess($processId)) {
        $rect = New-Object -TypeName R5WindowProbe+Rect
        $rectAvailable=[R5WindowProbe]::GetWindowRect($hwnd,[ref]$rect)
        $visible=[R5WindowProbe]::IsWindowVisible($hwnd)
        $element=$null
        $fromHandleError='none'
        try { $element=[Windows.Automation.AutomationElement]::FromHandle($hwnd) }
        catch { $fromHandleError=$_.Exception.GetType().Name }
        $button=$null
        if ($element) {
            $buttonCondition = New-AndCondition $parts.ToArray()
            try { $button = $element.FindFirst($scope, $buttonCondition) }
            catch {
                $errorType = $_.Exception.GetType().Name
                $fromHandleError = 'FindFirst:{0}' -f $errorType
            }
        }
        $title='<null>'
        if ($element) {
            try { $title=$element.Current.Name }
            catch { $title='<property error>' }
        }
        $hasElement = $null -ne $element
        $hasButton = $null -ne $button
        $message = 'startup HWND probe hwnd=0x{0:X} visible={1} ' +
            'rectAvailable={2} rect={3},{4},{5},{6} FromHandle={7} ' +
            'fromHandleError={8} title=''{9}'' buttonFound={10}'
        $message = $message -f $hwnd.ToInt64(), $visible, $rectAvailable,
            $rect.Left, $rect.Top, $rect.Right, $rect.Bottom, $hasElement,
            $fromHandleError, $title, $hasButton
        Log $message
        if ($button) { $hwndHits+=,$button }
    }
    $script:lastStartupHwndButton=$hwndHits | Select-Object -First 1
    $hasHwndButton = $null -ne $script:lastStartupHwndButton
    Log ('startup prompt probe HWNDButton={0}' -f $hasHwndButton)
}
function Write-TopLevelWindows([string]$label) {
    $windows=@([R5WindowProbe]::AllWindows())
    Log ('Top-level windows ({0}) count={1}:' -f $label, $windows.Count)
    foreach ($window in $windows) {
        Log ('HWND=0x{0:X} PID={1} visible={2} title=''{3}''' -f
            $window.Handle.ToInt64(), $window.ProcessId, $window.Visible, $window.Title)
    }
}
function Write-UninstallerTimeoutDiagnostics([int]$processId,[string]$label) {
    try {
        $un.Refresh()
        Log ('Uninstaller timeout ({0}): started PID={1} HasExited={2}' -f
            $label, $un.Id, $un.HasExited)
    } catch { Log ('Uninstaller launch-state error: {0}' -f $_.Exception.Message) }
    if ($processId -gt 0) {
        $owner=Get-Process -Id $processId -ErrorAction SilentlyContinue
        Log ('Uninstaller dialog owner PID={0} alive={1}' -f $processId, ($null -ne $owner))
    } else {
        Log 'Uninstaller dialog owner PID=0 unknown (no window was discovered).'
    }
    try {
        $startedPid=$un.Id
        $childProcesses=@(Get-CimInstance Win32_Process -Filter "ParentProcessId = $startedPid")
        Log ('Child processes of started uninstaller PID={0} count={1}:' -f
            $startedPid, $childProcesses.Count)
        foreach ($child in $childProcesses) {
            Log ('CHILD PID={0} executable=''{1}''' -f $child.ProcessId, $child.ExecutablePath)
        }
    } catch { Log ('Uninstaller child-process query error: {0}' -f $_.Exception.Message) }
    try { Write-TopLevelWindows $label }
    catch { Log ('Top-level window enumeration error: {0}' -f $_.Exception.Message) }
    try {
        $allElements=$root.FindAll($scope,$trueCondition)
        Log ('UIA timeout dump NO PID FILTER ({0}) elements={1}:' -f
            $label, $allElements.Count)
        foreach ($element in $allElements) {
            try {
                $current=$element.Current
                $type=$current.ControlType.ProgrammaticName
                if ($type -eq 'ControlType.Window' -or $type -eq 'ControlType.Button') {
                    Log ('UIA type={0} name/title=''{1}'' PID={2} AutomationId=''{3}''' -f
                        $type, $current.Name, $current.ProcessId, $current.AutomationId)
                }
            } catch { Log ('UIA element property error: {0}' -f $_.Exception.Message) }
        }
    } catch { Log ('UIA no-PID-filter dump error: {0}' -f $_.Exception.Message) }
}
function Find-UninstallerWindow([int]$seconds=30) {
    $until=(Get-Date).AddSeconds($seconds)
    do {
        $windows=@([R5WindowProbe]::AllWindows())
        $candidates=@($windows | Where-Object { $_.Visible -and $_.Title })
        Log ('Uninstaller window poll candidates={0}:' -f $candidates.Count)
        foreach ($window in $candidates) {
            Log ('Candidate HWND=0x{0:X} PID={1} title=''{2}''' -f
                $window.Handle.ToInt64(), $window.ProcessId, $window.Title)
        }
        $match=$candidates | Where-Object {
            $_.Title.IndexOf('USB Bridge Desk', [StringComparison]::OrdinalIgnoreCase) -ge 0 -and
                ($_.Title.IndexOf('卸载', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                 $_.Title.IndexOf('Uninstall', [StringComparison]::OrdinalIgnoreCase) -ge 0)
        } | Select-Object -First 1
        if ($match) {
            Log ('Found uninstaller HWND=0x{0:X} owner PID={1} title=''{2}''' -f
                $match.Handle.ToInt64(), $match.ProcessId, $match.Title)
            Get-UninstallerDialogProbe $match.Handle $match.ProcessId 'window discovery' | Out-Null
            return $match.ProcessId
        }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    Write-UninstallerTimeoutDiagnostics 0 'uninstaller window discovery'
    Shot 'uninstall-timeout.png'
    throw 'Timed out waiting for a visible USB Bridge Desk Uninstall window.'
}

# NSIS-only helpers. The app/update paths continue to use Wait-Button and Click.
function Get-UninstallerDialogProbe([IntPtr]$handle,[int]$processId,[string]$label,
    [bool]$writeLog=$true) {
    if ($writeLog) {
        Log ('=== NSIS dialog Win32/UIA comparison ({0}) HWND=0x{1:X} owner PID={2} ===' -f
            $label, $handle.ToInt64(), $processId)
    }
    # This discriminant is raw Win32: no UIA is used to discover these children.
    $nativeChildren=@([R5WindowProbe]::ChildWindows($handle))
    if ($writeLog) {
        Log ('Win32 EnumChildWindows + GetWindowTextW list count={0}:' -f $nativeChildren.Count)
        foreach ($child in $nativeChildren) {
            Log ('WIN32 child HWND=0x{0:X} class=''{1}'' text=''{2}'' PID={3} visible={4} enabled={5}' -f
                $child.Handle.ToInt64(), $child.ClassName, $child.Text,
                $child.ProcessId, $child.Visible, $child.Enabled)
        }
    }
    $uiaRows=@()
    try {
        $dialog=[Windows.Automation.AutomationElement]::FromHandle($handle)
        $elements=$dialog.FindAll($scope,$trueCondition)
        if ($writeLog) { Log ('UIA dialog subtree list count={0}:' -f $elements.Count) }
        foreach ($element in $elements) {
            try {
                $current=$element.Current
                $row=[pscustomobject]@{
                    Element=$element; ControlType=$current.ControlType.ProgrammaticName
                    Name=$current.Name; AutomationId=$current.AutomationId
                    ProcessId=$current.ProcessId; Enabled=$current.IsEnabled
                }
                $uiaRows+=,$row
                if ($writeLog) {
                    Log ('UIA child ControlType={0} Name=''{1}'' AutomationId=''{2}'' PID={3}' -f
                        $row.ControlType, $row.Name, $row.AutomationId, $row.ProcessId)
                }
            } catch { Log ('UIA dialog child property error: {0}' -f $_.Exception.Message) }
        }
    } catch { Log ('UIA dialog subtree list unavailable: {0}' -f $_.Exception.Message) }
    return [pscustomobject]@{
        Handle=$handle; ProcessId=$processId; Win32Children=$nativeChildren; UiaRows=$uiaRows
    }
}
function Get-UninstallerButtonProbe([string]$label,[string[]]$names,[int]$processId,
    [bool]$writeLog=$true) {
    if ($processId -le 0) { throw 'NSIS button lookup requires a discovered owner PID.' }
    # The guard MessageBox is a separate top-level HWND owned by the discovered PID.
    $dialogs=@([R5WindowProbe]::AllWindows() | Where-Object {
        $_.Visible -and $_.ProcessId -eq $processId
    })
    if ($writeLog) {
        Log ('NSIS button probe ({0}) discovered owner PID={1} visible dialogs={2}' -f
            $label, $processId, $dialogs.Count)
        if ($dialogs.Count -eq 0) {
            Log 'Win32 EnumChildWindows + GetWindowTextW list unavailable: no visible owner dialog.'
            Log 'UIA dialog subtree list unavailable: no visible owner dialog.'
        }
    }
    if ((Test-ButtonName '取消' $names) -or (Test-ButtonName 'Cancel' $names)) {
        $names=@('取消','取消(C)','Cancel')
    }
    $uiaButton=$null
    $nativeButton=$null
    $text=@()
    foreach ($dialog in $dialogs) {
        $probe=Get-UninstallerDialogProbe $dialog.Handle $processId $label $writeLog
        foreach ($child in $probe.Win32Children) {
            if ($child.ProcessId -ne $processId) { continue }
            $text+=,$child.Text
            if (-not $nativeButton -and $child.ClassName -eq 'Button' -and
                $child.Visible -and $child.Enabled -and (Test-ButtonName $child.Text $names)) {
                $nativeButton=$child
            }
        }
        foreach ($row in $probe.UiaRows) {
            if ($row.ProcessId -ne $processId) { continue }
            $text+=,$row.Name
            if (-not $uiaButton -and $row.ControlType -eq 'ControlType.Button' -and
                $row.Enabled -and (Test-ButtonName $row.Name $names)) {
                $uiaButton=$row.Element
            }
        }
    }
    return [pscustomobject]@{
        Label=$label; Names=$names; ProcessId=$processId
        UiaButton=$uiaButton; NativeButton=$nativeButton; DialogText=($text -join ' ')
    }
}
function Wait-UninstallerButton([string]$label,[string[]]$names,[int]$processId,
    [int]$seconds=30) {
    $until=(Get-Date).AddSeconds($seconds)
    $firstProbe=$true
    do {
        if ($script:uninstallerNativeClick -and $script:uninstallerNativeClick.IsFaulted) {
            throw $script:uninstallerNativeClick.Exception
        }
        $probe=Get-UninstallerButtonProbe $label $names $processId $firstProbe
        $firstProbe=$false
        if ($probe.UiaButton) {
            Log ('NSIS button found via UIA ({0}) owner PID={1}' -f $label, $processId)
            Get-UninstallerButtonProbe $label $names $processId | Out-Null
            return $probe
        }
        Start-Sleep -Milliseconds 200
    } while ((Get-Date) -lt $until)
    # Refresh/log both independent lists before choosing fallback or throwing.
    $probe=Get-UninstallerButtonProbe $label $names $processId
    if ($probe.UiaButton) { return $probe }
    if ($probe.NativeButton) {
        Log ('NSIS UIA wait expired ({0}); using Win32 BM_CLICK fallback owner PID={1}' -f
            $label, $processId)
        return $probe
    }
    Write-UninstallerTimeoutDiagnostics $processId $label
    Shot 'uninstall-timeout.png'
    throw ('Neither UIA nor Win32 found NSIS button ({0}) names={1} owner PID={2}.' -f
        $label, ($names -join ', '), $processId)
}
function Click-UninstallerButton($button) {
    if ($button.UiaButton) {
        try {
            $pattern=$null
            if ($button.UiaButton.TryGetCurrentPattern($invoke,[ref]$pattern)) {
                Log ('NSIS click via UIA InvokePattern ({0}) owner PID={1}' -f
                    $button.Label, $button.ProcessId)
                $pattern.Invoke()
                return
            }
            Log ('NSIS UIA button has no InvokePattern ({0}); trying Win32 BM_CLICK.' -f $button.Label)
        } catch {
            Log ('NSIS UIA InvokePattern failed ({0}): {1}; trying Win32 BM_CLICK.' -f
                $button.Label, $_.Exception.Message)
        }
    }
    # Re-enumerate to avoid using a child HWND cached before a modal transition.
    $probe=Get-UninstallerButtonProbe $button.Label $button.Names $button.ProcessId
    if ($probe.NativeButton) {
        $child=$probe.NativeButton
        Log ('NSIS click via Win32 SendMessage BM_CLICK ({0}) HWND=0x{1:X} text=''{2}'' owner PID={3}' -f
            $button.Label, $child.Handle.ToInt64(), $child.Text, $button.ProcessId)
        $script:uninstallerNativeClick=[R5WindowProbe]::BeginButtonClick($child.Handle)
        return
    }
    Write-UninstallerTimeoutDiagnostics $button.ProcessId $button.Label
    Shot 'uninstall-timeout.png'
    throw ('Cannot click NSIS button ({0}); both enumeration lists logged, owner PID={1}.' -f
        $button.Label, $button.ProcessId)
}

function Wait-Button([string]$label,[string[]]$names,[int]$processId=0,[int]$seconds=20,
    [string]$shotName='update-prompt-timeout.png') {
    $until=(Get-Date).AddSeconds($seconds)
    $nextProbe=Get-Date
    $keepWaiting = $true
    while ($keepWaiting) {
        if ($label -eq 'startup update prompt' -and (Get-Date) -ge $nextProbe) {
            Write-StartupPromptProbe $processId
            $nextProbe=(Get-Date).AddSeconds(5)
        }
        $item=Find-Button $names $processId $label
        if ($item) {
            if ($label -eq 'startup update prompt') {
                $openedAt=Get-StartupPromptOpenedAt
                $latencyBasis='first-probe-fallback'
                $latencyStart=$script:startupPromptProbeStart
                if ($openedAt) { $latencyBasis='app-Opened'; $latencyStart=$openedAt }
                $latency=[math]::Round(((Get-Date)-$latencyStart).TotalSeconds,1)
                $script:startupPromptLatency=$latency
                $script:startupPromptLatencyExceeded=$latency -gt 10
                $hitTimestamp = Get-Date -Format o
                $withinLimit = -not $script:startupPromptLatencyExceeded
                $message = 'startup prompt first-hit timestamp={0} elapsed_since={1} ' +
                    '{2}s via={3} acceptanceWithin10s={4}'
                Log ($message -f $hitTimestamp, $latencyBasis, $latency,
                    $script:lastButtonLookup, $withinLimit)
                Write-StartupPromptProbe $processId
                Shot 'update-prompt-first-hit.png'
                $shotTimestamp = Get-Date -Format o
                $message = 'startup prompt first-hit screenshot timestamp={0} ' +
                    'path=update-prompt-first-hit.png'
                Log ($message -f $shotTimestamp)
                Log "startup update prompt button found via=$script:lastButtonLookup"
            }
            return $item
        }
        Start-Sleep -Milliseconds 200
        $keepWaiting = (Get-Date) -lt $until
    }
    if ($processId -gt 0 -and $shotName -eq 'uninstall-timeout.png') {
        Write-UninstallerTimeoutDiagnostics $processId $label
    }
    $pidCondition = New-PropertyCondition $processIdProperty $processId
    if ($processId -gt 0) {
        $elements=$root.FindAll($scope,$pidCondition)
        $namesDump=@($elements | ForEach-Object {
            $elementName=$_.Current.Name
            $controlType=$_.Current.ControlType.ProgrammaticName
            if ($controlType -eq 'ControlType.Window') { "WINDOW title='$elementName'" }
            if ($controlType -eq 'ControlType.Button') { "BUTTON name='$elementName'" }
            if ($elementName) { "ELEMENT type=$controlType name='$elementName'" }
        } | Where-Object { $_ })
        $timeoutElementCount=$elements.Count
        $namesDumpText=$namesDump -join $newLine
        $timeoutHeader = ('UIA timeout dump for PID {0} ({1}) elements={2}:' -f
            $processId, $label, $timeoutElementCount
        )
        Log ($timeoutHeader + $newLine + $namesDumpText)
    } else {
        Log "UIA timeout dump unavailable for ${label}: no process ID was supplied."
    }
    Shot $shotName
    $nameSeparator=', '
    $namesText=$names -join $nameSeparator
    throw "Timed out waiting for $label ($namesText)."
}
function Click([Windows.Automation.AutomationElement]$item) {
    $pattern=$null
    if ($item.TryGetCurrentPattern($invoke,[ref]$pattern)) { $pattern.Invoke(); return }
    $selection=$null
    $selectionItemPattern = [Windows.Automation.SelectionItemPattern]::Pattern
    if ($item.TryGetCurrentPattern($selectionItemPattern, [ref]$selection)) {
        $selection.Select()
        return
    }
    $item.SetFocus()
    [Windows.Forms.SendKeys]::SendWait('{ENTER}')
}
function Confirm-AppAutomationId([string]$automationId,[string]$label,[int]$processId) {
    $pidCondition = New-PropertyCondition $processIdProperty $processId
    $elements=$root.FindAll($scope,$pidCondition)
    $matches=@($elements | Where-Object { $_.Current.AutomationId -ceq $automationId })
    if ($matches.Count -ne 1) {
        $message = 'Independent UIA enumeration found {0} elements with ' +
            "AutomationId '$automationId' for $label."
        throw ($message -f $matches.Count)
    }
    $element=$matches[0]
    $controlType=$element.Current.ControlType.ProgrammaticName
    $elementProcessId = $element.Current.ProcessId
    $message = 'Independent UIA enumeration label=''{0}'' AutomationId=''{1}'' ' +
        'ControlType={2} ProcessId={3}'
    Log ($message -f $label, $automationId, $controlType, $elementProcessId)
    if ($label -eq 'Settings navigation' -and $controlType -ne 'ControlType.ListItem') {
        throw "Settings navigation AutomationId resolved to unexpected ControlType $controlType."
    }
    return $element
}
function Wait-HashFailure([int]$processId,[int]$seconds=60) {
    $until=(Get-Date).AddSeconds($seconds)
    $trace=Join-Path $env:LOCALAPPDATA 'USB Bridge Desk\startup.log'
    $lastNames=@()
    $hasBanner=$false
    $hasFailureText=$false
    $traceConfirmed=$false
    $space=' '
    $nameSeparator=' | '
    $keepWaiting = $true
    while ($keepWaiting) {
        # Reacquire the full UIA subtree every time; live peers can appear late.
        $pidCondition = New-PropertyCondition $processIdProperty $processId
        $elements=$root.FindAll($scope,$pidCondition)
        $lastNames=@($elements | ForEach-Object { $_.Current.Name } | Where-Object { $_ })
        $bannerMatches = @(
            $elements | Where-Object { $_.Current.AutomationId -ceq 'UpdateNotice' }
        )
        $hasBanner = $bannerMatches.Count -gt 0
        $lastNamesText=$lastNames -join $space
        $failureTextPattern = 'SHA-256 校验失败，未启动安装程序'
        $hasFailureText = $lastNamesText -match $failureTextPattern
        $traceText=''
        if (Test-Path -LiteralPath $trace) {
            $traceText=Get-Content -LiteralPath $trace -Raw -Encoding UTF8
        }
        $tracePrefix='Update check/download failed: '
        $traceFailure = 'System\.IO\.InvalidDataException: ' +
            '更新包 SHA-256 校验失败，未启动安装程序。'
        $tracePattern=$tracePrefix + $traceFailure
        $traceConfirmed=$traceText -match $tracePattern
        if ($hasBanner -and $hasFailureText -and $traceConfirmed) {
            $closePidCondition = New-PropertyCondition $processIdProperty $processId
            $closeIdCondition = New-PropertyCondition $automationIdProperty 'UpdateNotice.Close'
            $closeConditions = @($closePidCondition, $closeIdCondition)
            $closeCondition = New-AndCondition $closeConditions
            $close=$root.FindFirst($scope,$closeCondition)
            if ($close) {
                $message = 'Wrong SHA-256 rejection confirmed: UpdateNotice AutomationId ' +
                    'present, UIA failure text visible, and startup trace records ' +
                    'InvalidDataException.'
                Log $message
                return $close
            }
        }
        Start-Sleep -Milliseconds 500
        $keepWaiting = (Get-Date) -lt $until
    }
    $lastNamesJoined=$lastNames -join $nameSeparator
    $message = 'Wrong SHA-256 rejection timeout: banner={0} UIAText={1} ' +
        'trace={2} names={3}'
    Log ($message -f $hasBanner, $hasFailureText, $traceConfirmed, $lastNamesJoined)
    $lastNamesDump=$lastNames -join $newLine
    $timeoutHeader = 'UIA timeout dump for PID {0} (SHA-256 failure):' -f $processId
    Log ($timeoutHeader + $newLine + $lastNamesDump)
    Shot 'update-hash-failure-timeout.png'
    $message = 'Timed out waiting for SHA-256 failure banner, text, and application ' +
        'trace ({0} seconds).'
    throw ($message -f $seconds)
}
function Shot([string]$name) {
    $bounds=[Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp = New-Object -TypeName System.Drawing.Bitmap -ArgumentList $bounds.Width, $bounds.Height
    $g=[Drawing.Graphics]::FromImage($bmp)
    try {
        $g.CopyFromScreen($bounds.Location, [Drawing.Point]::Empty, $bounds.Size)
        $imagePath = Join-Path $OutDir $name
        $pngFormat = [Drawing.Imaging.ImageFormat]::Png
        $bmp.Save($imagePath, $pngFormat)
    } finally {
        $g.Dispose()
        $bmp.Dispose()
    }
}
function Set-Manifest([string]$hash) {
    $downloadUrl = $FixtureUrl.TrimEnd('/') +
        '/USB-Bridge-Desk-R5-1.3.0-x64.exe'
    $manifest = @{
        latest_version = '9.9.9'
        download_url = $downloadUrl
        sha256 = $hash
        release_notes = 'Windows updater acceptance fixture'
    }
    $json = $manifest | ConvertTo-Json
    $manifestPath = Join-Path (Split-Path $log) 'version.json'
    $encoding = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false
    [IO.File]::WriteAllText($manifestPath, $json, $encoding)
}
function Check-Update([int]$processId) {
    $settings=Wait-Button 'Settings navigation' @('设置') $processId
    Confirm-AppAutomationId 'Nav.settings' 'Settings navigation' $processId | Out-Null
    Click $settings
    $check=Wait-Button 'settings update check' @('检查更新') $processId
    Confirm-AppAutomationId 'Settings.UpdateCheck' 'settings update check' $processId | Out-Null
    Click $check
    return Wait-Button 'new version dialog' @('下载并安装') $processId
}
try {
    $validHash=(Get-FileHash -LiteralPath $InstallerPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $fixtureRoot=Split-Path $log
    $fixtureInstaller = Join-Path $fixtureRoot 'USB-Bridge-Desk-R5-1.3.0-x64.exe'
    Copy-Item -LiteralPath $InstallerPath -Destination $fixtureInstaller -Force
    Set-Manifest $validHash
    $env:USB_BRIDGE_DESK_UPDATE_URL=$FixtureUrl.TrimEnd('/')+'/version.json'
    $app=Start-Process -FilePath $AppPath -PassThru
    $null=Wait-Window $app.Id
    $prompt=Wait-Button 'startup update prompt' @('下载并安装') $app.Id 90
    Shot 'update-available.png'
    Log 'New-version prompt visible at startup; download button has not been clicked.'
    Click (Wait-Button 'defer update' @('稍后') $app.Id)
    $prompt=Check-Update $app.Id
    $requests=Join-Path $fixtureRoot 'requests.log'
    $earlyDownloadPattern = 'USB-Bridge-Desk-R5-1.3.0-x64.exe'
    $earlyDownloadLogged = $false
    if (Test-Path $requests) {
        $requestText = Get-Content $requests -Raw
        $earlyDownloadLogged = $requestText -match $earlyDownloadPattern
    }
    if ($earlyDownloadLogged) {
        throw 'Installer download began before the user chose 下载并安装.'
    }
    Log ('Settings check showed the update; server log confirms no installer ' +
        'download before explicit choice.')
    Click (Wait-Button 'defer settings update' @('稍后') $app.Id)
    Shot 'settings-update-result.png'

    Set-Manifest ('0' * 64)
    $prompt=Check-Update $app.Id
    Click $prompt
    $failure=Wait-HashFailure $app.Id 60
    Shot 'update-hash-failure.png'
    Log 'Wrong SHA-256 manifest was rejected and the UI reported verification failure.'
    Click $failure

    Set-Manifest $validHash
    $prompt=Check-Update $app.Id
    Click $prompt
    if (-not $app.WaitForExit(30000)) {
        throw 'Application did not exit after handing the verified installer to Windows.'
    }
    $deadline=(Get-Date).AddSeconds(30)
    $installerProcess=$null
    $installerLaunchPending = $true
    while ($installerLaunchPending) {
        $processes = Get-CimInstance Win32_Process
        $installerProcess = $processes |
            Where-Object {
                $_.Name -like 'USB-Bridge-Desk-*.exe' -and
                $_.ExecutablePath -ne $AppPath
            } |
            Select-Object -First 1
        if ($installerProcess) { break }
        Start-Sleep -Milliseconds 250
        $installerLaunchPending = (Get-Date) -lt $deadline
    }
    if (-not $installerProcess) {
        throw 'Verified update download did not launch the downloaded installer.'
    }
    $installerPid = $installerProcess.ProcessId
    Log ('Correct SHA-256 download launched installer PID {0}.' -f $installerPid)
    Stop-Process -Id $installerProcess.ProcessId -Force
    $downloaded=Get-Content $requests -Raw
    $downloadPattern = 'USB-Bridge-Desk-R5-1.3.0-x64.exe'
    if ($downloaded -notmatch $downloadPattern) {
        throw 'Fixture server did not record the installer download.'
    }
    Log ('Verified installer was downloaded and launched; setup process was stopped ' +
        'before modifying the installation.')
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue

    $app=Start-Process -FilePath $AppPath -PassThru
    Start-Sleep -Seconds 3
    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $unPid=Find-UninstallerWindow 30
    $unOwner=Get-Process -Id $unPid
    $liveConfirm=Wait-UninstallerButton 'running-app uninstall confirmation' @('卸载','卸载(U)','Uninstall') $unPid 30
    Click-UninstallerButton $liveConfirm
    $ok=Wait-UninstallerButton 'live-app uninstall guard dialog' @('确定','确定(O)','OK') $unPid 30
    Shot 'uninstall-running-app-guard.png'
    $guardText=$ok.DialogText
    Log ('Running-app uninstall guard captured text: {0}' -f $guardText)
    $guardPattern = '请先关闭 USB Bridge Desk'
    if ($guardText -notmatch $guardPattern) {
        throw 'Running-app guard dialog did not show its expected Chinese message.'
    }
    Log 'Running-app uninstall guard dialog captured and asserted in Simplified Chinese.'
    Click-UninstallerButton $ok
    if (-not $unOwner.WaitForExit(10000)) {
        $stillRunning=Get-Process -Id $unPid -ErrorAction SilentlyContinue
        if ($stillRunning) { Stop-Process -Id $unPid -Force -ErrorAction SilentlyContinue }
    }
    Stop-Process -Id $app.Id -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2

    $un=Start-Process -FilePath $UninstallerPath -ArgumentList '/LANG=2052' -PassThru
    $unPid=Find-UninstallerWindow 30
    $unOwner=Get-Process -Id $unPid
    $confirm=Wait-UninstallerButton 'uninstall confirmation' @('卸载','卸载(U)','Uninstall') $unPid 30
    Shot 'uninstall-confirmation.png'
    Log 'Uninstall confirmation dialog captured in Simplified Chinese.'
    Click-UninstallerButton $confirm
    if (-not $unOwner.WaitForExit(300000)) { throw 'Uninstaller did not finish within five minutes.' }
    $installDir=Split-Path $AppPath
    if (Test-Path -LiteralPath $installDir) {
        throw ('Application installation directory remains after uninstall: {0}' -f
            $installDir)
    }
    Log 'Uninstall completed and application installation directory is absent.'
    if ($script:startupPromptLatencyExceeded) {
        $latency = $script:startupPromptLatency
        $message = 'ACCEPTANCE FAILURE: startup update button first appeared after ' +
            '{0}s; required latency is <=10s after Opened. UIA black hole remains ' +
            'although updater and uninstall completed.'
        Log ($message -f $latency)
        $message = 'UIA startup prompt latency exceeded 10 seconds ({0}s); ' +
            'full flow completed but acceptance failed.'
        throw ($message -f $latency)
    }
    $latency = $script:startupPromptLatency
    $message = 'ACCEPTANCE PASS: startup update button first appeared after {0}s ' +
        '(required <=10s).'
    Log ($message -f $latency)
} finally {
    Remove-Item Env:USB_BRIDGE_DESK_UPDATE_URL -ErrorAction SilentlyContinue
}
