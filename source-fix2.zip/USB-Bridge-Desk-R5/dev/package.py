#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build both x64 programs, run portable regression tests and assemble a single installer."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / 'release'
SOURCE = 'source-fix2.zip'
INSTALLER = 'USB-Bridge-Desk-R5-1.3.0-x64.exe'
SOURCE_OUTPUT = Path(__file__).resolve().parents[3] / SOURCE

def run(command, cwd=ROOT):
    subprocess.run(command, cwd=cwd, check=True)

def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def archive(path):
    # Stable names, order and timestamps; exclude compiler caches and downloaded installers.
    with ZipFile(path, 'w') as out:
        for top in ('App','Core','Tests','dev','packaging','notices','usb.ids','README.md','LICENSE','Directory.Build.props','global.json','NuGet.Config'):
            start=ROOT/top
            for item in sorted(start.rglob('*')) if start.is_dir() else [start]:
                if not item.is_file() or {'obj','bin','__pycache__'}.intersection(item.relative_to(ROOT).parts):
                    continue
                rel = item.relative_to(ROOT).as_posix()
                info=ZipInfo('USB-Bridge-Desk-R5/'+rel,(2026,1,1,0,0,0))
                info.compress_type=ZIP_DEFLATED
                out.writestr(info,item.read_bytes())

def verify_archive(path):
    with ZipFile(path) as bundle:
        names = bundle.namelist()
        if not names or any(not name.startswith('USB-Bridge-Desk-R5/') for name in names):
            raise RuntimeError('Source archive must contain the USB-Bridge-Desk-R5 source root')
        files = {name.removeprefix('USB-Bridge-Desk-R5/') for name in names}
    required = {'App/UsbBridgeDesk.csproj','App/Assets/Orbit32.png','App/Assets/DeskUISans.ttf','usb.ids',
                'Core/Core.csproj','Core/Updater.cs','packaging/setup.nsi','dev/windows-r5-test.yml'}
    missing = required - files
    if missing:
        raise RuntimeError('Source archive is incomplete: ' + ', '.join(sorted(missing)))

def main():
    RELEASE.mkdir(exist_ok=True)
    run([sys.executable,'dev/fetch-vendor.py'])
    archive(SOURCE_OUTPUT)
    verify_archive(SOURCE_OUTPUT)
    # Compile only the delivered archive, never a sibling checkout or cached output.
    unpacked=ROOT/'build/from-source'
    if unpacked.exists(): shutil.rmtree(unpacked)
    with ZipFile(SOURCE_OUTPUT) as bundle:
        bundle.extractall(unpacked)
    source=unpacked/'USB-Bridge-Desk-R5'
    run([sys.executable,'dev/build-host.py'],source)
    dotnet=os.environ.get('DOTNET','dotnet')
    run([dotnet,'run','--project','Tests','-c','Release'],source)
    stage=source/'build/stage'
    run([dotnet,'publish','App/UsbBridgeDesk.csproj','-c','Release','--self-contained','false','-o',str(stage)],source)
    # An unpackaged WinUI build can compile successfully and lose its application
    # PRI during publish. Validate the staging directory NSIS actually consumes.
    if not (stage / 'Assets/DeskUISans.ttf').is_file():
        raise RuntimeError('Published application is missing its UI font')
    if not (stage / 'usb.ids').is_file():
        raise RuntimeError('Published application is missing the USB name database')
    for name in ('icon.ico','Assets/Orbit32.png'):
        expected = source/('packaging/icon.ico' if name=='icon.ico' else 'App/'+name)
        if not (stage/name).is_file() or sha(stage/name)!=sha(expected):
            raise RuntimeError(f'Published icon asset mismatch: {name}')
    pri = stage / 'resources.pri'
    if not pri.is_file() or pri.stat().st_size == 0:
        raise RuntimeError(f'WinUI application resource index missing from publish: {pri}')
    print(f'WinUI resources: {pri.name}  {pri.stat().st_size} bytes  SHA256 {sha(pri)}')
    for xml in stage.glob('*.xml'): xml.unlink()
    shutil.copytree(source/'build/host-win-x64',stage/'resources/host')
    engines=stage/'resources/engines'
    engines.mkdir()
    for name in ('usbipd-win_5.3.0_x64.msi','USBip-0.9.8.1-x64.exe'):
        shutil.copy2(ROOT/'vendor'/name,engines/name)
    shutil.copy2(source/'packaging/provision.ps1',engines)
    shutil.copytree(source/'notices',stage/'notices',ignore=shutil.ignore_patterns('*.zip'))
    for name in ('README.md','LICENSE'): shutil.copy2(source/name,stage/name)
    shutil.copy2(SOURCE_OUTPUT,stage/'notices'/SOURCE)
    files={p.relative_to(stage).as_posix():sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'notices/build-manifest.json').write_text(json.dumps({
        'version':'1.3.0',
        'baseline_sha256':'9a3cb19f88364e22c996d9532a25c3e0c8ed9f17e6f1b080dfb671f05d1c47b2',
        'compiled_from_archive_sha256':sha(SOURCE_OUTPUT),
        'files':files},indent=2),encoding='utf-8')
    nsis=os.environ.get('MAKENSIS','makensis')
    (source/'release').mkdir()
    run([nsis,str(source/'packaging/setup.nsi')],source)
    shutil.copy2(source/'release'/INSTALLER,RELEASE/INSTALLER)
    result=RELEASE/INSTALLER
    print(f'{result.name}  {result.stat().st_size:,} bytes  SHA256 {sha(result)}')
    if result.stat().st_size>50_000_000:
        raise RuntimeError('Installer exceeds the 50 MB release target')
    print(f'{SOURCE}  SHA256 {sha(SOURCE_OUTPUT)}')

if __name__=='__main__':
    main()
